import subprocess
from pathlib import Path
root=Path(__file__).parent
with (root/'results/latex_build.log').open('w') as log:
 for cmd in [('pdflatex','-interaction=nonstopmode','-halt-on-error','BOS2L_20260929.tex'),('bibtex','BOS2L_20260929'),('pdflatex','-interaction=nonstopmode','-halt-on-error','BOS2L_20260929.tex'),('pdflatex','-interaction=nonstopmode','-halt-on-error','BOS2L_20260929.tex')]:
  subprocess.run(cmd,cwd=root/'paper',stdout=log,stderr=subprocess.STDOUT,check=True)
print('paper/BOS2L_20260929.pdf')
