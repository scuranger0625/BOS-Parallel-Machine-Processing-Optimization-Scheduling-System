# BOS-2L 20260929 實驗紀錄

這份紀錄由 `make_report.py` 讀取原始執行結果產生。所有時間皆為合成加工時間單位；不是實際工廠分鐘。

## 主實驗

144 個事件 × 3 個容許交期 = 432 個情境。每個情境比較六種策略，共 2,592 筆 policy rows。

| 方法 | 合法筆數 | 準時筆數 | Recovery 次數 | 平均完工 | 平均逾期 | 平均開始偏移 | 平均片段換機 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Frozen BOS | 0 | 0 | 0 | — | — | — | — |
| Right shift only | 432 | 156 | 0 | 17.736 | 4.023 | 17.896 | 0.000 |
| Always greedy | 432 | 200 | 432 | 16.250 | 3.028 | 19.708 | 3.965 |
| Gated greedy | 432 | 200 | 276 | 16.637 | 3.028 | 15.812 | 1.752 |
| Gated local DP | 432 | 200 | 276 | 16.637 | 3.028 | 15.812 | 1.752 |
| Gated LP-assisted | 432 | 200 | 276 | 16.634 | 3.028 | 15.889 | 1.752 |

Frozen BOS 因為有效物料延遲而不合法，不可拿原來的短 makespan 當成優勢。Always greedy 每次事件都重排。三個 gated 方法只有右移不合交期才介入。

右移直接接受 156/432，避免 36.11% recovery；有 276 個觸發情境，greedy 救回其中 44 個，三個 gated 方法最終都準時 200 個。這不是 DP/LP 的全面勝利；主實驗的 DP 大多被初始下界或局部窗口限制主導。

平均開始偏移定義：所有 residual segment 對原參考開始時間的絕對差加總。換機數是片段與原 machine label 不同的個數；未解 machine relabeling 最小化問題，不代表最少換機成本。

## 補充小型搜尋實驗

80 個預先定義 seeds，沒有剔除 ties 或 loss。與主實驗不同，使用 full residual DP，最多 30,000 states；不能把這個 DP 的成績直接當成七節點 local DP 成績。

- DP 改善 shift/greedy 最佳候選：16/80。
- LP-assisted 改善相同候選：7/80。
- MILP optimal：80/80；DP 全數吻合。
- DP 初始 bound 認證 44 例、實際搜尋認證 36 例。
- 最大 state 數 7608；本次最大 DP 秒數 0.064372。

## 可重現設定與公平性

- 主實驗 n={6,14}、m={2,3}、alpha={0,0.75}、seed=0..5、delay={2,6,12}、tau={0,2,6}。確切 PRNG seed 見程式 `generate()`。
- 每個事件固定同一 nominal BOS prefix、物料 gate、checkpoint 與機器許可。只有比較策略不同。
- 主實驗 DP window=7、state cap=12,000；補充 full DP cap=30,000。不同計算預算單獨報告。
- LP/DP 候選跨三個交期快取。每列 seconds 是實測 component cost 加總，接受的決策不計入 solver cost；不宣稱部署端到端 latency。
- post-hoc LP/MILP 認證不算進接受分支。程式測試會確認 controller 接受時不呼叫 optimize/local_dp。
- 同一 graph/event 的不同 delay、slack 並非獨立樣本，因此未報未分群的 p-value 或信賴區間。
- 沒有公開 benchmark／真實 production trace，不能宣稱產業泛化或普遍 dominance。

## 檔案對照

| 檔案 | 內容 |
|---|---|
| results/raw.csv | 2,592 筆 policy 比較、界限、交期、變動、component runtime |
| results/certificates.jsonl | 144 個完整輸入、prefix、gate、residual、候選排程、LP/MILP status |
| results/stress.csv | 80 個 full-DP 比較，包括 raw LP-list |
| results/stress_certificates.jsonl | 補充實驗原始排程與 solver records |
| results/run.log / stress.log | 逐例執行輸出 |
| results/tests.log | 邊界案例與 24 個 DP–MILP randomized comparisons |
| results/verification.json | 重新讀取全部排程後的驗證結果 |
| results/environment.json | Python / NumPy / SciPy 與平台版本 |

所有新數字來自這次實際執行；0915、0928 歷史數字沒有混入新統計。
