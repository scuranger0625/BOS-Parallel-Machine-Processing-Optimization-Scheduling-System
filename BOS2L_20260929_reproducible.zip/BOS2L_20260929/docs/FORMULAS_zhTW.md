# BOS-2L 20260929：公式與證明導讀

**本版一句話：先保留做過的工作，把未來計畫往右推；交期仍可接受就停止，真的不行才啟動修復。**

這是以 0915 BOS、0928 checkpoint LP 與 0928 progress DP 整併的研究延伸。正式定理與證明見 `paper/BOS2L_20260929.pdf`；本文件是教學重構。DP 已改成與 LP 相同的 checkpoint 權限，沒有把「任意時槽中斷」的舊 OPT 偷渡進來。

## 1. 先認識六個時間

| 符號 | 意義 | 不要混淆 |
|---|---|---|
| (t_0) | 延遲事件揭露時刻 | 不是 slack |
| (C_0) | 原 BOS 排程完工時間 | 不一定等於原最優解 |
| (D) | 原承諾交期，假設 (C_0\le D) | 本版不再拿 D 表示延遲量 |
| (\tau) | 額外可容忍的交期時間 | 不是 revelation time |
| (B=D+\tau) | 最晚可接受交期 | 不是 LP lower bound |
| (\Delta_d) | 能讓所有剩餘片段一致右移後合法的位移量 | 不是 dimensionless epsilon |

以上均為時間單位。原本的 overlap allowance (\delta_{ij}) 則是加工 handoff 可以提前多少，和交期容錯是不同層次。

## 2. 第一層保留什麼？【原模型】

\[
\ell_{ij}=p_i-\delta_{ij},\qquad
b_i=\max\{p_i,\max_{(i,j)\in E}(\ell_{ij}+b_j)\}.
\]

BOS 在「目前合法可執行」的工作中選 (b_i) 最大者。singleton 的 (p_i) 不能拿掉。

**部分齊套先行的精確意思：每一個必要前驅都達到自己的加工門檻後，可以不用等它們全部完工就啟動後繼。** 仍是 AND，不是缺某個必要組件也能任意開始的 OR/subset 模型。這是 0914→0915 已修正過的界線。

## 3. 固定歷史，不准把做過的事情往後搬【研究延伸】

假設事件前依 nominal plan 執行，已做進度為

\[
q_i^0=\min\{p_i,\max(0,t_0-s_i^0)\}.
\]

若實際現場和計畫不同，應換成觀測進度，不能盲用此式。

把未完成工作在「當前進度、handoff 門檻、材料 gate、完成點」切成正長度片段。片段之間可暫停或換機，片段內不可中斷。事件當下也允許 checkpoint 暫停；因此這版不是『進行中工作絕對不可停』模型。

例如工作做了 1 單位、總共要做 4，後繼需要等它做滿 3：剩下可切成 [1,3] 和 [3,4]。若 [1,3] 被材料卡住，後繼不能因為鐘走到原訂時間就算拿到 3 單位產出。

## 4. 真正的右移公式【研究延伸】

對剩餘片段 v，令參考開始時間 (\bar x_v) 以 (t_0) 為零點。把原工序依賴，加上「原機器上前一片段→後一片段」形成 augmented DAG (A_0)。其邊權 (w_{uv}) 是必要開始時間差。

\[
\boxed{x_v^d=\max\{\bar x_v,R_v^d,\max_{(u,v)\in A_0}(x_u^d+w_{uv})\}.}
\]

白話：一個片段不能早於原計畫、不能早於到料，也不能早於前驅／同機器上一件工作放行。按照拓樸順序往前推一次即可。

這個 recurrence 沒有搜尋新機器順序，沒有一發生延遲就重新求全域最小 makespan；它只算**保留原有決策的最早合法右移**。

統一右移則是

\[
\Delta_d=\max_v(R_v^d-\bar x_v)_+,\qquad
x_v^{\rm uniform}=\bar x_v+\Delta_d.
\]

forward projection 與 uniform shift 不是同一個排程。前者能利用局部空隙，且

\[
\bar x_v\le x_v^d\le\bar x_v+\Delta_d.
\]

**證明骨架：**原 DAG 加上機器次序仍無環；拓樸推進逐一滿足限制。任何其他保留原次序且只能右移的合法解，都得大於等於相同三個量，因此逐點不可能比 projection 更早。統一平移不改開始時間差與機器間隔，且足夠涵蓋到料，所以是一個可行比較對象。

適用條件：相同機器、有限 release、只有下界型時間依賴、允許本版 checkpoint 暫停、無切換成本。若有 no-wait、最長等待時間、故障日曆等，需另行檢查；本定理不自動包含它們。

## 5. 你要的上下界主式【研究延伸】

\[
\boxed{LB_d\le OPT_d\le C_{\rm shift}\le U_d^{\rm shift}=C_0+\Delta_d.}
\]

四者都用**絕對完工時間**，且 OPT 固定同一段歷史與 checkpoint 操作權限。

\[
LB_d=t_0+\max\left\{\frac{W_R}{m},L_{R,\lambda},z_{LP}\right\}.
\]

沒有解 LP 時拿掉 (z_{LP})。路徑下界包含 release、沿路 lag 和最後節點加工時間。工作量下界和路徑下界用 max，不可以直接相加。

Recovery 得到更好合法候選時，另設

\[
OPT_d\le U_d^{\rm best}\le C_{\rm shift}.
\]

**不要把 (U_d^{\rm best}) 塞到 (C_{\rm shift}\le UB_d) 的右邊。** 那會把正確關係倒過來。

若 right-shift 違反額外 operational constraints，它就不是新增約束問題的合法 UB；這時只能由其他驗證合法的候選提供 UB。

## 6. 容錯到底怎麼吸收延遲？【教學重構】

\[
B=D+\tau,\quad \sigma_0=B-C_0,
\quad a_d=C_{\rm shift}-C_0,
\quad \sigma_d=B-C_{\rm shift}.
\]

- (\sigma_0)：原本留有多少交期空間。
- (a_d)：這次排程實際消耗多少空間。
- (\sigma_d\ge0)：還沒突破允許交期。

只要 \(\Delta_d\le\sigma_0\)，統一右移已可接受，所以 projection 也可接受。反過來不成立：\(\Delta_d>\sigma_0\) 時，projection 可能利用局部 idle gap 仍趕得上。

## 7. Trigger theorem：什麼時候要救？【研究延伸】

\[
\boxed{\mathrm{Trigger}
=\neg\mathrm{Valid}(S_{\rm shift})\lor(C_{\rm shift}>B).}
\]

如果合法而且 \(C_{\rm shift}\le B\)，立刻接受，不呼叫 DP／LP。

\[
C_{\rm shift}>B\;\not\Rightarrow\;OPT_d>B.
\]

原順序不行，不代表換順序也不行。能證明交期無解的充分條件是

\[
\boxed{LB_d>B\Rightarrow\text{同一模型下無排程能趕上交期}.}
\]

\(LB_d\le B\) 也不能保證有解。若找到經驗證 \(C\le B\) 的候選，才是可交付證書。

## 8. DP 與 LP 分別做什麼？【研究延伸】

| 工具 | 角色 | 保證範圍 |
|---|---|---|
| BOS score DP | DAG bottleneck priority | 線性時間算 priority，不是 exact scheduling |
| local scheduling DP | 搜尋小範圍片段決策 | 做完整才對該範圍 exact |
| full scheduling DP | 小型 residual 最適排程 | 做完整才等於同模型 OPT |
| makespan LP | 提供下界與排序訊號 | fractional 值不能直接執行 |
| LP-list | 以 expected start 排 executable set | 解碼後要檢查合法性 |
| binary MILP | 小型獨立 oracle | optimal status 才能稱最優 |

本版 DP 的 Bellman 式：

\[
V(t,q)=\min_{A\in\mathcal A(t,q)}V(t+1,q+\mathbf1_A),
\qquad V(t,h)=t.
\]

合法動作 A 必須包含**所有正在加工的片段**，維持 segment nonpreemption；最多 m 個；新片段要過 release 和所有依賴。零 lag 可同一時槽共同啟動。沒有運轉中片段時，允許空動作等待。

這版保留 (t,q)，不直接沿用 0928 的 earliest-progress dominance：因為跑到一半的片段不能任意停，不能只說「早到就等到晚到的時間」而忽略 nonpreemption。

狀態數上限 (M=\prod_v(h_v+1))，一般隨節點數指數成長。超過 state budget 只能回傳 feasible incumbent + LB，不能報 OPT。

Local DP 選拓樸尾端七個片段，其餘照 incumbent 執行；窗口開始要等凍結片段全完成。這是保守且容易驗證的初版鄰域，不等於已經找到最佳 bottleneck neighborhood。

LP 解 \(\bar t_v=\sum_t t x_{vt}\)，以 \(\bar t_v\) 小者作為 dispatcher priority。**不是把每個 fractional start 自己四捨五入。** 本版沒有在每個 DP branch 重新解 LP；LP pruning 是可研究擴充，程式目前實作的是全域 LB 與候選排序。

## 9. 一致的小例子【教學重構】

兩台機器；工作 A 要 4 單位、B 要 1；B 等 A 做滿 3 單位才能啟動。原排程 A=[0,4)、B=[3,4)，所以 (C_0=4\)。

事件 (t_0=1\)：A 已做 1，後面要等材料到 5 才能繼續。右移後 A=[0,1)+[5,8)，B=[7,8)，所以 (C_{\rm shift}=8\)。

| 交期設定 | 決策 |
|---|---|
| D=4、tau=4，B=8 | 合法且等於 B，直接接受，不解 DP／LP |
| D=4、tau=3，B=7 | 觸發 recovery；本例 LB=8，可認證趕不上 |

注意 B 不能照原先的 3 啟動：當時 A 只有實際加工 1，不是 3。程式測試 `test_projection_progress` 專門防止這個錯誤回歸。

## 10. 單調性還剩下什麼？【研究延伸】

同一時刻、同一歷史、同一 checkpoint 權限下：

\[
R^{d'}\ge R^d\Rightarrow
x^{d'}\ge x^d,
\qquad\mathcal F_{d'}\subseteq\mathcal F_d\Rightarrow OPT_{d'}\ge OPT_d.
\]

projection 的確單調；同模型 OPT 也單調。**任意重新跑的 greedy 結果不一定單調**，因為延遲可能碰巧改變錯誤決策順序。這項 0928 修正完整保留。

## 11. 本次證據支持到哪裡？

主實驗 432 個交期情境，右移直接接受 156；gated greedy/DP/LP 都準時 200。額外 80 個 full-DP 案例，DP 改善 incumbent 16 例、LP-assisted 改善 7 例，全數都有 MILP 最優認證。

這支持『先測試容錯再決定是否修復』的實作可行性，尚未證明普遍最強 recovery 或真實工廠效益。未新增無條件 (2-1/m+\varepsilon\) 宣告；已接受的右移不一定 work-conserving，不能硬套 list-scheduling bound。

完整實驗設定、負面結果與限制在 `EXPERIMENTS_zhTW.md`。IEEE 論文含正式模型、right-shift／trigger／DP correctness 證明、pseudocode、complexity 和舊近似界的適用條件。
