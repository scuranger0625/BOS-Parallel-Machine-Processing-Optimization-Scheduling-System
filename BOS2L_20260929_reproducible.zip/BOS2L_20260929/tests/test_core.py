import unittest,random
from unittest.mock import patch
from src.bos_core import Instance,Edge,simulate,Schedule
from src.recovery import build_recovery,validate_recovery
from src.tolerance import right_shift,controller,segment_dp
from src.optimization import optimize

class Core(unittest.TestCase):
 def example(self):
  i=Instance((4,1),(0,0),(Edge(0,1,3),),2)
  s=simulate(i,'bos',record_decisions=False)
  return build_recovery(i,s,1,{0:(1,5)})
 def test_projection_progress(self):
  r=self.example();s,d=right_shift(r)
  self.assertEqual(r.tau+s.makespan,8)
  validate_recovery(r,s)
  # successor cannot start at nominal 3 while predecessor paused at progress 1
  self.assertGreaterEqual(r.tau+s.start[-1],7)
 def test_acceptance_no_optimization(self):
  r=self.example()
  with patch('src.tolerance.optimize',side_effect=AssertionError('must not run')),patch('src.tolerance.local_dp',side_effect=AssertionError('must not run')):
   for method in ('greedy','dp','lp'):
    s,info=controller(r,8,method)
    self.assertEqual(info['status'],'accepted_shift')
    self.assertFalse(info['trigger'])
 def test_operational_constraint(self):
  r=self.example();s,info=controller(r,100,'greedy',operational=lambda x:False)
  self.assertTrue(info['trigger']);self.assertIsNone(s)
  self.assertEqual(info['status'],'no_operational_candidate')
 def test_uniform_dominates_projection(self):
  r=self.example();s,d=right_shift(r);u,_=right_shift(r,True)
  self.assertLessEqual(s.makespan,u.makespan)
  self.assertEqual(r.nominal.makespan+d,r.tau+u.makespan)
 def test_zero_lag(self):
  i=Instance((2,2),(0,0),(Edge(0,1,0),),2)
  inc=simulate(i,'bos',record_decisions=False);s,info=segment_dp(i,inc)
  self.assertEqual(s.makespan,2)
 def test_dp_milp_random(self):
  for seed in range(24):
   rng=random.Random(seed);p=tuple(rng.randint(1,4) for _ in range(5))
   edges=tuple(Edge(u,v,rng.randint(0,p[u])) for u in range(5) for v in range(u+1,5) if rng.random()<.25)
   i=Instance(p,tuple(rng.randint(0,3) for _ in p),edges,2)
   inc=simulate(i,'bos',record_decisions=False);s,di=segment_dp(i,inc,200000)
   ei,exact=optimize(i,True,15)
   self.assertEqual(ei['status'],0)
   self.assertIn(di['status'],('optimal','bound_certified'))
   self.assertEqual(s.makespan,exact.makespan)
 def test_budget_not_optimal(self):
  for seed in range(100):
   rng=random.Random(seed);p=tuple(rng.randint(1,6) for _ in range(7))
   i=Instance(p,(0,)*7,(),2);inc=simulate(i,'bos',record_decisions=False)
   s,info=segment_dp(i,inc,1)
   if info['status']=='state_budget':break
  self.assertEqual(info['status'],'state_budget')

if __name__=='__main__': unittest.main(verbosity=2)
