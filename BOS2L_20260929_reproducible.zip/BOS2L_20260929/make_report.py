from pathlib import Path
import json,csv
root=Path(__file__).parent;s=json.loads((root/'results/summary.json').read_text());stress=json.loads((root/'results/stress_summary.json').read_text())
labels={'BOS_frozen':'Frozen BOS','right_shift_only':'Right shift only','always_greedy':'Always greedy','greedy_recovery':'Gated greedy','DP_recovery':'Gated local DP','LP_assisted':'Gated LP-assisted'}
tex=r'''\subsection{Primary Results}
\begin{table}[t]\centering
\caption{Primary suite: 432 delivery scenarios. Illegal frozen plans receive no completion credit.}
\label{tab:main}
\begin{tabular}{lrrrr}
\toprule Policy & On time & Calls & Mean $C$ & Tardiness\\\midrule
'''
for p,l in labels.items():
 r=s[p];C='--' if r['mean_C'] is None else f"{r['mean_C']:.3f}";t='--' if r['mean_tardiness'] is None else f"{r['mean_tardiness']:.3f}"
 tex+=f"{l} & {r['on_time']} & {r['recovery_calls']} & {C} & {t}"+r'\\'+'\n'
tex+=r'''\bottomrule\end{tabular}\end{table}
Projection accepts 156/432 scenarios (36.11\%) without any recovery. Gated greedy raises on-time delivery from 156 to 200 cases, recovering 44 of 276 triggered cases. Gated local DP and LP-assisted recovery reach the same on-time count. Their lack of additional deadline successes is a negative result, not an omitted outcome. LP improves mean completion by only 0.0023 time units over gated greedy in this suite. All feasible policies pass physical validation; all frozen unmodified plans fail because the generator deliberately places an effective late material gate.

Always-greedy has mean completion 16.250 versus 16.637 for gated greedy. This is expected: the latter retains acceptable plans even when a faster alternative exists. Gated greedy reduces mean segment start deviation from 19.708 to 15.812 and mean reassigned segments from 3.965 to 1.752. Right shift has zero reassignment but larger mean deviation (17.896) because long delays propagate. Thus stability depends on the metric; shift does not minimize every disturbance measure.

The main DP status counts are 71 full bound certificates, one full searched optimum, 46 local bound certificates, and 26 local searched optima. A local status certifies only the conservative suffix subproblem. All 24 sampled exact MILP solves terminate optimally. No LP or oracle failure is hidden in these totals.

\subsection{Harder Small-Instance Suite}
A separate fixed sweep uses seeds 928100--928179, seven jobs with processing times 2--7, two or three machines, forward-edge probability 0.10, and lags sampled from zero, half-processing, or full-processing time. Revelation is at time one; the chosen job receives a gate at its current progress, delayed by one to four time units after the later of revelation or nominal gate time. All 80 cases are retained. This suite uses full residual DP with a 30,000-state cap rather than the primary suite's local window; its results are not pooled with the policy table.

DP improves the best shift/greedy incumbent in 16/80 cases; LP-assisted selection improves it in 7/80. All 80 DP results match independently solved MILP optima: 44 terminate at an initial bound certificate and 36 require search. The maximum inserted-state count is 7,608. No case reaches the configured cap, so these tests do not establish scalability to larger residual graphs. A separate forced-budget unit test verifies that stopping early does not report optimality. Raw unguarded LP-list outcomes, including losses, remain in the stress CSV.
'''
(root/'paper/results_generated.tex').write_text(tex)
md='''# BOS-2L 20260929 實驗紀錄

這份紀錄由 `make_report.py` 讀取原始執行結果產生。所有時間皆為合成加工時間單位；不是實際工廠分鐘。

## 主實驗

144 個事件 × 3 個容許交期 = 432 個情境。每個情境比較六種策略，共 2,592 筆 policy rows。

| 方法 | 合法筆數 | 準時筆數 | Recovery 次數 | 平均完工 | 平均逾期 | 平均開始偏移 | 平均片段換機 |
|---|---:|---:|---:|---:|---:|---:|---:|
'''
for p,l in labels.items():
 r=s[p];nums=[r['feasible'],r['on_time'],r['recovery_calls']]+['—' if r[k] is None else f'{r[k]:.3f}' for k in ('mean_C','mean_tardiness','mean_deviation','mean_reassigned')]
 md+='| '+l+' | '+' | '.join(map(str,nums))+' |\n'
md+='''
Frozen BOS 因為有效物料延遲而不合法，不可拿原來的短 makespan 當成優勢。Always greedy 每次事件都重排。三個 gated 方法只有右移不合交期才介入。

右移直接接受 156/432，避免 36.11% recovery；有 276 個觸發情境，greedy 救回其中 44 個，三個 gated 方法最終都準時 200 個。這不是 DP/LP 的全面勝利；主實驗的 DP 大多被初始下界或局部窗口限制主導。

平均開始偏移定義：所有 residual segment 對原參考開始時間的絕對差加總。換機數是片段與原 machine label 不同的個數；未解 machine relabeling 最小化問題，不代表最少換機成本。

## 補充小型搜尋實驗

80 個預先定義 seeds，沒有剔除 ties 或 loss。與主實驗不同，使用 full residual DP，最多 30,000 states；不能把這個 DP 的成績直接當成七節點 local DP 成績。

'''
md+=f"- DP 改善 shift/greedy 最佳候選：{stress['dp_improves_incumbent']}/80。\n- LP-assisted 改善相同候選：{stress['lp_improves_incumbent']}/80。\n- MILP optimal：{stress['exact_optimal']}/80；DP 全數吻合。\n- DP 初始 bound 認證 44 例、實際搜尋認證 36 例。\n- 最大 state 數 {stress['max_states']}；本次最大 DP 秒數 {stress['max_seconds']:.6f}。\n"
md+='''
## 可重現設定與公平性

- 主實驗 n={6,14}、m={2,3}、alpha={0,0.75}、seed=0..5、delay={2,6,12}、tau={0,2,6}。確切 PRNG seed 見程式 `generate()`。
- 每個事件固定同一 nominal BOS prefix、物料 gate、checkpoint 與機器許可。只有比較策略不同。
- 主實驗 DP window=7、state cap=12,000；補充 full DP cap=30,000。不同計算預算單獨報告。
- LP/DP 候選跨三個交期快取。每列 seconds 是實測 component cost 加總，接受的決策不計入 solver cost；不宣稱部署端到端 latency。
- post-hoc LP/MILP 認證不算進接受分支。程式測試會確認 controller 接受時不呼叫 optimize/local_dp。
- 同一 graph/event 的不同 delay、slack 並非獨立樣本，因此未報未分群的 p-value 或信賴區間。
- 沒有公開 benchmark／真實 production trace，不能宣稱產業泛化或普遍 dominance。

## 檔案對照

| 檔案 | 內容 |
|---|---|
| results/raw.csv | 2,592 筆 policy 比較、界限、交期、變動、component runtime |
| results/certificates.jsonl | 144 個完整輸入、prefix、gate、residual、候選排程、LP/MILP status |
| results/stress.csv | 80 個 full-DP 比較，包括 raw LP-list |
| results/stress_certificates.jsonl | 補充實驗原始排程與 solver records |
| results/run.log / stress.log | 逐例執行輸出 |
| results/tests.log | 邊界案例與 24 個 DP–MILP randomized comparisons |
| results/verification.json | 重新讀取全部排程後的驗證結果 |
| results/environment.json | Python / NumPy / SciPy 與平台版本 |

所有新數字來自這次實際執行；0915、0928 歷史數字沒有混入新統計。
'''
(root/'docs/EXPERIMENTS_zhTW.md').write_text(md)
