# 來源整併與修正紀錄

## 讀取來源

- 0915 可重現專案：`BOS_20260915_reproducible_project.zip`，含模型、分析、REVIEW_0914、bos_core、exact_solver 與 experiments。
- 0928 LP／IEEE：`BOS_20260928_reproducible_project.zip`，核對 recovery.py、optimization.py、budget.tex、model 與逐例紀錄格式。
- 0928 DP：`BOS2L_DP_20260928_reproducible.zip`，核對 dp_scheduler.py、FORMULAS_ZH、preemption 與 state dominance 假設。
- 使用者 20260929 的 tolerance-first 新規格為本次控制流程的主準則。

## 新增與保留

| 項目 | 決策 |
|---|---|
| BOS bottleneck | 保留 singleton p_i 與 bounded-overlap start lag |
| 部分齊套 | 保留所有前驅各自過 gate 的 AND；未改成 OR |
| 歷史 | 事件前實際工作不得右移或重做 |
| running job | 明確允許事件 checkpoint 暫停；非中斷現場需另建 reservation model |
| shift | 新增 reference floors，避免 forward propagation 意外左移 |
| acceptance | 明確先判斷可交期；接受時不呼叫 recovery solver |
| DP | 改為 running segment 必須繼續、以 (t,q) 狀態；不沿用任意中斷模型 OPT |
| LP | 保留 expected-start priority list decoding；不獨立四捨五入 starts |
| 上界 | shift envelope 與 best feasible incumbent 分開 |
| trigger | 政策需要修復不等於交期無解 |
| 舊近似界 | 保留 bounded-lag work-conserving 的條件式推導；不套到接受的非 work-conserving shift |
| 實驗 | 新主實驗與 stress 分列；舊結果未混入 |

## 刻意未宣稱

- LP rounding 必然勝過 greedy。
- local DP 等於全域 OPT。
- 有 state transition／單調性就能多項式解 NP-hard 排程。
- 右移、反應式排程、slack 本身是新發明。
- 任意機器故障、切換成本、no-wait 或多人為操作限制已由本次定理涵蓋。

## 相關文獻查核

- Vieira, Herrmann, Lin (2003), Journal of Scheduling 6, 39–62，DOI 10.1023/A:1022235519958。期刊原頁核對題名、作者、頁碼及 framework 定位。
- Subramaniam, Raheja, Reddy (2005), International Journal of Production Research 43(1), 1–23，DOI 10.1080/0020754042000270412。出版者頁面核對作者與 right-shift repair 背景；未假稱已重現其 mAOR 實驗。

本次英文稿與原作者名稱沿用既有稿件的 Chen-Hong；沒有自行改寫姓名拼音。
