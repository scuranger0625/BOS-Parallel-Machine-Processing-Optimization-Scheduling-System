import os,sys,subprocess
from pathlib import Path
root=Path(__file__).parent
env=dict(os.environ);env.setdefault('OPENBLAS_NUM_THREADS','1')
steps=[('run.log',['run_experiments.py']),('stress.log',['run_stress.py']),('tests.log',['-m','unittest','discover','-s','tests','-v']),('verification.json',['verify_results.py']),('report_build.log',['make_report.py'])]
for log,args in steps:
 print('Running',args,flush=True)
 with (root/'results'/log).open('w') as f:
  subprocess.run([sys.executable,*args],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
print('Completed. See results/ and docs/EXPERIMENTS_zhTW.md')
