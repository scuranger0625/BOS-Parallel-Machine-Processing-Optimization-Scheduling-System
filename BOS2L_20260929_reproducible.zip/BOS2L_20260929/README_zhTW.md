# BOS-2L：Tolerance-Preserving Right Shift（20260929）

本版以 0915 BOS、0928 checkpoint LP 與 DP 研究版本整併，採「Delay → Right Shift → Acceptance Test → Recovery only if necessary」。所有論文新數字皆有原始輸入與排程紀錄。

## 先讀哪裡

1. `docs/FORMULAS_zhTW.md`：公式、證明直覺、單一一致例子、舊錯誤防回歸。
2. `paper/BOS2L_20260929.pdf`：IEEE 雙欄英文研究稿，含完整定理、演算法、複雜度與限制。
3. `docs/EXPERIMENTS_zhTW.md`：主要／補充實驗與負面結果。
4. `src/tolerance.py`：新右移、接受決策、DP 與 LP 輔助入口。

## 安裝和重跑

Python 3.11 以上，依 `results/environment.json` 為本次實測版本。

```bash
python -m pip install -r requirements.txt
python run_all.py
```

`run_all.py` 會重跑主實驗、補充實驗、測試、逐例驗證並更新表格與導讀實驗數字。一般電腦執行時間會不同。固定 RNG seeds 可重現排程品質；runtime 不是固定常數。HiGHS 的數值精度／版本可能影響 ties 或分支流程。

編譯論文（需安裝 TeX Live 的 IEEE/amsmath 等套件；本包已帶 IEEEtran.cls 與 algorithm 樣式）：

```bash
python build_paper.py
```

## 程式模組對照

| 程式 | 作用 |
|---|---|
| src/bos_core.py | 繼承 0928 的 BOS 與同 timestamp closure；0915 模型語義保留 |
| src/recovery.py | 繼承 checkpoint 切分與獨立進度驗證；移除舊立即 recovery 入口 |
| src/optimization.py | 連續 LP / binary MILP / expected-start list decoder |
| src/tolerance.py | 新增 uniform / forward projection、acceptance、guarded recovery、segment DP / local DP |
| run_experiments.py | 144 events、432 budgets、6 policies，完整 logs 和 certificates |
| run_stress.py | 80 個 full-DP stress cases，全部 MILP 核對 |
| verify_results.py | 重新讀取 certificates，重建物理限制與 policy acceptance |
| tests/test_core.py | 7 類測試，其中含 24 個隨機 DP–MILP 對照 |

## 呼叫決策入口

```python
from src.bos_core import Instance, Edge, simulate
from src.recovery import build_recovery
from src.tolerance import controller

inst = Instance((4, 1), (0, 0), (Edge(0, 1, 3),), 2)
nominal = simulate(inst, 'bos', record_decisions=False)
rec = build_recovery(inst, nominal, 1, {0: (1, 5)})
schedule, info = controller(rec, deadline=8, method='dp')
assert info['status'] == 'accepted_shift'  # 完全不呼叫 DP
print(rec.tau + schedule.makespan, info)
```

Residual schedule 是相對事件時刻；`rec.tau + schedule.makespan` 才是絕對完工。程式沿用舊 `Recovery.tau` 欄位表示 revelation time；**論文改用 (t_0)**，論文中的 (\tau) 專指 deadline allowance。這項歷史欄位命名差異不改變數值語義。

`operational` 可提供額外排程 predicate。所有候選均被過濾；若全不合法，回傳 `None, no_operational_candidate`。這不等於現有 solver 支援任意 operational constraints 的最佳化。主實驗只包含論文明列的模型。

## 保證與限制

- segment 內非中斷；checkpoint 可暫停／遷移且成本為零。
- 相同機器，固定事件前歷史；不允許解法回去改寫 history。
- exact DP 只有 full search 或 bound 認證才是 global checkpoint optimum；local optimum 不等於 global optimum。
- LP 不成功時不使用未認證 objective 作為下界，仍保留合法備援。
- 缺少真實／公開 benchmark；新穎性和實務成本模型仍待投稿前補強。
- 不宣稱新的無條件 (2-1/m+\varepsilon)、FPTAS 或解決一般 NP-hard scheduling。

原始紀錄位於 results；來源沿革與 checksum 位於 provenance 與 MANIFEST_SHA256.json。
