"""Predeclared harder small-instance sweep, including every seed and failure."""
import json,random,time,csv
from pathlib import Path
from dataclasses import asdict
from src.bos_core import Instance,Edge,simulate,instance_to_dict,lower_bound
from src.recovery import build_recovery,validate_recovery
from src.tolerance import right_shift,segment_dp
from src.optimization import optimize
out=Path(__file__).parent/'results';rows=[];certs=[]
for seed in range(80):
 rng=random.Random(928100+seed);n=7;m=2+seed%2
 p=tuple(rng.randint(2,7) for _ in range(n))
 edges=tuple(Edge(u,v,rng.choice([0,p[u]//2,p[u]])) for u in range(n) for v in range(u+1,n) if rng.random()<.10)
 i=Instance(p,(0,)*n,edges,m,'stress',str(seed));nom=simulate(i,'bos',record_decisions=False);t0=1
 j=seed%n;g=min(p[j]-1,max(0,t0-nom.start[j]));arrival=max(t0,nom.start[j]+g)+1+seed%4
 rec=build_recovery(i,nom,t0,{j:(g,arrival)})
 shift,_=right_shift(rec);greedy=simulate(rec.residual,'bos',record_decisions=False);inc=min([shift,greedy],key=lambda s:s.makespan)
 dp,di=segment_dp(rec.residual,inc,30000)
 li,lp=optimize(rec.residual,False,10);ei,exact=optimize(rec.residual,True,10)
 for s in (dp,greedy,shift,lp,exact):
  if s is not None:validate_recovery(rec,s)
 if exact is not None and di['status'] in ('optimal','bound_certified'):assert dp.makespan==exact.makespan
 rows.append(dict(seed=seed,n_segments=rec.residual.n,shift=t0+shift.makespan,greedy=t0+greedy.makespan,dp=t0+dp.makespan,lp_port=t0+min(inc.makespan,lp.makespan if lp else inc.makespan),lp_raw=t0+lp.makespan if lp else '',opt=t0+exact.makespan if exact else '',dp_status=di['status'],dp_states=di['states'],dp_seconds=di['seconds'],lp_status=li['status'],exact_status=ei['status']))
 certs.append(dict(seed=seed,instance=instance_to_dict(i),nominal=asdict(nom),t0=t0,gates={j:(g,arrival)},residual=instance_to_dict(rec.residual),dp_info=di,lp_info=li,exact_info=ei,schedules={k:asdict(s) if s else None for k,s in [('shift',shift),('greedy',greedy),('dp',dp),('lp',lp),('exact',exact)]}))
 print(rows[-1],flush=True)
with (out/'stress.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(out/'stress_certificates.jsonl').write_text(''.join(json.dumps(c)+'\n' for c in certs))
s={'cases':80,'dp_status':{s:sum(r['dp_status']==s for r in rows) for s in set(r['dp_status'] for r in rows)},'dp_improves_greedy':sum(r['dp']<r['greedy'] for r in rows),'dp_improves_incumbent':sum(r['dp']<min(r['greedy'],r['shift']) for r in rows),'lp_improves_incumbent':sum(r['lp_port']<min(r['greedy'],r['shift']) for r in rows),'exact_optimal':sum(r['exact_status']==0 for r in rows),'max_states':max(r['dp_states'] for r in rows),'max_seconds':max(r['dp_seconds'] for r in rows)}
(out/'stress_summary.json').write_text(json.dumps(s,indent=2));print(s)
