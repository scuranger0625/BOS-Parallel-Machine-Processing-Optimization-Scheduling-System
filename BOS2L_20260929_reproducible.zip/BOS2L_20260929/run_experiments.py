"""Run deterministic paired synthetic experiments; no hidden data downloads."""
import csv,json,time,platform,sys,random,hashlib
from pathlib import Path
from dataclasses import asdict
import numpy as np, scipy
from src.bos_core import Instance,Edge,simulate,instance_to_dict,lower_bound
from src.recovery import build_recovery,validate_recovery
from src.tolerance import right_shift,reference,local_dp
from src.optimization import optimize
OUT=Path(__file__).parent/'results';OUT.mkdir(exist_ok=True)

def timed(fn):
 t=time.perf_counter();v=fn();return v,time.perf_counter()-t

def generate(n,m,alpha,seed):
 rng=random.Random(290000+n*1000+m*100+seed)
 p=tuple(rng.randint(1,4) for _ in range(n));edges=[]
 for u in range(n):
  for v in range(u+1,n):
   if rng.random()<.18 or (seed%2 and v==n-1):edges.append(Edge(u,v,p[u]-int(alpha*p[u])))
 return Instance(p,(0,)*n,tuple(edges),m,'merge' if seed%2 else 'random',f'n{n}-m{m}-a{alpha}-s{seed}')

rows=[]; events=[]; failures=[]; checks=0; started=time.perf_counter()
for n in (6,14):
 for m in (2,3):
  for alpha in (0,.75):
   for seed in range(6):
    inst=generate(n,m,alpha,seed);nom=simulate(inst,'bos',record_decisions=False);t0=max(1,nom.makespan//3)
    pending=[j for j in range(n) if nom.completion[j]>t0]
    j=pending[seed%len(pending)];q=max(0,t0-nom.start[j]);g=min(inst.p[j]-1,q+(seed%2))
    for delay in (2,6,12):
     arrival=max(t0,nom.start[j]+g)+delay
     rec=build_recovery(inst,nom,t0,{j:(g,arrival)})
     (shift,delta),ts=timed(lambda:right_shift(rec))
     uniform,_=right_shift(rec,True)
     greedy,tg=timed(lambda:simulate(rec.residual,'bos',record_decisions=False))
     inc=min([shift,greedy],key=lambda s:s.makespan)
     (dp,di),td=timed(lambda:local_dp(rec.residual,inc,max_states=12000))
     (li,lp),tl=timed(lambda:optimize(rec.residual,False,10))
     if lp is None:failures.append({'id':inst.instance_id,'delay':delay,'lp':li})
     lp_port=min([s for s in (shift,greedy,lp) if s is not None],key=lambda s:s.makespan)
     dp_port=min([shift,greedy,dp],key=lambda s:s.makespan)
     gr_port=min([shift,greedy],key=lambda s:s.makespan)
     lb=t0+max(lower_bound(rec.residual),li['objective'] if li['status']==0 else 0)
     exactinfo=None;exact=None
     if n==6 and seed<2:
      exactinfo,exact=optimize(rec.residual,True,15)
      if exact is None:failures.append({'id':inst.instance_id,'delay':delay,'exact':exactinfo})
      else:
       assert lb<=t0+exact.makespan+1e-5
       if rec.residual.n<=7 and di['status'] in ('optimal','bound_certified'):assert dp.makespan==exact.makespan
     schedules={'projection':shift,'uniform':uniform,'greedy_raw':greedy,'dp_raw':dp,'lp_raw':lp,'exact':exact}
     stats={}
     for name,s in schedules.items():
      if s is not None:
       stats[name]=validate_recovery(rec,s);checks+=1
       assert lb<=t0+s.makespan+1e-5
     assert shift.makespan<=uniform.makespan
     event_id=inst.instance_id+f'-d{delay}'
     events.append(dict(id=event_id,instance=instance_to_dict(inst),nominal=asdict(nom),t0=t0,gates={j:(g,arrival)},segments=rec.segments,residual=instance_to_dict(rec.residual),reference=reference(rec),delta=delta,lb=lb,dp_info=di,lp_info=li,exact_info=exactinfo,schedules={k:asdict(v) if v else None for k,v in schedules.items()},physical_metrics=stats))
     for slack in (0,2,6):
      B=nom.makespan+slack; trigger=t0+shift.makespan>B
      policies={'BOS_frozen':(None,0),'right_shift_only':(shift,ts),'always_greedy':(greedy,tg),'greedy_recovery':(gr_port if trigger else shift,ts+(tg if trigger else 0)),'DP_recovery':(dp_port if trigger else shift,ts+(tg+td if trigger else 0)),'LP_assisted':(lp_port if trigger else shift,ts+(tg+tl if trigger else 0))}
      # The frozen nominal schedule is feasible exactly when the delayed gate
      # would already be reached at/after its new arrival. Here delay>0, false.
      frozen_valid=nom.start[j]+g>=arrival
      for policy,(s,cost) in policies.items():
       C=nom.makespan if s is None else t0+s.makespan
       valid=frozen_valid if s is None else True
       b=reference(rec)
       movement=0 if s is None else sum(abs(s.start[k]-b[k]) for k in range(rec.residual.n))
       changed_m=0 if s is None else sum(s.machine[k]!=nom.machine[rec.segments[k][0]] for k in range(rec.residual.n))
       rows.append(dict(event_id=event_id,n=n,m=m,alpha=alpha,seed=seed,delay=delay,slack=slack,segments=rec.residual.n,policy=policy,C0=nom.makespan,B=B,C=C,feasible=int(valid),accepted=int(valid and C<=B),trigger=int(trigger),recovery_called=int(policy=='always_greedy' or (policy in ('greedy_recovery','DP_recovery','LP_assisted') and trigger)),tardiness=max(0,C-B) if valid else '',start_deviation=movement,reassigned_segments=changed_m,seconds=cost,LB=lb,OPT=t0+exact.makespan if exact else '',dp_status=di['status']))
     print(event_id,'segments',rec.residual.n,'shift',t0+shift.makespan,'greedy',t0+greedy.makespan,'dp',di['status'],flush=True)
with (OUT/'raw.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (OUT/'certificates.jsonl').open('w') as f:
 for e in events:f.write(json.dumps(e)+'\n')
summary={}
for policy in sorted(set(r['policy'] for r in rows)):
 rr=[r for r in rows if r['policy']==policy];valid=[r for r in rr if r['feasible']]
 summary[policy]={'cases':len(rr),'feasible':len(valid),'on_time':sum(r['accepted'] for r in rr),'recovery_calls':sum(r['recovery_called'] for r in rr),'mean_C':float(np.mean([r['C'] for r in valid])) if valid else None,'mean_tardiness':float(np.mean([r['tardiness'] for r in valid])) if valid else None,'mean_deviation':float(np.mean([r['start_deviation'] for r in valid])) if valid else None,'mean_reassigned':float(np.mean([r['reassigned_segments'] for r in valid])) if valid else None,'mean_component_ms':1000*float(np.mean([r['seconds'] for r in rr]))}
summary['audit']={'events':len(events),'deadline_cases':len(events)*3,'schedule_checks':checks,'failures':failures,'exact_optimal':sum(e['exact_info'] is not None and e['exact_info']['status']==0 for e in events),'dp_status':{s:sum(e['dp_info']['status']==s for e in events) for s in set(e['dp_info']['status'] for e in events)},'seconds':time.perf_counter()-started}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2));(OUT/'environment.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__},indent=2));print(json.dumps(summary,indent=2))
