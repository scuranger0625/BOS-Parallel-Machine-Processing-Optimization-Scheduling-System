"""Replay every stored schedule, independent of optimization runs."""
import json,csv
from pathlib import Path
from src.bos_core import instance_from_dict,Schedule
from src.recovery import build_recovery,validate_recovery
from src.tolerance import right_shift
root=Path(__file__).parent;out=root/'results';count=0
for fn in ('certificates.jsonl','stress_certificates.jsonl'):
 for line in (out/fn).read_text().splitlines():
  e=json.loads(line);i=instance_from_dict(e['instance']);nom=Schedule(**e['nominal'])
  gates={int(j):tuple(v) for j,v in e['gates'].items()};r=build_recovery(i,nom,e['t0'],gates)
  shift,delta=right_shift(r)
  for name,obj in e['schedules'].items():
   if obj is None:continue
   s=Schedule(**obj);validate_recovery(r,s);count+=1
   if 'lb' in e:assert e['lb']<=r.tau+s.makespan+1e-5
  if 'projection' in e['schedules']:
   assert list(shift.start)==e['schedules']['projection']['start']
   assert r.tau+shift.makespan<=nom.makespan+delta
rows=list(csv.DictReader((out/'raw.csv').open()))
for r in rows:
 C=int(r['C']);B=int(r['B']);valid=int(r['feasible'])
 assert int(r['accepted'])==int(valid and C<=B)
 if r['policy'] in ('greedy_recovery','DP_recovery','LP_assisted'):
  assert r['trigger']==r['recovery_called']
  if int(r['accepted'])==0:assert int(r['trigger'])==1
print(json.dumps({'replayed_schedules':count,'checked_policy_rows':len(rows),'violations':0},indent=2))
