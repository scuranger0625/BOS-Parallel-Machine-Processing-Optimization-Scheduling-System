"""Tolerance-first BOS-2L. Absolute deadlines; relative residual schedules.
Identical machines, integer checkpoint segments, no setup or switching cost.
"""
from dataclasses import replace
from itertools import combinations
import time
from .bos_core import Instance, Edge, Schedule, simulate, lower_bound
from .optimization import optimize, schedule_from_starts
from .recovery import validate_recovery


def reference(rec):
    return tuple(max(rec.tau, rec.nominal.start[j]+a)-rec.tau for j,a,b in rec.segments)


def right_shift(rec, uniform=False):
    """Monotone projection with baseline floors and fixed machine order."""
    i=rec.residual; b=reference(rec)
    machines=tuple(rec.nominal.machine[j] for j,a,c in rec.segments)
    arcs={(e.u,e.v):e.lag for e in i.edges}
    for m in range(i.machines):
        row=sorted((k for k in range(i.n) if machines[k]==m),key=lambda k:(b[k],k))
        for u,v in zip(row,row[1:]): arcs[u,v]=max(arcs.get((u,v),0),i.p[u])
    aug=Instance(i.p,i.release,tuple(Edge(u,v,l) for (u,v),l in arcs.items()),i.machines)
    delta=max([0]+[i.release[k]-b[k] for k in range(i.n)])
    if uniform: starts=[x+delta for x in b]
    else:
        starts=[max(b[k],i.release[k]) for k in range(i.n)]
        for v in aug.topological_order:
            for u,l in aug.predecessors[v]: starts[v]=max(starts[v],starts[u]+l)
    ends=tuple(starts[k]+i.p[k] for k in range(i.n))
    topo={v:k for k,v in enumerate(aug.topological_order)}
    s=Schedule('uniform' if uniform else 'projection',tuple(starts),machines,ends,max(ends),tuple(sorted(range(i.n),key=lambda k:(starts[k],topo[k]))),())
    validate_recovery(rec,s)
    assert all(starts[k]>=b[k] for k in range(i.n))
    assert rec.tau+s.makespan<=rec.nominal.makespan+delta
    return s,delta


def segment_dp(inst, incumbent, max_states=80000):
    """Layered Bellman DP: running segments MUST continue. Empty actions allowed.
    Full completion = exact integer checkpoint optimum; state cap = feasible
    incumbent plus analytic lower bound, never an optimality claim.
    """
    st=time.perf_counter(); p=inst.p; n=inst.n; H=incumbent.makespan
    initial=(0,)*n; layer={initial:()}; count=1
    lb=lower_bound(inst)
    if H<=lb+1e-8:
        return incumbent,dict(status='bound_certified',states=count,lb=lb,seconds=time.perf_counter()-st)
    for t in range(H):
        nxt={}
        for q,path in layer.items():
            mandatory=tuple(k for k in range(n) if 0<q[k]<p[k])
            candidates=[k for k in range(n) if q[k]==0 and inst.release[k]<=t and all(q[u]>=l for u,l in inst.predecessors[k])]
            for size in range(min(inst.machines-len(mandatory),len(candidates)),-1,-1):
                for chosen in combinations(candidates,size):
                    a=mandatory+chosen; aset=set(a)
                    if any(q[v]==0 and v in aset and l==0 and q[u]==0 and u not in aset for u,v,l in ((e.u,e.v,e.lag) for e in inst.edges)): continue
                    q2=tuple(q[k]+int(k in aset) for k in range(n))
                    newpath=path+(tuple(sorted(a)),)
                    if q2==p:
                        starts=tuple(next(tt for tt,act in enumerate(newpath) if k in act) for k in range(n))
                        s=schedule_from_starts(inst,starts,'dp')
                        return s,dict(status='optimal',states=count,lb=s.makespan,seconds=time.perf_counter()-st)
                    rem=sum(p[k]-q2[k] for k in range(n))
                    # Strict-improvement pruning: incumbent already feasible.
                    bound=t+1+max((rem+inst.machines-1)//inst.machines,max(p[k]-q2[k] for k in range(n)))
                    if bound>=H: continue
                    if q2 not in nxt:
                        nxt[q2]=newpath;count+=1
                        if count>max_states:
                            return incumbent,dict(status='state_budget',states=count,lb=lb,seconds=time.perf_counter()-st)
        layer=nxt
        if not layer: break
    return incumbent,dict(status='optimal',states=count,lb=H,seconds=time.perf_counter()-st)


def local_dp(inst, incumbent, window=7, max_states=80000):
    """All nodes for small instances; otherwise a topological suffix window.
    Outside-window segments keep the incumbent. Window starts after all frozen
    future segments complete, a conservative restriction with exact boundary.
    """
    if inst.n<=window: return segment_dp(inst,incumbent,max_states)
    selected=tuple(inst.topological_order[-window:]); keep=set(selected)
    fixed=[u for u in range(inst.n) if u not in keep]
    cut=max(incumbent.completion[u] for u in fixed)
    pos={u:k for k,u in enumerate(selected)}
    rel=tuple(max(cut,inst.release[u],max([0]+[incumbent.start[v]+l for v,l in inst.predecessors[u] if v not in keep]))-cut for u in selected)
    sub=Instance(tuple(inst.p[u] for u in selected),rel,tuple(Edge(pos[e.u],pos[e.v],e.lag) for e in inst.edges if e.u in keep and e.v in keep),inst.machines)
    base=simulate(sub,'bos',record_decisions=False)
    sol,info=segment_dp(sub,base,max_states)
    starts=list(incumbent.start);machines=list(incumbent.machine)
    for k,u in enumerate(selected): starts[u]=cut+sol.start[k];machines[u]=sol.machine[k]
    ends=tuple(starts[u]+inst.p[u] for u in range(inst.n))
    topo={v:k for k,v in enumerate(inst.topological_order)}
    cand=Schedule('local_dp',tuple(starts),tuple(machines),ends,max(ends),tuple(sorted(range(inst.n),key=lambda k:(starts[k],topo[k]))),())
    info.update(scope='suffix_window',window=window,cut=cut,lb=lower_bound(inst))
    info['status']='local_'+info['status']
    return (cand if cand.makespan<incumbent.makespan else incumbent),info


def controller(rec, deadline, method='greedy', operational=lambda s:True):
    """No optimization is called on the acceptance path. Failed constraints
    require recovery but candidates are revalidated; infeasibility is explicit.
    """
    st=time.perf_counter();shift,delta=right_shift(rec)
    trigger=rec.tau+shift.makespan>deadline or not operational(shift)
    info={'trigger':trigger,'delta':delta,'lb':rec.tau+lower_bound(rec.residual),'method':method}
    if not trigger:
        info.update(status='accepted_shift',seconds=time.perf_counter()-st)
        return shift,info
    candidates=[shift] if operational(shift) else []
    greedy=simulate(rec.residual,'bos',record_decisions=False)
    if operational(greedy):candidates.append(greedy)
    if method=='dp':
        cand,di=local_dp(rec.residual,min([shift,greedy],key=lambda x:x.makespan))
        info['dp']=di
        if operational(cand):candidates.append(cand)
    elif method=='lp':
        li,cand=optimize(rec.residual,False,10)
        info['lp']=li
        if li['status']==0:info['lb']=max(info['lb'],rec.tau+li['objective'])
        if cand is not None and operational(cand):candidates.append(cand)
    elif method!='greedy':raise ValueError(method)
    for c in candidates:validate_recovery(rec,c)
    if not candidates:
        info.update(status='no_operational_candidate',seconds=time.perf_counter()-st)
        return None,info
    chosen=min(candidates,key=lambda x:x.makespan)
    info.update(status='recovered' if rec.tau+chosen.makespan<=deadline else 'deadline_missed',seconds=time.perf_counter()-st)
    return chosen,info
