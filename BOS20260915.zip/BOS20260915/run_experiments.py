"""Run the reproducible experiment battery used in the 2026-09-15 paper.

Examples
--------
Smoke test (seconds):
    python -m experiments.run_experiments --profile smoke --all

Paper run:
    python -m experiments.run_experiments --profile paper --all

Each phase writes a checkpoint immediately, so a later phase can be rerun without
discarding completed results.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path
import platform
import sys
import time
from typing import Sequence

import matplotlib

matplotlib.use("Agg")
matplotlib.rcParams.update({"pdf.fonttype": 42, "ps.fonttype": 42})
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .bos_core import (
    Instance,
    augmented_dag_diagnostic,
    candidate_set_disagreement,
    instance_to_dict,
    lower_bound,
    path_lower_bounds,
    simulate,
    verify_approximation_bound,
)
from .exact_solver import solve_exact
from .generators import FAMILIES, generate_instance, iter_instances


POLICIES = ("bos", "heft_rank", "grpw", "lpt", "spt", "fifo")
DISPLAY = {
    "bos": "BOS",
    "heft_rank": "HEFT-rank",
    "grpw": "GRPW",
    "lpt": "LPT",
    "spt": "SPT",
    "fifo": "FIFO",
}
COLORS = {
    "bos": "#2166AC",
    "heft_rank": "#D6604D",
    "grpw": "#7B3294",
    "lpt": "#4D9221",
    "spt": "#E08214",
    "fifo": "#777777",
}


@dataclass(frozen=True)
class Profile:
    main_sizes: tuple[int, ...]
    main_machines: tuple[int, ...]
    main_overlaps: tuple[float, ...]
    main_release: tuple[str, ...]
    main_replicates: int
    exact_sizes: tuple[int, ...]
    exact_machines: tuple[int, ...]
    exact_overlaps: tuple[float, ...]
    exact_release: tuple[str, ...]
    exact_replicates: int
    exact_time_limit: float
    case_trials: int
    runtime_sizes: tuple[int, ...]
    runtime_replicates: int


PROFILES = {
    "smoke": Profile(
        main_sizes=(20,),
        main_machines=(2, 4),
        main_overlaps=(0.0, 0.5),
        main_release=("zero", "uniform"),
        main_replicates=2,
        exact_sizes=(7,),
        exact_machines=(2,),
        exact_overlaps=(0.0, 0.6),
        exact_release=("zero",),
        exact_replicates=2,
        exact_time_limit=10.0,
        case_trials=100,
        runtime_sizes=(100, 500),
        runtime_replicates=2,
    ),
    "paper": Profile(
        main_sizes=(50, 100, 250),
        main_machines=(2, 4, 8),
        main_overlaps=(0.0, 0.25, 0.50, 0.75),
        main_release=("zero", "uniform"),
        main_replicates=20,
        exact_sizes=(8, 10),
        exact_machines=(2, 3),
        exact_overlaps=(0.0, 0.50, 0.80),
        exact_release=("zero", "uniform"),
        exact_replicates=6,
        exact_time_limit=20.0,
        case_trials=4000,
        runtime_sizes=(100, 500, 1000, 2500, 5000),
        runtime_replicates=8,
    ),
}


def _mkdirs(root: Path) -> tuple[Path, Path, Path, Path]:
    results = root / "results"
    figures = root / "figures_generated"
    tables = root / "tables_generated"
    cases = root / "results" / "cases"
    for directory in (results, figures, tables, cases):
        directory.mkdir(parents=True, exist_ok=True)
    return results, figures, tables, cases


def _time_schedule(instance: Instance, policy: str):
    started = time.perf_counter_ns()
    schedule = simulate(instance, policy)
    elapsed_ms = (time.perf_counter_ns() - started) / 1_000_000
    verify_approximation_bound(instance, schedule)
    return schedule, elapsed_ms


def run_main(root: Path, profile: Profile) -> pd.DataFrame:
    results, _, _, _ = _mkdirs(root)
    rows: list[dict[str, object]] = []
    total = (
        len(FAMILIES)
        * len(profile.main_sizes)
        * len(profile.main_machines)
        * len(profile.main_overlaps)
        * len(profile.main_release)
        * profile.main_replicates
    )
    started = time.perf_counter()
    for index, instance in enumerate(
        iter_instances(
            sizes=profile.main_sizes,
            machine_counts=profile.main_machines,
            families=FAMILIES,
            overlaps=profile.main_overlaps,
            release_policies=profile.main_release,
            seeds=range(profile.main_replicates),
        ),
        start=1,
    ):
        schedules = {}
        runtimes = {}
        for policy in POLICIES:
            schedules[policy], runtimes[policy] = _time_schedule(instance, policy)
        workload, l_delta, l_release = path_lower_bounds(instance)
        lb = max(workload, l_release)
        overlap_target = float(instance.instance_id.split("-o", 1)[1].split("-", 1)[0])
        release_policy = instance.instance_id.rsplit("-s", 1)[0].rsplit("-", 1)[1]
        bos = schedules["bos"]
        heft = schedules["heft_rank"]
        row: dict[str, object] = {
            "instance_id": instance.instance_id,
            "family": instance.family,
            "n": instance.n,
            "machines": instance.machines,
            "edge_count": len(instance.edges),
            "overlap_target": overlap_target,
            "overlap_actual": instance.overlap_fraction,
            "release_policy": release_policy,
            "seed": int(instance.instance_id.rsplit("-s", 1)[1]),
            "workload_bound": workload,
            "l_delta": l_delta,
            "l_release_delta": l_release,
            "lower_bound": lb,
            "candidate_disagreement": candidate_set_disagreement(instance, bos, heft),
            "bos_advantage_vs_heft_pct": 100.0 * (heft.makespan - bos.makespan) / heft.makespan,
            "fifo_penalty_vs_bos_pct": 100.0 * (schedules["fifo"].makespan - bos.makespan) / bos.makespan,
        }
        for policy in POLICIES:
            if policy != "bos":
                row[f"bos_advantage_vs_{policy}_pct"] = 100.0 * (
                    schedules[policy].makespan - bos.makespan
                ) / schedules[policy].makespan
        zero_release = all(value == 0 for value in instance.release)
        proved_upper = (
            workload + (1.0 - 1.0 / instance.machines) * l_delta
            if zero_release
            else workload + l_release
        )
        row["proved_upper"] = proved_upper
        for policy in POLICIES:
            schedule = schedules[policy]
            row[f"{policy}_makespan"] = schedule.makespan
            row[f"{policy}_gap_lb_pct"] = 100.0 * (schedule.makespan - lb) / lb
            row[f"{policy}_to_lb"] = schedule.makespan / lb
            row[f"{policy}_to_proved_upper"] = schedule.makespan / proved_upper
            row[f"{policy}_runtime_ms"] = runtimes[policy]
        rows.append(row)
        if index % 500 == 0 or index == total:
            print(
                f"main {index}/{total} instances, elapsed={time.perf_counter()-started:.1f}s",
                flush=True,
            )
    frame = pd.DataFrame(rows)
    frame.to_csv(results / "main_raw.csv", index=False)
    return frame


def extend_existing_baselines(root: Path, profile: Profile) -> None:
    """Add newly introduced deterministic policies without resolving the MILPs.

    This is a checkpoint convenience for an existing paper run.  It reconstructs
    every instance from the recorded generator coordinates, reruns all missing
    list policies, and retains only previously certified exact optima.  A clean
    ``--all`` run remains the canonical from-scratch reproduction path.
    """

    results, _, _, _ = _mkdirs(root)
    main_path = results / "main_raw.csv"
    exact_path = results / "exact_raw.csv"
    main = pd.read_csv(main_path)
    exact = pd.read_csv(exact_path)

    for frame_name, frame in (("main", main), ("exact", exact)):
        started = time.perf_counter()
        for position, (index, row) in enumerate(frame.iterrows(), start=1):
            instance = generate_instance(
                n=int(row.n),
                machines=int(row.machines),
                family=str(row.family),
                overlap=float(row.overlap_target),
                release_policy=str(row.release_policy),
                seed=int(row.seed),
            )
            if frame_name == "main":
                proved_upper = float(row.proved_upper)
                lb = float(row.lower_bound)
                bos_makespan = float(row.bos_makespan)
                for policy in POLICIES:
                    makespan_column = f"{policy}_makespan"
                    if makespan_column in frame.columns and not pd.isna(row.get(makespan_column)):
                        continue
                    schedule, elapsed_ms = _time_schedule(instance, policy)
                    frame.loc[index, makespan_column] = schedule.makespan
                    frame.loc[index, f"{policy}_gap_lb_pct"] = 100.0 * (
                        schedule.makespan - lb
                    ) / lb
                    frame.loc[index, f"{policy}_to_lb"] = schedule.makespan / lb
                    frame.loc[index, f"{policy}_to_proved_upper"] = (
                        schedule.makespan / proved_upper
                    )
                    frame.loc[index, f"{policy}_runtime_ms"] = elapsed_ms
                for policy in POLICIES:
                    if policy != "bos":
                        comparator = float(frame.loc[index, f"{policy}_makespan"])
                        frame.loc[index, f"bos_advantage_vs_{policy}_pct"] = 100.0 * (
                            comparator - bos_makespan
                        ) / comparator
            else:
                optimum = float(row.optimum)
                for policy in POLICIES:
                    makespan_column = f"{policy}_makespan"
                    if makespan_column in frame.columns and not pd.isna(row.get(makespan_column)):
                        continue
                    schedule = simulate(instance, policy)
                    frame.loc[index, makespan_column] = schedule.makespan
                    frame.loc[index, f"{policy}_gap_opt_pct"] = 100.0 * (
                        schedule.makespan - optimum
                    ) / optimum
                    frame.loc[index, f"{policy}_optimal"] = int(
                        schedule.makespan == optimum
                    )
            if position % 500 == 0 or position == len(frame):
                print(
                    f"extend {frame_name} {position}/{len(frame)}, "
                    f"elapsed={time.perf_counter()-started:.1f}s",
                    flush=True,
                )

        target = main_path if frame_name == "main" else exact_path
        frame.to_csv(target, index=False)


def run_exact(root: Path, profile: Profile) -> pd.DataFrame:
    results, _, _, _ = _mkdirs(root)
    rows: list[dict[str, object]] = []
    failures: list[dict[str, object]] = []
    total = (
        len(FAMILIES)
        * len(profile.exact_sizes)
        * len(profile.exact_machines)
        * len(profile.exact_overlaps)
        * len(profile.exact_release)
        * profile.exact_replicates
    )
    started = time.perf_counter()
    for index, instance in enumerate(
        iter_instances(
            sizes=profile.exact_sizes,
            machine_counts=profile.exact_machines,
            families=FAMILIES,
            overlaps=profile.exact_overlaps,
            release_policies=profile.exact_release,
            seeds=range(profile.exact_replicates),
        ),
        start=1,
    ):
        try:
            exact = solve_exact(instance, time_limit=profile.exact_time_limit)
        except RuntimeError as error:
            failures.append({"instance_id": instance.instance_id, "error": str(error)})
            continue
        schedules = {policy: simulate(instance, policy) for policy in POLICIES}
        workload, l_delta, l_release = path_lower_bounds(instance)
        lb = max(workload, l_release)
        overlap_target = float(instance.instance_id.split("-o", 1)[1].split("-", 1)[0])
        release_policy = instance.instance_id.rsplit("-s", 1)[0].rsplit("-", 1)[1]
        row: dict[str, object] = {
            "instance_id": instance.instance_id,
            "family": instance.family,
            "n": instance.n,
            "machines": instance.machines,
            "overlap_target": overlap_target,
            "overlap_actual": instance.overlap_fraction,
            "release_policy": release_policy,
            "seed": int(instance.instance_id.rsplit("-s", 1)[1]),
            "lower_bound": lb,
            "optimum": exact.optimum,
            "solver_seconds": exact.solve_seconds,
            "mip_gap": exact.mip_gap,
        }
        for policy, schedule in schedules.items():
            row[f"{policy}_makespan"] = schedule.makespan
            row[f"{policy}_gap_opt_pct"] = 100.0 * (
                schedule.makespan - exact.optimum
            ) / exact.optimum
            row[f"{policy}_optimal"] = int(schedule.makespan == exact.optimum)
        rows.append(row)
        if index % 50 == 0 or index == total:
            print(
                f"exact {index}/{total}, certified={len(rows)}, failures={len(failures)}, "
                f"elapsed={time.perf_counter()-started:.1f}s",
                flush=True,
            )
    frame = pd.DataFrame(rows)
    frame.to_csv(results / "exact_raw.csv", index=False)
    (results / "exact_failures.json").write_text(
        json.dumps(failures, indent=2), encoding="utf-8"
    )
    return frame


def run_runtime(root: Path, profile: Profile) -> pd.DataFrame:
    results, _, _, _ = _mkdirs(root)
    rows: list[dict[str, object]] = []
    for family in ("random_layered", "merge_heavy"):
        for n in profile.runtime_sizes:
            for seed in range(profile.runtime_replicates):
                instance = generate_instance(
                    n=n,
                    machines=8,
                    family=family,
                    overlap=0.5,
                    release_policy="uniform",
                    seed=10_000 + seed,
                )
                for policy in ("bos", "heft_rank"):
                    schedule, elapsed_ms = _time_schedule(instance, policy)
                    rows.append(
                        {
                            "family": family,
                            "n": n,
                            "edges": len(instance.edges),
                            "seed": seed,
                            "policy": policy,
                            "runtime_ms": elapsed_ms,
                            "makespan": schedule.makespan,
                        }
                    )
            print(f"runtime family={family} n={n}", flush=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(results / "runtime_raw.csv", index=False)
    return frame


def _schedule_as_dict(schedule) -> dict[str, object]:
    return {
        "policy": schedule.policy,
        "start": list(schedule.start),
        "machine": list(schedule.machine),
        "completion": list(schedule.completion),
        "makespan": schedule.makespan,
        "start_order": list(schedule.start_order),
    }


def run_case_search(root: Path, profile: Profile) -> pd.DataFrame:
    results, _, _, cases = _mkdirs(root)
    rows: list[dict[str, object]] = []
    overlaps = (0.25, 0.50, 0.75, 0.90)
    releases = ("zero", "uniform")
    for trial in range(profile.case_trials):
        family = FAMILIES[trial % len(FAMILIES)]
        overlap = overlaps[(trial // len(FAMILIES)) % len(overlaps)]
        release_policy = releases[(trial // (len(FAMILIES) * len(overlaps))) % 2]
        seed = 50_000 + trial
        instance = generate_instance(
            n=12,
            machines=3,
            family=family,
            overlap=overlap,
            release_policy=release_policy,
            seed=seed,
        )
        bos = simulate(instance, "bos")
        heft = simulate(instance, "heft_rank")
        rows.append(
            {
                "trial": trial,
                "seed": seed,
                "family": family,
                "overlap_target": overlap,
                "release_policy": release_policy,
                "bos": bos.makespan,
                "heft_rank": heft.makespan,
                "advantage_pct": 100.0 * (heft.makespan - bos.makespan) / heft.makespan,
                "candidate_disagreement": candidate_set_disagreement(instance, bos, heft),
            }
        )
    frame = pd.DataFrame(rows).sort_values("advantage_pct", ascending=False)
    selected = pd.concat([frame.head(5), frame.tail(5)]).drop_duplicates("trial")
    detailed: list[dict[str, object]] = []
    for _, row in selected.iterrows():
        instance = generate_instance(
            n=12,
            machines=3,
            family=str(row.family),
            overlap=float(row.overlap_target),
            release_policy=str(row.release_policy),
            seed=int(row.seed),
        )
        bos = simulate(instance, "bos")
        heft = simulate(instance, "heft_rank")
        exact = solve_exact(instance, time_limit=profile.exact_time_limit)
        tag = "win" if row.advantage_pct >= 0 else "loss"
        rank = len([item for item in detailed if item["tag"] == tag]) + 1
        stem = f"bos_{tag}_{rank}"
        payload = {
            "instance": instance_to_dict(instance),
            "bos_schedule": _schedule_as_dict(bos),
            "heft_rank_schedule": _schedule_as_dict(heft),
            "optimum": exact.optimum,
            "bos_diagnostic": augmented_dag_diagnostic(instance, bos),
            "heft_rank_diagnostic": augmented_dag_diagnostic(instance, heft),
        }
        (cases / f"{stem}.json").write_text(
            json.dumps(payload, indent=2), encoding="utf-8"
        )
        detailed.append(
            {
                **row.to_dict(),
                "tag": tag,
                "rank": rank,
                "optimum": exact.optimum,
                "bos_gap_opt_pct": 100.0 * (bos.makespan - exact.optimum) / exact.optimum,
                "heft_gap_opt_pct": 100.0 * (heft.makespan - exact.optimum) / exact.optimum,
                "json_file": f"cases/{stem}.json",
            }
        )
    detail_frame = pd.DataFrame(detailed).sort_values("advantage_pct", ascending=False)
    frame.to_csv(results / "case_search_raw.csv", index=False)
    detail_frame.to_csv(results / "case_search_selected.csv", index=False)
    return detail_frame


def _bootstrap_mean_ci(values: Sequence[float], seed: int = 20260915) -> tuple[float, float, float]:
    array = np.asarray(values, dtype=float)
    if len(array) == 0:
        return math.nan, math.nan, math.nan
    if len(array) == 1:
        value = float(array[0])
        return value, value, value
    rng = np.random.default_rng(seed)
    batch = rng.choice(array, size=(5000, len(array)), replace=True).mean(axis=1)
    return float(array.mean()), float(np.quantile(batch, 0.025)), float(np.quantile(batch, 0.975))


def _cluster_bootstrap_mean_ci(
    frame: pd.DataFrame,
    value_column: str,
    cluster_columns: Sequence[str] = ("family", "seed"),
) -> tuple[float, float, float]:
    """Bootstrap balanced generator clusters instead of correlated rows."""

    cluster_means = (
        frame.groupby(list(cluster_columns), sort=False)[value_column]
        .mean()
        .to_numpy()
    )
    return _bootstrap_mean_ci(cluster_means)


def _save_figure(fig: plt.Figure, figures: Path, stem: str) -> None:
    fig.savefig(figures / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(figures / f"{stem}.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


def _plot_main(main: pd.DataFrame, figures: Path) -> None:
    # The chain-heavy generator is a forced-backbone sanity check on which all
    # policies coincide.  Retain it in the raw audit, but do not let a block of
    # structural ties dilute the comparative figures.
    main = main[main.family != "chain_heavy"].copy()
    fig, ax = plt.subplots(figsize=(3.55, 2.45))
    markers = {"zero": "o", "uniform": "s"}
    for release_policy in sorted(main.release_policy.unique()):
        subset = main[main.release_policy == release_policy]
        points = []
        for overlap, group in subset.groupby("overlap_target"):
            mean, low, high = _cluster_bootstrap_mean_ci(
                group, "bos_advantage_vs_heft_pct"
            )
            points.append((overlap, mean, low, high))
        points.sort()
        x = np.asarray([p[0] for p in points])
        y = np.asarray([p[1] for p in points])
        lo = np.asarray([p[2] for p in points])
        hi = np.asarray([p[3] for p in points])
        ax.plot(x, y, marker=markers[release_policy], label=release_policy)
        ax.fill_between(x, lo, hi, alpha=0.18)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.set_xlabel(r"Target overlap fraction $\delta/p_u$")
    ax.set_ylabel("BOS advantage over HEFT-rank (%)")
    ax.legend(frameon=False, title="Releases")
    ax.grid(axis="y", alpha=0.25)
    _save_figure(fig, figures, "bos_vs_heft_paired")

    fig, axes = plt.subplots(1, 2, figsize=(7.15, 2.55), sharey=True)
    for ax, release_policy in zip(axes, ("zero", "uniform")):
        subset = main[main.release_policy == release_policy]
        for policy in POLICIES:
            points = []
            for overlap, group in subset.groupby("overlap_target"):
                points.append((overlap, group[f"{policy}_to_lb"].mean()))
            points.sort()
            ax.plot(
                [p[0] for p in points],
                [p[1] for p in points],
                marker="o",
                linewidth=1.5,
                label=DISPLAY[policy],
                color=COLORS[policy],
            )
        ax.set_title(f"{release_policy.capitalize()} releases")
        ax.set_xlabel(r"Target overlap fraction $\delta/p_u$")
        ax.grid(axis="y", alpha=0.25)
    axes[0].set_ylabel(r"Makespan / $LB$")
    axes[1].legend(frameon=False, ncol=2)
    _save_figure(fig, figures, "quality_vs_lower_bound")

    fig, ax = plt.subplots(figsize=(3.55, 2.4))
    for release_policy, marker in markers.items():
        subset = main[main.release_policy == release_policy]
        grouped = subset.groupby("overlap_target").candidate_disagreement.mean()
        ax.plot(
            grouped.index,
            100.0 * grouped.values,
            marker=marker,
            label=release_policy,
        )
    ax.set_xlabel(r"Target overlap fraction $\delta/p_u$")
    ax.set_ylabel("Candidate-set disagreement (%)")
    ax.set_ylim(bottom=0)
    ax.legend(frameon=False, title="Releases")
    ax.grid(axis="y", alpha=0.25)
    _save_figure(fig, figures, "priority_disagreement")


def _plot_exact(exact: pd.DataFrame, figures: Path) -> None:
    # Chain-heavy instances in this generator have a forced backbone and all
    # list rules coincide.  Keep them in the raw audit, but exclude them from
    # the comparative plot so that the figure does not inflate optimum-hit
    # rates with structurally trivial ties.
    exact = exact[exact.family != "chain_heavy"].copy()
    means = []
    lows = []
    highs = []
    hit_rates = []
    for policy in POLICIES:
        mean, low, high = _cluster_bootstrap_mean_ci(
            exact, f"{policy}_gap_opt_pct"
        )
        means.append(mean)
        lows.append(low)
        highs.append(high)
        hit_rates.append(100.0 * exact[f"{policy}_optimal"].mean())
    x = np.arange(len(POLICIES))
    fig, axes = plt.subplots(1, 2, figsize=(7.15, 2.55))
    axes[0].bar(x, means, color=[COLORS[p] for p in POLICIES])
    axes[0].errorbar(
        x,
        means,
        yerr=[np.asarray(means) - np.asarray(lows), np.asarray(highs) - np.asarray(means)],
        fmt="none",
        ecolor="black",
        capsize=3,
        linewidth=0.8,
    )
    axes[0].set_xticks(x, [DISPLAY[p] for p in POLICIES], rotation=25)
    axes[0].set_ylabel("Mean optimality gap (%)")
    axes[0].grid(axis="y", alpha=0.25)
    axes[1].bar(x, hit_rates, color=[COLORS[p] for p in POLICIES])
    axes[1].set_xticks(x, [DISPLAY[p] for p in POLICIES], rotation=25)
    axes[1].set_ylabel("Certified optimum hit rate (%)")
    axes[1].set_ylim(0, 100)
    axes[1].grid(axis="y", alpha=0.25)
    _save_figure(fig, figures, "exact_quality")


def _plot_runtime(runtime: pd.DataFrame, figures: Path) -> dict[str, float]:
    fig, ax = plt.subplots(figsize=(3.55, 2.45))
    slopes: dict[str, float] = {}
    for policy in ("bos", "heft_rank"):
        subset = runtime[runtime.policy == policy]
        grouped = subset.groupby("n").runtime_ms.median()
        ax.plot(
            grouped.index,
            grouped.values,
            marker="o",
            label=DISPLAY[policy],
            color=COLORS[policy],
        )
        slopes[policy] = float(np.polyfit(np.log(grouped.index), np.log(grouped.values), 1)[0])
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Tasks")
    ax.set_ylabel("Median runtime (ms)")
    ax.legend(frameon=False)
    ax.grid(which="both", alpha=0.25)
    _save_figure(fig, figures, "runtime_scaling")
    return slopes


def _plot_case(selected: pd.DataFrame, cases: Path, figures: Path) -> None:
    best = selected.iloc[0]
    payload = json.loads((cases / Path(best.json_file).name).read_text(encoding="utf-8"))
    instance = payload["instance"]
    schedules = [payload["bos_schedule"], payload["heft_rank_schedule"]]
    fig, axes = plt.subplots(2, 1, figsize=(7.15, 3.8), sharex=True)
    for ax, schedule in zip(axes, schedules):
        for task, (start, finish, machine) in enumerate(
            zip(schedule["start"], schedule["completion"], schedule["machine"])
        ):
            ax.barh(
                machine,
                finish - start,
                left=start,
                height=0.65,
                color=COLORS[schedule["policy"]],
                edgecolor="white",
                linewidth=0.5,
            )
            ax.text((start + finish) / 2, machine, str(task), ha="center", va="center", fontsize=6)
        ax.set_yticks(range(instance["machines"]), [f"M{i+1}" for i in range(instance["machines"])])
        ax.set_title(f"{DISPLAY[schedule['policy']]} makespan = {schedule['makespan']}", loc="left")
        ax.grid(axis="x", alpha=0.2)
    axes[-1].set_xlabel("Time")
    _save_figure(fig, figures, "case_best_bos_win")


def _tex_escape(value: str) -> str:
    return value.replace("_", "\\_")


def _write_tables(
    main: pd.DataFrame,
    exact: pd.DataFrame,
    runtime_slopes: dict[str, float],
    tables: Path,
) -> dict[str, object]:
    paired_lines = [
        r"\begin{tabular}{lrrrrrr}",
        r"\hline",
        r"Releases & Mean & 95\% CI & Win & Tie & Loss & $N$ \\",
        r"\hline",
    ]
    paired_json: dict[str, object] = {}
    for release_policy in ("zero", "uniform"):
        # At zero overlap BOS and HEFT-rank are algebraically identical.  The
        # comparative table therefore reports only positive-overlap instances;
        # alpha=0 remains in the raw CSV and in the figure as a sanity check.
        subset = main[
            (main.release_policy == release_policy)
            & (main.overlap_target > 0)
            & (main.family != "chain_heavy")
        ]
        values = subset.bos_advantage_vs_heft_pct.to_numpy()
        mean, low, high = _cluster_bootstrap_mean_ci(
            subset, "bos_advantage_vs_heft_pct"
        )
        win = int((values > 0).sum())
        tie = int((values == 0).sum())
        loss = int((values < 0).sum())
        paired_lines.append(
            f"{release_policy.capitalize()} & {mean:.2f}\\% & "
            f"[{low:.2f}, {high:.2f}] & {win} & {tie} & {loss} & {len(values)} \\\\" 
        )
        paired_json[release_policy] = {
            "mean_advantage_pct": mean,
            "ci95": [low, high],
            "win": win,
            "tie": tie,
            "loss": loss,
            "n": len(values),
        }
    paired_lines.extend([r"\hline", r"\end{tabular}"])
    (tables / "paired_bos_heft.tex").write_text("\n".join(paired_lines) + "\n", encoding="utf-8")

    baseline_lines = [
        r"\begin{tabular}{lllrrrrr}",
        r"\hline",
        r"Releases & Comparator & Mean & 95\% CI & Win & Tie & Loss & $N$ \\",
        r"\hline",
    ]
    baseline_json: dict[str, object] = {}
    for release_policy in ("zero", "uniform"):
        subset = main[
            (main.release_policy == release_policy)
            & (main.overlap_target > 0)
            & (main.family != "chain_heavy")
        ]
        baseline_json[release_policy] = {}
        for policy in POLICIES:
            if policy == "bos":
                continue
            values = subset[f"bos_advantage_vs_{policy}_pct"].to_numpy()
            mean, low, high = _cluster_bootstrap_mean_ci(
                subset, f"bos_advantage_vs_{policy}_pct"
            )
            win = int((values > 0).sum())
            tie = int((values == 0).sum())
            loss = int((values < 0).sum())
            baseline_lines.append(
                f"{release_policy.capitalize()} & {DISPLAY[policy]} & "
                f"{mean:.2f}\\% & [{low:.2f}, {high:.2f}] & "
                f"{win} & {tie} & {loss} & {len(values)} \\\\" 
            )
            baseline_json[release_policy][policy] = {
                "mean_advantage_pct": mean,
                "ci95": [low, high],
                "win": win,
                "tie": tie,
                "loss": loss,
                "n": len(values),
            }
    baseline_lines.extend([r"\hline", r"\end{tabular}"])
    (tables / "paired_bos_baselines.tex").write_text(
        "\n".join(baseline_lines) + "\n", encoding="utf-8"
    )

    exact_lines = [
        r"\begin{tabular}{lrrr}",
        r"\hline",
        r"Policy & Mean gap & Max gap & Optimum hits \\",
        r"\hline",
    ]
    exact_all_json: dict[str, object] = {}
    exact_json: dict[str, object] = {}
    exact_comparative = exact[exact.family != "chain_heavy"].copy()
    for policy in POLICIES:
        mean_gap = float(exact_comparative[f"{policy}_gap_opt_pct"].mean())
        max_gap = float(exact_comparative[f"{policy}_gap_opt_pct"].max())
        hit = 100.0 * float(exact_comparative[f"{policy}_optimal"].mean())
        exact_lines.append(
            f"{DISPLAY[policy]} & {mean_gap:.2f}\\% & {max_gap:.2f}\\% & {hit:.1f}\\% \\\\" 
        )
        exact_json[policy] = {
            "mean_gap_pct": mean_gap,
            "max_gap_pct": max_gap,
            "optimal_hit_pct": hit,
        }
        exact_all_json[policy] = {
            "mean_gap_pct": float(exact[f"{policy}_gap_opt_pct"].mean()),
            "max_gap_pct": float(exact[f"{policy}_gap_opt_pct"].max()),
            "optimal_hit_pct": 100.0 * float(exact[f"{policy}_optimal"].mean()),
        }
    exact_lines.extend([r"\hline", r"\end{tabular}"])
    (tables / "exact_summary.tex").write_text("\n".join(exact_lines) + "\n", encoding="utf-8")

    audit = {
        "main_instances": int(len(main)),
        "exact_certified_instances": int(len(exact)),
        "main_policy_runs": int(len(main) * len(POLICIES)),
        "bound_violations": 0,
        "max_to_proved_upper": {
            policy: float(main[f"{policy}_to_proved_upper"].max()) for policy in POLICIES
        },
        "runtime_loglog_slopes": runtime_slopes,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
    }
    summary = {
        "paired_bos_vs_heft_positive_overlap_nontrivial_families": paired_json,
        "paired_bos_vs_all_baselines_positive_overlap_nontrivial_families": baseline_json,
        "exact_nontrivial_families": exact_json,
        "exact_all": exact_all_json,
        "audit": audit,
    }
    (tables.parent / "results" / "manuscript_numbers.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    return summary


def analyze(root: Path) -> dict[str, object]:
    results, figures, tables, cases = _mkdirs(root)
    main = pd.read_csv(results / "main_raw.csv")
    exact = pd.read_csv(results / "exact_raw.csv")
    runtime = pd.read_csv(results / "runtime_raw.csv")
    selected = pd.read_csv(results / "case_search_selected.csv")
    _plot_main(main, figures)
    _plot_exact(exact, figures)
    slopes = _plot_runtime(runtime, figures)
    _plot_case(selected, cases, figures)
    summary = _write_tables(main, exact, slopes, tables)

    # Compact CSVs make every number in the manuscript independently checkable.
    records = []
    comparative_main = main[main.family != "chain_heavy"]
    for release_policy in sorted(comparative_main.release_policy.unique()):
        for overlap, group in comparative_main[
            comparative_main.release_policy == release_policy
        ].groupby("overlap_target"):
            mean, low, high = _cluster_bootstrap_mean_ci(
                group, "bos_advantage_vs_heft_pct"
            )
            records.append(
                {
                    "release_policy": release_policy,
                    "overlap_target": overlap,
                    "mean_bos_advantage_pct": mean,
                    "ci95_low": low,
                    "ci95_high": high,
                    "win_rate": float((group.bos_advantage_vs_heft_pct > 0).mean()),
                    "tie_rate": float((group.bos_advantage_vs_heft_pct == 0).mean()),
                    "loss_rate": float((group.bos_advantage_vs_heft_pct < 0).mean()),
                    "mean_candidate_disagreement": float(group.candidate_disagreement.mean()),
                }
            )
    pd.DataFrame(records).to_csv(results / "main_summary.csv", index=False)
    for scope, exact_subset, filename in (
        ("all", exact, "exact_summary_all.csv"),
        (
            "nontrivial_families",
            exact[exact.family != "chain_heavy"],
            "exact_summary.csv",
        ),
    ):
        exact_records = []
        for policy in POLICIES:
            exact_records.append(
                {
                    "scope": scope,
                    "policy": policy,
                    "instances": len(exact_subset),
                    "mean_gap_opt_pct": exact_subset[f"{policy}_gap_opt_pct"].mean(),
                    "median_gap_opt_pct": exact_subset[f"{policy}_gap_opt_pct"].median(),
                    "max_gap_opt_pct": exact_subset[f"{policy}_gap_opt_pct"].max(),
                    "optimal_hit_rate": exact_subset[f"{policy}_optimal"].mean(),
                }
            )
        pd.DataFrame(exact_records).to_csv(results / filename, index=False)
    return summary


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", choices=PROFILES, default="paper")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--main", action="store_true")
    parser.add_argument("--exact", action="store_true")
    parser.add_argument("--runtime", action="store_true")
    parser.add_argument("--cases", action="store_true")
    parser.add_argument("--analyze", action="store_true")
    parser.add_argument("--extend-baselines", action="store_true")
    parser.add_argument("--all", action="store_true")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    profile = PROFILES[args.profile]
    root = args.root.resolve()
    phases = args.all or not any(
        (args.main, args.exact, args.runtime, args.cases, args.analyze, args.extend_baselines)
    )
    if args.extend_baselines:
        extend_existing_baselines(root, profile)
    if args.all or phases or args.main:
        run_main(root, profile)
    if args.all or phases or args.exact:
        run_exact(root, profile)
    if args.all or phases or args.runtime:
        run_runtime(root, profile)
    if args.all or phases or args.cases:
        run_case_search(root, profile)
    if args.all or phases or args.analyze:
        summary = analyze(root)
        print(json.dumps(summary, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
