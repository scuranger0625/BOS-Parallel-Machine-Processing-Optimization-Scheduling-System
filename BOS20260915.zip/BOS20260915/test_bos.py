from __future__ import annotations

import unittest

from experiments.bos_core import (
    Edge,
    Instance,
    augmented_dag_diagnostic,
    bos_scores,
    candidate_set_disagreement,
    grpw_scores,
    path_lower_bounds,
    simulate,
    verify_approximation_bound,
)
from experiments.exact_solver import solve_exact
from experiments.generators import FAMILIES, generate_instance


class BosCoreTests(unittest.TestCase):
    def test_bottom_level_includes_singleton_path(self) -> None:
        instance = Instance(
            p=(10, 1),
            release=(0, 0),
            edges=(Edge(0, 1, 0),),
            machines=2,
        )
        self.assertEqual(bos_scores(instance), (10, 1))

    def test_zero_lag_closure_starts_successor_at_same_time(self) -> None:
        instance = Instance(
            p=(10, 1),
            release=(0, 0),
            edges=(Edge(0, 1, 0),),
            machines=2,
        )
        schedule = simulate(instance, "bos")
        self.assertEqual(schedule.start, (0, 0))
        self.assertEqual(schedule.makespan, 10)

    def test_grpw_counts_merged_descendant_once(self) -> None:
        instance = Instance(
            p=(2, 3, 5, 7),
            release=(0, 0, 0, 0),
            edges=(Edge(0, 1, 2), Edge(0, 2, 2), Edge(1, 3, 3), Edge(2, 3, 5)),
            machines=2,
        )
        self.assertEqual(grpw_scores(instance), (17, 10, 12, 7))

    def test_duration_baselines_have_opposite_orders(self) -> None:
        instance = Instance(
            p=(5, 1, 3),
            release=(0, 0, 0),
            edges=(),
            machines=1,
        )
        self.assertEqual(simulate(instance, "lpt").start_order, (0, 2, 1))
        self.assertEqual(simulate(instance, "spt").start_order, (1, 2, 0))

    def test_release_and_and_precedence(self) -> None:
        instance = Instance(
            p=(4, 6, 2),
            release=(3, 0, 0),
            edges=(Edge(0, 2, 2), Edge(1, 2, 5)),
            machines=2,
        )
        schedule = simulate(instance, "bos")
        self.assertGreaterEqual(schedule.start[2], schedule.start[0] + 2)
        self.assertGreaterEqual(schedule.start[2], schedule.start[1] + 5)
        self.assertGreaterEqual(schedule.start[0], 3)

    def test_exact_solver_known_independent_instance(self) -> None:
        instance = Instance(
            p=(3, 2, 2),
            release=(0, 0, 0),
            edges=(),
            machines=2,
            instance_id="known-independent",
        )
        result = solve_exact(instance, time_limit=5.0)
        self.assertEqual(result.optimum, 4)
        self.assertEqual(result.mip_gap, 0.0)

    def test_random_feasibility_bounds_and_exact_dominance(self) -> None:
        for family_index, family in enumerate(FAMILIES):
            for seed in range(5):
                instance = generate_instance(
                    n=8,
                    machines=2 + seed % 2,
                    family=family,
                    overlap=(seed % 4) / 4,
                    release_policy="zero" if seed % 2 == 0 else "uniform",
                    seed=100 * family_index + seed,
                )
                schedules = [
                    simulate(instance, policy)
                    for policy in ("bos", "heft_rank", "grpw", "lpt", "spt", "fifo")
                ]
                for schedule in schedules:
                    verify_approximation_bound(instance, schedule)
                optimum = solve_exact(instance, time_limit=10.0).optimum
                self.assertTrue(all(schedule.makespan >= optimum for schedule in schedules))
                self.assertLessEqual(path_lower_bounds(instance)[0], optimum)
                self.assertLessEqual(path_lower_bounds(instance)[2], optimum)

    def test_augmented_dag_reproduces_schedule_makespan(self) -> None:
        instance = generate_instance(
            n=20,
            machines=4,
            family="random_layered",
            overlap=0.6,
            release_policy="uniform",
            seed=71,
        )
        schedule = simulate(instance, "bos")
        diagnostic = augmented_dag_diagnostic(instance, schedule)
        self.assertEqual(diagnostic["fixed_order_makespan"], schedule.makespan)
        self.assertTrue(diagnostic["critical_edges"])

    def test_candidate_disagreement_is_well_defined(self) -> None:
        instance = generate_instance(
            n=30,
            machines=4,
            family="merge_heavy",
            overlap=0.7,
            release_policy="zero",
            seed=8,
        )
        bos = simulate(instance, "bos")
        heft = simulate(instance, "heft_rank")
        value = candidate_set_disagreement(instance, bos, heft)
        self.assertGreaterEqual(value, 0.0)
        self.assertLessEqual(value, 1.0)


if __name__ == "__main__":
    unittest.main()
