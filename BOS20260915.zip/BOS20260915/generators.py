"""Deterministic synthetic benchmark generators for BOS experiments."""

from __future__ import annotations

import math
from typing import Iterable

import numpy as np

from .bos_core import Edge, Instance


FAMILIES = ("chain_heavy", "fork_join", "merge_heavy", "random_layered")
RELEASE_POLICIES = ("zero", "uniform", "bursty")


def _chain_heavy_edges(n: int, rng: np.random.Generator) -> set[tuple[int, int]]:
    """A deep backbone with one-task detours around many backbone arcs."""

    if n == 1:
        return set()
    backbone = list(range(0, n, 2))
    if backbone[-1] != n - 1:
        backbone.append(n - 1)
    edges = {(u, v) for u, v in zip(backbone, backbone[1:])}
    for branch in range(1, n - 1, 2):
        left = branch - 1
        right = min(branch + 1, n - 1)
        edges.add((left, branch))
        edges.add((branch, right))
        if right + 2 < n and rng.random() < 0.30:
            edges.add((branch, right + 2))
    return edges


def _fork_join_edges(n: int, rng: np.random.Generator) -> set[tuple[int, int]]:
    """Repeated fork-join modules with random module width."""

    if n == 1:
        return set()
    edges: set[tuple[int, int]] = set()
    source = 0
    next_node = 1
    while next_node < n:
        remaining = n - next_node
        if remaining == 1:
            edges.add((source, next_node))
            break
        width = min(int(rng.integers(2, 6)), remaining - 1)
        branches = list(range(next_node, next_node + width))
        join = next_node + width
        for branch in branches:
            edges.add((source, branch))
            edges.add((branch, join))
        source = join
        next_node = join + 1
    return edges


def _layered_nodes(n: int, target_width: int) -> list[list[int]]:
    levels: list[list[int]] = []
    node = 0
    while node < n:
        width = min(target_width, n - node)
        levels.append(list(range(node, node + width)))
        node += width
    return levels


def _merge_heavy_edges(n: int, rng: np.random.Generator) -> set[tuple[int, int]]:
    width = max(2, int(round(math.sqrt(n))))
    levels = _layered_nodes(n, width)
    edges: set[tuple[int, int]] = set()
    for level_index in range(1, len(levels)):
        candidates = levels[level_index - 1]
        if level_index >= 2:
            candidates = candidates + levels[level_index - 2]
        for v in levels[level_index]:
            degree = min(len(candidates), int(rng.integers(2, min(7, len(candidates)) + 1)))
            for u in rng.choice(candidates, size=degree, replace=False):
                edges.add((int(u), v))
    return edges


def _random_layered_edges(n: int, rng: np.random.Generator) -> set[tuple[int, int]]:
    width = max(3, int(round(math.sqrt(n))))
    levels = _layered_nodes(n, width)
    edges: set[tuple[int, int]] = set()
    for level_index in range(1, len(levels)):
        prior = [u for level in levels[max(0, level_index - 3) : level_index] for u in level]
        immediate = levels[level_index - 1]
        for v in levels[level_index]:
            degree = min(len(prior), int(rng.integers(1, 4)))
            chosen = set(int(x) for x in rng.choice(prior, size=degree, replace=False))
            chosen.add(int(rng.choice(immediate)))
            edges.update((u, v) for u in chosen)
    return edges


def generate_edge_pairs(n: int, family: str, rng: np.random.Generator) -> set[tuple[int, int]]:
    if family == "chain_heavy":
        return _chain_heavy_edges(n, rng)
    if family == "fork_join":
        return _fork_join_edges(n, rng)
    if family == "merge_heavy":
        return _merge_heavy_edges(n, rng)
    if family == "random_layered":
        return _random_layered_edges(n, rng)
    raise ValueError(f"unknown family: {family}")


def _edge_lag(processing_time: int, overlap: float, rng: np.random.Generator) -> int:
    if overlap <= 0.0:
        delta = 0
    elif overlap >= 1.0:
        delta = processing_time
    else:
        concentration = 14.0
        fraction = float(
            rng.beta(overlap * concentration, (1.0 - overlap) * concentration)
        )
        delta = int(round(fraction * processing_time))
    return processing_time - min(processing_time, max(0, delta))


def _release_dates(
    policy: str,
    processing: tuple[int, ...],
    machines: int,
    rng: np.random.Generator,
) -> tuple[int, ...]:
    n = len(processing)
    if policy == "zero":
        return (0,) * n
    base = max(1, int(round(sum(processing) / machines)))
    if policy == "uniform":
        horizon = max(1, int(round(0.50 * base)))
        return tuple(int(x) for x in rng.integers(0, horizon + 1, size=n))
    if policy == "bursty":
        late = max(1, int(round(0.60 * base)))
        jitter = max(1, int(round(0.08 * base)))
        result = []
        for _ in range(n):
            if rng.random() < 0.70:
                result.append(int(rng.integers(0, jitter + 1)))
            else:
                result.append(late + int(rng.integers(0, jitter + 1)))
        return tuple(result)
    raise ValueError(f"unknown release policy: {policy}")


def generate_instance(
    *,
    n: int,
    machines: int,
    family: str,
    overlap: float,
    release_policy: str,
    seed: int,
    processing_low: int = 1,
    processing_high: int = 20,
) -> Instance:
    """Generate a reproducible integer-time instance.

    ``overlap`` is the target mean allowance fraction ``delta / p[u]``.
    Edge-specific values are beta-distributed around that target, except that
    zero and one produce exact finish--start and zero-lag edges respectively.
    """

    if n < 1:
        raise ValueError("n must be positive")
    if not (0.0 <= overlap <= 1.0):
        raise ValueError("overlap must lie in [0, 1]")
    rng = np.random.default_rng(seed)
    processing = tuple(
        int(x) for x in rng.integers(processing_low, processing_high + 1, size=n)
    )
    pairs = generate_edge_pairs(n, family, rng)
    edges = tuple(
        Edge(u, v, _edge_lag(processing[u], overlap, rng))
        for u, v in sorted(pairs)
    )
    release = _release_dates(release_policy, processing, machines, rng)
    identifier = f"{family}-n{n}-m{machines}-o{overlap:.2f}-{release_policy}-s{seed}"
    return Instance(
        p=processing,
        release=release,
        edges=edges,
        machines=machines,
        family=family,
        instance_id=identifier,
    )


def iter_instances(
    *,
    sizes: Iterable[int],
    machine_counts: Iterable[int],
    families: Iterable[str],
    overlaps: Iterable[float],
    release_policies: Iterable[str],
    seeds: Iterable[int],
) -> Iterable[Instance]:
    for family in families:
        for n in sizes:
            for machines in machine_counts:
                for overlap in overlaps:
                    for release_policy in release_policies:
                        for seed in seeds:
                            yield generate_instance(
                                n=n,
                                machines=machines,
                                family=family,
                                overlap=overlap,
                                release_policy=release_policy,
                                seed=seed,
                            )

