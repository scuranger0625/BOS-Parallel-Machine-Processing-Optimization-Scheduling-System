"""Core model, schedulers, lower bounds, and schedule diagnostics.

The implementation follows the paper's offline model exactly:

* all tasks, processing times, release dates, and DAG edges are known;
* an edge ``(u, v)`` has a non-negative start--start lag ``lag <= p[u]``;
* tasks are non-preemptive and execute on identical parallel machines;
* BOS uses a fixed overlap-adjusted bottom-level score and an event-driven
  executable set.

All tie breaking is deterministic by task index so that runs are reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import heapq
from typing import Iterable, Sequence


@dataclass(frozen=True, order=True)
class Edge:
    """A start--start precedence edge."""

    u: int
    v: int
    lag: int


@dataclass
class Instance:
    """One identical-machine overlap-scheduling instance."""

    p: tuple[int, ...]
    release: tuple[int, ...]
    edges: tuple[Edge, ...]
    machines: int
    family: str = "unspecified"
    instance_id: str = ""
    successors: tuple[tuple[tuple[int, int], ...], ...] = field(init=False)
    predecessors: tuple[tuple[tuple[int, int], ...], ...] = field(init=False)
    topological_order: tuple[int, ...] = field(init=False)

    def __post_init__(self) -> None:
        n = len(self.p)
        if n == 0:
            raise ValueError("an instance must contain at least one task")
        if len(self.release) != n:
            raise ValueError("p and release must have equal length")
        if self.machines < 1:
            raise ValueError("machines must be positive")
        if any(x <= 0 for x in self.p):
            raise ValueError("processing times must be positive")
        if any(x < 0 for x in self.release):
            raise ValueError("release times must be non-negative")

        succ: list[list[tuple[int, int]]] = [[] for _ in range(n)]
        pred: list[list[tuple[int, int]]] = [[] for _ in range(n)]
        seen: set[tuple[int, int]] = set()
        for edge in self.edges:
            if not (0 <= edge.u < n and 0 <= edge.v < n):
                raise ValueError(f"edge endpoint out of range: {edge}")
            if edge.u == edge.v:
                raise ValueError("self loops are not allowed")
            if (edge.u, edge.v) in seen:
                raise ValueError(f"duplicate edge: {(edge.u, edge.v)}")
            if not (0 <= edge.lag <= self.p[edge.u]):
                raise ValueError(
                    f"lag on {(edge.u, edge.v)} must lie in [0, p[u]]"
                )
            seen.add((edge.u, edge.v))
            succ[edge.u].append((edge.v, edge.lag))
            pred[edge.v].append((edge.u, edge.lag))

        for row in succ:
            row.sort()
        for row in pred:
            row.sort()
        self.successors = tuple(tuple(row) for row in succ)
        self.predecessors = tuple(tuple(row) for row in pred)
        self.topological_order = _topological_order(self.successors, self.predecessors)

    @property
    def n(self) -> int:
        return len(self.p)

    @property
    def overlap_fraction(self) -> float:
        if not self.edges:
            return 0.0
        return sum(self.p[e.u] - e.lag for e in self.edges) / sum(
            self.p[e.u] for e in self.edges
        )


@dataclass(frozen=True)
class Decision:
    """The candidate set immediately before one dispatch."""

    time: int
    candidates: tuple[int, ...]
    chosen: int


@dataclass
class Schedule:
    """A complete deterministic schedule."""

    policy: str
    start: tuple[int, ...]
    machine: tuple[int, ...]
    completion: tuple[int, ...]
    makespan: int
    start_order: tuple[int, ...]
    decisions: tuple[Decision, ...]


def _topological_order(
    successors: Sequence[Sequence[tuple[int, int]]],
    predecessors: Sequence[Sequence[tuple[int, int]]],
) -> tuple[int, ...]:
    indegree = [len(row) for row in predecessors]
    heap = [i for i, degree in enumerate(indegree) if degree == 0]
    heapq.heapify(heap)
    order: list[int] = []
    while heap:
        u = heapq.heappop(heap)
        order.append(u)
        for v, _ in successors[u]:
            indegree[v] -= 1
            if indegree[v] == 0:
                heapq.heappush(heap, v)
    if len(order) != len(successors):
        raise ValueError("precedence graph must be acyclic")
    return tuple(order)


def bos_scores(instance: Instance) -> tuple[int, ...]:
    """Return b_i = max{p_i, max_(i,j)(lag_ij + b_j)}."""

    score = list(instance.p)
    for u in reversed(instance.topological_order):
        for v, lag in instance.successors[u]:
            score[u] = max(score[u], lag + score[v])
    return tuple(score)


def heft_rank_scores(instance: Instance) -> tuple[int, ...]:
    """Return the HEFT-derived upward rank for identical machines.

    Standard HEFT targets heterogeneous processors.  With identical processing
    times and zero communication cost, its upward rank reduces to the full-work
    downstream path score below.  The event simulator supplies the overlap-aware
    feasibility semantics; therefore the paper calls this baseline HEFT-rank,
    rather than claiming to run the full heterogeneous HEFT algorithm.
    """

    score = list(instance.p)
    for u in reversed(instance.topological_order):
        if instance.successors[u]:
            score[u] = instance.p[u] + max(score[v] for v, _ in instance.successors[u])
    return tuple(score)


def lpt_scores(instance: Instance) -> tuple[int, ...]:
    """Longest-processing-time priority."""

    return instance.p


def spt_scores(instance: Instance) -> tuple[int, ...]:
    """Shortest-processing-time priority, represented as a max-heap score."""

    return tuple(-value for value in instance.p)


def grpw_scores(instance: Instance) -> tuple[int, ...]:
    """Greatest ranked positional weight (GRPW).

    The positional weight of a task is its processing time plus the processing
    time of every *distinct* transitive successor.  This supplies a structural
    comparator that rewards large downstream workload, whereas BOS rewards the
    longest overlap-adjusted path.  Sets avoid double counting at DAG merges.
    """

    descendants: list[set[int]] = [set() for _ in range(instance.n)]
    score = list(instance.p)
    for u in reversed(instance.topological_order):
        reachable = descendants[u]
        for v, _ in instance.successors[u]:
            reachable.add(v)
            reachable.update(descendants[v])
        score[u] += sum(instance.p[v] for v in reachable)
    return tuple(score)


def _priority_key(
    policy: str,
    task: int,
    ready_time: int,
    scores: Sequence[int] | None,
) -> tuple[int, int]:
    if policy == "fifo":
        return (ready_time, task)
    if scores is None:
        raise ValueError(f"scores required for policy {policy}")
    return (-scores[task], task)


def policy_scores(instance: Instance, policy: str) -> tuple[int, ...] | None:
    if policy == "bos":
        return bos_scores(instance)
    if policy == "heft_rank":
        return heft_rank_scores(instance)
    if policy == "lpt":
        return lpt_scores(instance)
    if policy == "spt":
        return spt_scores(instance)
    if policy == "grpw":
        return grpw_scores(instance)
    if policy == "fifo":
        return None
    raise ValueError(f"unknown policy: {policy}")


def simulate(instance: Instance, policy: str = "bos") -> Schedule:
    """Run a work-conserving event-driven list scheduler."""

    n = instance.n
    scores = policy_scores(instance, policy)

    # event = (time, type, task, auxiliary)
    # type 0 completion, 1 release, 2 activation.  All equal-time events are
    # consumed as a batch, so the type order is only a deterministic fallback.
    events: list[tuple[int, int, int, int]] = [
        (instance.release[i], 1, i, -1) for i in range(n)
    ]
    heapq.heapify(events)
    idle_machines = list(range(instance.machines))
    heapq.heapify(idle_machines)

    released = [False] * n
    activated_predecessors = [0] * n
    started = [False] * n
    completed = [False] * n
    start = [-1] * n
    machine = [-1] * n
    completion = [-1] * n
    ready_heap: list[tuple[tuple[int, int], int]] = []
    ready_members: set[int] = set()
    start_order: list[int] = []
    decisions: list[Decision] = []
    completed_count = 0

    def add_if_ready(task: int, now: int) -> None:
        if (
            not started[task]
            and task not in ready_members
            and released[task]
            and activated_predecessors[task] == len(instance.predecessors[task])
        ):
            heapq.heappush(
                ready_heap,
                (_priority_key(policy, task, now, scores), task),
            )
            ready_members.add(task)

    def process_equal_time_events(now: int) -> None:
        nonlocal completed_count
        affected: set[int] = set()
        while events and events[0][0] == now:
            _, event_type, task, auxiliary = heapq.heappop(events)
            if event_type == 0:
                if completed[task]:
                    raise RuntimeError(f"duplicate completion for task {task}")
                completed[task] = True
                completed_count += 1
                heapq.heappush(idle_machines, auxiliary)
            elif event_type == 1:
                released[task] = True
                affected.add(task)
            elif event_type == 2:
                activated_predecessors[auxiliary] += 1
                affected.add(auxiliary)
            else:
                raise RuntimeError(f"unknown event type: {event_type}")
        for task in sorted(affected):
            add_if_ready(task, now)

    now = 0
    while completed_count < n:
        if events and events[0][0] < now:
            raise RuntimeError("event queue moved backward")
        if events and events[0][0] == now:
            process_equal_time_events(now)

        while idle_machines and ready_heap:
            candidates = tuple(sorted(ready_members))
            _, task = heapq.heappop(ready_heap)
            ready_members.remove(task)
            if started[task]:
                raise RuntimeError(f"task {task} was started twice")

            assigned_machine = heapq.heappop(idle_machines)
            started[task] = True
            start[task] = now
            machine[task] = assigned_machine
            completion[task] = now + instance.p[task]
            start_order.append(task)
            decisions.append(Decision(now, candidates, task))

            heapq.heappush(events, (completion[task], 0, task, assigned_machine))
            for successor, lag in instance.successors[task]:
                heapq.heappush(events, (now + lag, 2, task, successor))

            # Starting a task may activate zero-lag successors at the same time.
            if events and events[0][0] == now:
                process_equal_time_events(now)

        if completed_count == n:
            break
        if not events:
            raise RuntimeError("deadlock: incomplete tasks but no future event")
        next_time = events[0][0]
        if next_time <= now:
            raise RuntimeError("same-time closure was not exhausted")
        now = next_time

    result = Schedule(
        policy=policy,
        start=tuple(start),
        machine=tuple(machine),
        completion=tuple(completion),
        makespan=max(completion),
        start_order=tuple(start_order),
        decisions=tuple(decisions),
    )
    validate_schedule(instance, result)
    return result


def validate_schedule(instance: Instance, schedule: Schedule) -> None:
    """Raise ``AssertionError`` if a returned schedule is infeasible."""

    n = instance.n
    assert len(schedule.start) == n
    assert len(schedule.machine) == n
    assert len(set(schedule.start_order)) == n
    assert set(schedule.start_order) == set(range(n))
    for task in range(n):
        assert schedule.start[task] >= instance.release[task]
        assert 0 <= schedule.machine[task] < instance.machines
        assert schedule.completion[task] == schedule.start[task] + instance.p[task]
    for edge in instance.edges:
        assert schedule.start[edge.v] >= schedule.start[edge.u] + edge.lag
    for assigned_machine in range(instance.machines):
        jobs = sorted(
            (schedule.start[i], schedule.completion[i], i)
            for i in range(n)
            if schedule.machine[i] == assigned_machine
        )
        for left, right in zip(jobs, jobs[1:]):
            assert left[1] <= right[0], (assigned_machine, left, right)
    assert schedule.makespan == max(schedule.completion)


def path_lower_bounds(instance: Instance) -> tuple[float, int, int]:
    """Return workload bound, L_delta, and release-aware L_(r,delta)."""

    workload = sum(instance.p) / instance.machines
    l_delta = max(bos_scores(instance))

    # best_start[v] is max over paths ending at v of
    # release(first vertex) + the sum of edge lags on that path.
    best_start = list(instance.release)
    for v in instance.topological_order:
        for u, lag in instance.predecessors[v]:
            best_start[v] = max(best_start[v], best_start[u] + lag)
    l_release = max(best_start[v] + instance.p[v] for v in range(instance.n))
    return workload, l_delta, l_release


def lower_bound(instance: Instance) -> float:
    workload, _, l_release = path_lower_bounds(instance)
    return max(workload, float(l_release))


def verify_approximation_bound(instance: Instance, schedule: Schedule) -> None:
    """Check the proved deterministic bound for a work-conserving schedule."""

    workload, l_delta, l_release = path_lower_bounds(instance)
    tolerance = 1e-9
    if all(value == 0 for value in instance.release):
        upper = workload + (1.0 - 1.0 / instance.machines) * l_delta
    else:
        upper = workload + l_release
    assert schedule.makespan <= upper + tolerance, (schedule.makespan, upper)


def candidate_set_disagreement(
    instance: Instance,
    first: Schedule,
    second: Schedule,
    first_policy: str = "bos",
    second_policy: str = "heft_rank",
) -> float:
    """Compare priorities on the same candidate sets harvested from both traces.

    This avoids the invalid claim that two diverged schedules occupy the same
    runtime state.  Each unique candidate set of size at least two is evaluated
    offline by both deterministic priority rules.
    """

    sets = {
        frozenset(decision.candidates)
        for schedule in (first, second)
        for decision in schedule.decisions
        if len(decision.candidates) >= 2
    }
    if not sets:
        return 0.0
    scores_a = policy_scores(instance, first_policy)
    scores_b = policy_scores(instance, second_policy)

    def choose(candidates: Iterable[int], policy: str, scores: Sequence[int] | None) -> int:
        return min(candidates, key=lambda task: _priority_key(policy, task, 0, scores))

    differing = 0
    for candidates in sets:
        choice_a = choose(candidates, first_policy, scores_a)
        choice_b = choose(candidates, second_policy, scores_b)
        differing += choice_a != choice_b
    return differing / len(sets)


def augmented_dag_diagnostic(instance: Instance, schedule: Schedule) -> dict[str, object]:
    """Build the schedule-induced DAG and return its critical-chain certificate."""

    source = instance.n
    typed_edges: list[tuple[int, int, int, str]] = [
        (source, i, instance.release[i], "release") for i in range(instance.n)
    ]
    typed_edges.extend((e.u, e.v, e.lag, "precedence") for e in instance.edges)
    for assigned_machine in range(instance.machines):
        jobs = sorted(
            (schedule.start[i], i)
            for i in range(instance.n)
            if schedule.machine[i] == assigned_machine
        )
        for (_, u), (_, v) in zip(jobs, jobs[1:]):
            typed_edges.append((u, v, instance.p[u], "machine"))

    node_count = instance.n + 1
    outgoing: list[list[tuple[int, int, str]]] = [[] for _ in range(node_count)]
    indegree = [0] * node_count
    for u, v, weight, kind in typed_edges:
        outgoing[u].append((v, weight, kind))
        indegree[v] += 1
    queue = [i for i, degree in enumerate(indegree) if degree == 0]
    heapq.heapify(queue)
    order: list[int] = []
    while queue:
        u = heapq.heappop(queue)
        order.append(u)
        for v, _, _ in outgoing[u]:
            indegree[v] -= 1
            if indegree[v] == 0:
                heapq.heappush(queue, v)
    if len(order) != node_count:
        raise AssertionError("schedule-induced graph contains a cycle")

    distance = [-10**18] * node_count
    parent: list[tuple[int, str, int] | None] = [None] * node_count
    distance[source] = 0
    for u in order:
        for v, weight, kind in outgoing[u]:
            candidate = distance[u] + weight
            if candidate > distance[v]:
                distance[v] = candidate
                parent[v] = (u, kind, weight)

    terminal = max(range(instance.n), key=lambda i: (distance[i] + instance.p[i], -i))
    fixed_order_makespan = distance[terminal] + instance.p[terminal]
    assert fixed_order_makespan == schedule.makespan

    chain_nodes = [terminal]
    chain_edges: list[dict[str, object]] = []
    current = terminal
    while current != source:
        parent_info = parent[current]
        if parent_info is None:
            raise AssertionError("critical-chain reconstruction failed")
        u, kind, weight = parent_info
        actual_u = 0 if u == source else schedule.start[u]
        actual_v = schedule.start[current]
        chain_edges.append(
            {
                "u": "source" if u == source else u,
                "v": current,
                "weight": weight,
                "kind": kind,
                "slack": actual_v - actual_u - weight,
            }
        )
        if u != source:
            chain_nodes.append(u)
        current = u
    chain_nodes.reverse()
    chain_edges.reverse()

    tight_counts = {"release": 0, "precedence": 0, "machine": 0}
    for u, v, weight, kind in typed_edges:
        actual_u = 0 if u == source else schedule.start[u]
        if schedule.start[v] - actual_u - weight == 0:
            tight_counts[kind] += 1

    return {
        "fixed_order_makespan": fixed_order_makespan,
        "critical_terminal": terminal,
        "critical_nodes": chain_nodes,
        "critical_edges": chain_edges,
        "critical_edge_types": [edge["kind"] for edge in chain_edges],
        "tight_edge_counts": tight_counts,
    }


def instance_to_dict(instance: Instance) -> dict[str, object]:
    return {
        "p": list(instance.p),
        "release": list(instance.release),
        "edges": [{"u": e.u, "v": e.v, "lag": e.lag} for e in instance.edges],
        "machines": instance.machines,
        "family": instance.family,
        "instance_id": instance.instance_id,
    }


def instance_from_dict(data: dict[str, object]) -> Instance:
    return Instance(
        p=tuple(int(x) for x in data["p"]),
        release=tuple(int(x) for x in data["release"]),
        edges=tuple(
            Edge(int(edge["u"]), int(edge["v"]), int(edge["lag"]))
            for edge in data["edges"]
        ),
        machines=int(data["machines"]),
        family=str(data.get("family", "unspecified")),
        instance_id=str(data.get("instance_id", "")),
    )
