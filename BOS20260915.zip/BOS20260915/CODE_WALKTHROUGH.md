# BOS 程式碼導覽

## 1. 核心排程器：`experiments/bos_core.py`

最重要的三個入口：

- `bos_scores(instance)`：reverse topological DP，實作 `b_i=max{p_i,max(lag_ij+b_j)}`。
- `policy_scores(instance, policy)`：切換 BOS、HEFT-rank、GRPW、LPT、SPT、FIFO。
- `simulate(instance, policy)`：共用 event-driven simulator；處理 release、edge activation、completion 與 zero-lag same-time closure。

`validate_schedule` 不是裝飾：每次 `simulate` 返回前都會檢查 releases、所有 lag、machine overlap、completion 與 makespan。

其他可稽核函式：

- `path_lower_bounds`：計算 `W/m`、`L_delta`、`L_(r,delta)`。
- `verify_approximation_bound`：逐 schedule 驗證論文 theorem upper bound。
- `candidate_set_disagreement`：避免比較兩條已分岔 trace 的假「same state」。
- `augmented_dag_diagnostic`：建立 labeled release／precedence／machine arcs，重建 critical chain。

## 2. Instance generators：`experiments/generators.py`

`generate_instance` 的所有隨機性都來自明示的 NumPy seed。processing time、DAG family、target overlap、actual edge lag、release policy 與 instance ID 都可回推。四個 family 是：

- `chain_heavy`
- `fork_join`
- `merge_heavy`
- `random_layered`

## 3. Certified optimum：`experiments/exact_solver.py`

`solve_exact` 建立 time-indexed MILP：每個 task 恰好選一個 integer start time、每個 time slot 同時執行量不超過 `m`、每條 start--start lag 成立，並最小化 makespan。只有 solver success、optimal status、decoded feasibility 與 zero MIP gap 才納入 exact CSV。

## 4. 一鍵重跑：`experiments/run_experiments.py`

```bash
PYTHONPATH=. python -m experiments.run_experiments --profile paper --all
```

五個 phase：

1. `run_main`：5,760 instances、六個 heuristic。
2. `run_exact`：576 個小型 MILP。
3. `run_runtime`：BOS／HEFT-rank scaling。
4. `run_case_search`：找 BOS 最大 win/loss 並保存 JSON certificate。
5. `analyze`：從 raw CSV 重新產生圖、表、cluster-bootstrap CI 與 manuscript numbers。

`--profile smoke --all` 是快速端到端驗證；`--extend-baselines --analyze` 可在已有 certified optimum CSV 時只補跑新增 deterministic policies，不重解 MILP。

## 5. Tests：`tests/test_bos.py`

測試涵蓋 singleton bottom level、zero-lag simultaneous start、AND-precedence、GRPW merge 去重、SPT/LPT 相反順序、已知 exact optimum、random feasibility 與 bound、augmented-DAG makespan，以及 candidate disagreement 值域。
