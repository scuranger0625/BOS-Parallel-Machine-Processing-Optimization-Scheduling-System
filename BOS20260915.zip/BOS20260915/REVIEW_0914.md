# BOS 論文 0914 版審查報告

## 結論

0914 版不是「演算法完全錯了」，而是**理論核心可救、論文定位與實驗證據必須大修**。最值得保留的是 start--start lag 模型、overlap-adjusted bottom level、event-driven implementation 與 single blocking-chain proof。最需要撤回的是 online／partial-kit 的過度詮釋、把通用 list-scheduling bound 當成 BOS 特有優勢，以及不可重現或過強的實驗結論。

## 逐項問題與處理

| 嚴重度 | 0914 版問題 | 為什麼有風險 | 0915 版處理 |
|---|---|---|---|
| 高 | 把 event-driven 描述成 online／dynamic input | instance 的 DAG、processing time、release 與 lag 都在排程前已知；事件驅動只是 simulator 實作 | 明確定義為 offline scheduling；online graph/data change 移到 future work |
| 高 | 使用 partial-kit 語言 | 現有 executable condition 要求**所有** incoming lags 成立，是 AND semantics，不是收到任意部分 components 即可 | 改稱 bounded overlap／progressive handoff；明確排除 OR/subset semantics |
| 高 | 理論保證容易被讀成 BOS-specific | blocking-chain proof 只用 work conservation，沒有使用 BOS priority | 定理改寫為適用所有 work-conserving list policies；BOS priority 的價值只由實驗判斷 |
| 高 | start--start lag 被暗示為模型首創 | generalized temporal precedence／RCPSP/max 已有長期文獻 | 新增 Bartusch、Hartmann–Briskorn、Schwindt、Schutt 等來源並縮窄 novelty claim |
| 高 | HEFT baseline 命名不精確 | 完整 HEFT 包含 heterogeneous processor 與 earliest-finish processor selection；原實驗只取 rank 概念 | 改名 HEFT-rank，並讓它與 BOS 共用完全相同的 feasibility／dispatch engine |
| 高 | 「同一 state 的 decision disagreement」不成立 | 兩個 schedule 一旦早期選擇不同，後續 ready set 與 machine state 已經不同 | 改為收集兩條 trace 出現的 candidate sets，再離線用兩個 score 評分同一集合 |
| 高 | 「小型案例 BOS 全部 optimal」不可驗證且實際為假 | 0914 專案沒有 exact model、solver status、raw results 或 seeds；新實驗找到 BOS 非最優案例 | 加入 time-indexed MILP；576/576 status optimal、MIP gap 0；誠實報告 BOS mean gap 與反例 |
| 高 | 圖檔無法追溯至數字 | 沒有 raw CSV、generator parameters、seed、confidence interval 或一鍵重跑 script | 全部圖表由 `run_experiments.py` 從 CSV 產生，保存逐例結果與 JSON certificates |
| 中 | augmented DAG 沒處理相同 endpoints 的不同 constraint | precedence arc 與 machine-order arc 可能重合但 weight、語義不同 | 定義為 labeled arc multiset；診斷分別保存 release／precedence／machine arcs |
| 中 | augmented-DAG longest path 的 equality scope 過寬 | 任意 feasible schedule 可以刻意 idle，固定-order earliest schedule 未必等於原 schedule | equality 限定於 work-conserving event-driven list schedule，並補上 tight incoming constraint 證明 |
| 中 | bottom-level 必須包含 singleton path | 高 overlap 時 `lag + successor score` 可能小於 task 自身 processing time | 使用 `b_i=max{p_i,max(lag_ij+b_j)}`，並加入 unit test |
| 中 | zero-lag simultaneous activation 未完整規格化 | predecessor 與 successor 可能同 timestamp start；若事件未閉包會錯過合法 dispatch | 明確加入 same-time closure，測試 successor 可在 lag 0 同時啟動 |
| 中 | proof 中有 `ell` 排版 typo，且 charging 解釋不夠防誤讀 | 若分別對多條 idle path 加總，可能重複 charge 互不相容的 paths | 修正為一條 schedule-dependent blocking chain 與 disjoint prefixes |
| 中 | release-time case 不能直接沿用 zero-release formula | 單一晚到 task 已構成反例 | 分別證明 zero-release `(2-1/m)` 與 arbitrary-release `2` approximation |
| 中 | 舊 bibliography 有不相干、重複或錯位條目 | book review、networking ML、Toyota 引用等不能支撐當前 scheduling claim | bibliography 重建為 12 筆直接相關的一手／經典來源 |

## 新實驗設計

所有 heuristic 只更換 priority，其他條件完全相同：BOS、HEFT-rank、GRPW、LPT、SPT、FIFO。另以 MILP 求小型最優解。

- 主實驗：4 families × 3 task sizes × 3 machine counts × 4 overlap targets × 2 release policies × 20 seeds = **5,760 instances**。
- Heuristic schedules：5,760 × 6 = **34,560 runs**。
- Exact：4 families × 2 sizes × 2 machine counts × 3 overlap targets × 2 releases × 6 seeds = **576 certified optima**，失敗 0。
- Contrast search：4,000 個 `n=12,m=3` instances，最大 BOS win／loss 再由 MILP 認證。
- Runtime：`n={100,500,1000,2500,5000}`，兩個 families、八次重複。
- 所有 34,560 heuristic schedules 的 feasibility 與 theorem bound violations：**0**。

chain-heavy family 是 forced-backbone sanity check，六個 priority 全部同解。它保留在 raw audit，但從 comparative statistics 排除，避免用大量結構性 ties 稀釋差異；`alpha=0` 同理保留為 BOS=HEFT-rank 的 sanity condition。

## 最重要的重跑結果

### Positive-overlap、非 trivial families（每種 release 1,620 對）

| Comparator | BOS mean advantage，zero release | Win / Tie / Loss | BOS mean advantage，uniform release | Win / Tie / Loss |
|---|---:|---:|---:|---:|
| HEFT-rank | 0.188% | 551 / 807 / 262 | 0.140% | 552 / 795 / 273 |
| GRPW | 0.283% | 593 / 763 / 264 | 0.191% | 561 / 806 / 253 |
| LPT | 1.577% | 1202 / 363 / 55 | 1.132% | 1165 / 400 / 55 |
| SPT | 2.975% | 1436 / 151 / 33 | 2.118% | 1430 / 156 / 34 |
| FIFO | 1.819% | 1329 / 226 / 65 | 1.319% | 1309 / 256 / 55 |

正值代表 BOS makespan 較小。BOS 對所有 comparator 的**平均值**較好，但 win/loss counts 明確顯示沒有 pointwise dominance。

### 432 個非 trivial certified exact cases

| Policy | Mean optimality gap | Maximum gap | Optimum hit rate |
|---|---:|---:|---:|
| BOS | **1.783%** | 17.33% | 61.6% |
| HEFT-rank | 1.809% | 17.33% | **63.0%** |
| GRPW | 1.803% | **15.56%** | 62.0% |
| LPT | 2.578% | 27.59% | 55.3% |
| SPT | 6.225% | 34.48% | 25.7% |
| FIFO | 3.982% | 28.95% | 41.9% |

BOS 的 mean gap 最低；HEFT-rank hit rate 最高；GRPW maximum gap 最低。這才是可信的結論，不是「BOS 永遠最好」。

### 認證反例

- 最大 BOS win：merge-heavy、target overlap 0.75、zero release，`BOS=38=OPT`、`HEFT-rank=44`，BOS advantage 13.64%。
- 最大 BOS loss：random-layered、target overlap 0.90、zero release，`BOS=41`、`HEFT-rank=35=OPT`，BOS advantage -17.14%。

## 建議投稿前仍要補的東西

1. 至少一組公開 RCPSP/max 衍生 benchmark 或真實 production trace；目前 synthetic evidence 不足以支撐產業泛化。
2. 若要保留「partial kit」術語，必須另建 OR/subset activation model，現有 AND model 不夠。
3. 若要主張 online，需定義 reveal model、competitive benchmark 與不可預知資訊；event-driven simulator 本身不等於 online algorithm。
4. 若版面允許，加入更強 search-based heuristic（例如 multi-start priority sampling）時必須控制相同時間預算，不能拿單次 BOS 和高成本 solver 不對等比較。
