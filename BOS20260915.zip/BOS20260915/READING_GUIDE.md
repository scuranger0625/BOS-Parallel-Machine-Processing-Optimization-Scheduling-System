# BOS 推薦參考文獻導讀

以下不是「湊 citation 數量」，而是針對 0914 版最容易被 reviewer 攻擊的五個位置：模型定位、approximation proof、HEFT 命名、priority-rule baseline、exact benchmark。

## 第一優先：投稿前必讀

### 1. Hartmann & Briskorn (2022), *An Updated Survey of Variants and Extensions of the RCPSP*

- 連結：[Publisher / DOI](https://doi.org/10.1016/j.ejor.2021.05.004)
- 建議看：問題分類、temporal constraints、generalized precedence 的段落。
- 對 BOS 的用途：把 start--start lag 放回既有 RCPSP/generalized-precedence 地圖，避免把模型元件說成首創。
- 你要帶走的判斷：BOS 的 novelty 應放在「受限 identical-machine specialization 的證明、priority 與診斷」，不是「發明 time lag」。

### 2. Graham (1969), *Bounds on Multiprocessing Timing Anomalies*

- 連結：[SIAM / DOI](https://doi.org/10.1137/0117039)
- 建議看：list scheduling 的 capacity accounting 與 critical-chain／idle-time proof 思路。
- 對 BOS 的用途：0915 版 `(2-1/m)` proof 的祖先；也提醒我們 bound 來自 work conservation，不是 BOS score。
- 你要帶走的判斷：理論要寫成「這個 list-scheduler class 有保證」，不能寫成「因此 BOS priority 勝過 HEFT」。

### 3. Bartusch, Möhring, & Radermacher (1988), *Scheduling Project Networks with Resource Constraints and Time Windows*

- 連結：[Springer](https://link.springer.com/article/10.1007/BF02283745)
- 建議看：general temporal constraints 與 project-network representation。
- 對 BOS 的用途：這是模型 lineage 的早期核心來源；能支撐 minimum time lag 不是新概念。
- 你要帶走的判斷：related work 必須主動承認 generalized temporal scheduling，而不是等 reviewer 指出。

### 4. Topcuoglu, Hariri, & Wu (2002), *Performance-Effective and Low-Complexity Task Scheduling for Heterogeneous Computing*

- 連結：[IEEE / DOI](https://doi.org/10.1109/71.993206)
- 建議看：upward rank 公式、processor-selection phase，以及 HEFT 完整流程。
- 對 BOS 的用途：說清楚本實驗只使用 HEFT-derived rank；完整 HEFT 的 heterogeneous costs 與 insertion-based processor selection 沒有被執行。
- 你要帶走的判斷：baseline 名稱改成 **HEFT-rank** 是必要的學術精確，不是文字潔癖。

### 5. Kolisch (1996), *Serial and Parallel RCPSP Methods Revisited: Theory and Computation*

- 連結：[ScienceDirect](https://www.sciencedirect.com/science/article/pii/0377221795003576)
- 建議看：serial／parallel schedule generation、single-pass priority rules 與 computational comparison。
- 對 BOS 的用途：支撐新增的 GRPW、LPT、SPT baseline，並提醒 priority-rule 表現應在共同 schedule-generation engine 中比較。
- 你要帶走的判斷：只跟 HEFT 比太窄；加入不同資訊來源的 dispatch rules 才能判斷 overlap-aware score 的增益來自哪裡。

### 6. Schutt, Feydy, Stuckey, & Wallace (2013), *Solving RCPSP/max by Lazy Clause Generation*

- 連結：[Open preprint](https://arxiv.org/abs/1009.0347)；[Journal DOI](https://doi.org/10.1007/s10951-012-0285-x)
- 建議看：RCPSP/max model、exact search、benchmark 與「找到解」和「證明最優」的區別。
- 對 BOS 的用途：支撐小型 exact experiment 的必要性，也提供未來換成標準 benchmark／更強 exact solver 的路線。
- 你要帶走的判斷：沒有 solver status、bound 與 gap，就不能把 heuristic schedule 稱為 optimal。

## 第二優先：用來補理論背景

### 7. Hartmann & Briskorn (2010), *A Survey of Variants and Extensions of the RCPSP*

- 連結：[Open author PDF](https://www.hsba.de/fileadmin/user_upload/bereiche/_dokumente/6-forschung/profs-publikationen/Hartmann_2010_A_Survey_of_Variants_and_Extensions_of_the_Resource-Constraints_Project_Scheduling_Problem.pdf)
- 用途：比 2022 update 更完整地建立舊有分類脈絡；若只能先讀一篇，先讀 2022。

### 8. Schwindt (2005), *Resource Allocation in Project Management*

- 連結：[Springer / DOI](https://doi.org/10.1007/3-540-27852-4)
- 用途：generalized precedence、time windows 與 resource-constrained project scheduling 的系統性專書；適合寫 thesis chapter，不必在 conference paper 逐章展開。

### 9. Brucker et al. (1999), *Resource-Constrained Project Scheduling: Notation, Classification, Models, and Methods*

- 連結：[Publisher / DOI](https://doi.org/10.1016/S0377-2217(98)00204-5)
- 用途：標準 notation 與 model classification；適合校正問題符號和 related-work 範圍。

## 我建議的閱讀順序

如果只有兩小時：**Hartmann 2022 → HEFT 2002 → Graham 1969**。

如果準備投稿 rebuttal：再加 **Bartusch 1988 → Kolisch 1996 → Schutt 2013**。這六篇剛好對應 reviewer 最可能問的六句話：模型以前有沒有、bound 從哪來、HEFT 有沒有真的跑、baseline 是否太弱、optimal 怎麼證明、novelty 到底在哪。
