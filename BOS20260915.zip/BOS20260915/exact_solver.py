"""Certified small-instance optimum using a time-indexed MILP.

The model is exact for integer processing times, release dates, and lags.  A
binary variable x[i,t] says that task i starts at integer time t.  Aggregate
capacity constraints are sufficient for identical machines because a set of
fixed intervals with maximum overlap m can be greedily colored onto m machines.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix

from .bos_core import Instance, Schedule, simulate


@dataclass(frozen=True)
class ExactResult:
    optimum: int
    starts: tuple[int, ...]
    status: int
    message: str
    mip_gap: float
    solve_seconds: float


def _greedy_upper_bound(instance: Instance) -> int:
    return min(
        simulate(instance, policy).makespan
        for policy in ("bos", "heft_rank", "grpw", "lpt", "spt", "fifo")
    )


def solve_exact(instance: Instance, time_limit: float = 30.0) -> ExactResult:
    """Solve one small instance to proven optimality or raise RuntimeError."""

    import time

    horizon = _greedy_upper_bound(instance)
    starts_for_task: list[list[int]] = []
    variable_for: dict[tuple[int, int], int] = {}
    variable_count = 0
    for i in range(instance.n):
        candidates = list(range(instance.release[i], horizon - instance.p[i] + 1))
        if not candidates:
            raise RuntimeError(f"no feasible start-time variable for task {i}")
        starts_for_task.append(candidates)
        for t in candidates:
            variable_for[i, t] = variable_count
            variable_count += 1
    makespan_variable = variable_count
    variable_count += 1

    objective = np.zeros(variable_count)
    objective[makespan_variable] = 1.0
    integrality = np.ones(variable_count, dtype=np.uint8)
    integrality[makespan_variable] = 0
    lower = np.zeros(variable_count)
    upper = np.ones(variable_count)
    upper[makespan_variable] = float(horizon)

    rows: list[int] = []
    cols: list[int] = []
    values: list[float] = []
    constraint_lower: list[float] = []
    constraint_upper: list[float] = []
    row = 0

    def add_constraint(coefficients: list[tuple[int, float]], lb: float, ub: float) -> None:
        nonlocal row
        for column, value in coefficients:
            rows.append(row)
            cols.append(column)
            values.append(value)
        constraint_lower.append(lb)
        constraint_upper.append(ub)
        row += 1

    # Exactly one start time per task.
    for i in range(instance.n):
        add_constraint(
            [(variable_for[i, t], 1.0) for t in starts_for_task[i]],
            1.0,
            1.0,
        )

    # At most m simultaneously executing tasks in every unit interval.
    for tau in range(horizon):
        active: list[tuple[int, float]] = []
        for i in range(instance.n):
            first = max(instance.release[i], tau - instance.p[i] + 1)
            last = min(tau, horizon - instance.p[i])
            for t in range(first, last + 1):
                if (i, t) in variable_for:
                    active.append((variable_for[i, t], 1.0))
        if active:
            add_constraint(active, -np.inf, float(instance.machines))

    # Start--start precedence: s_v - s_u >= lag_uv.
    for edge in instance.edges:
        coefficients = [
            (variable_for[edge.v, t], float(t)) for t in starts_for_task[edge.v]
        ]
        coefficients.extend(
            (variable_for[edge.u, t], float(-t)) for t in starts_for_task[edge.u]
        )
        add_constraint(coefficients, float(edge.lag), np.inf)

    # Makespan >= s_i + p_i.
    for i in range(instance.n):
        coefficients = [(makespan_variable, 1.0)]
        coefficients.extend(
            (variable_for[i, t], float(-t)) for t in starts_for_task[i]
        )
        add_constraint(coefficients, float(instance.p[i]), np.inf)

    matrix = coo_matrix(
        (np.asarray(values), (np.asarray(rows), np.asarray(cols))),
        shape=(row, variable_count),
    ).tocsr()
    constraints = LinearConstraint(
        matrix,
        np.asarray(constraint_lower),
        np.asarray(constraint_upper),
    )
    started_at = time.perf_counter()
    result = milp(
        c=objective,
        integrality=integrality,
        bounds=Bounds(lower, upper),
        constraints=constraints,
        options={"time_limit": time_limit, "mip_rel_gap": 0.0, "presolve": True},
    )
    elapsed = time.perf_counter() - started_at
    if not result.success or result.x is None:
        raise RuntimeError(
            f"exact solve failed for {instance.instance_id}: "
            f"status={result.status}, message={result.message}"
        )

    starts = []
    for i in range(instance.n):
        chosen = max(starts_for_task[i], key=lambda t: result.x[variable_for[i, t]])
        starts.append(int(chosen))
    optimum = int(round(result.fun))
    if max(starts[i] + instance.p[i] for i in range(instance.n)) != optimum:
        raise AssertionError("MILP objective and decoded starts disagree")
    for edge in instance.edges:
        if starts[edge.v] < starts[edge.u] + edge.lag:
            raise AssertionError("decoded exact solution violates a lag")
    for tau in range(optimum):
        active = sum(
            starts[i] <= tau < starts[i] + instance.p[i]
            for i in range(instance.n)
        )
        if active > instance.machines:
            raise AssertionError("decoded exact solution violates capacity")

    return ExactResult(
        optimum=optimum,
        starts=tuple(starts),
        status=int(result.status),
        message=str(result.message),
        mip_gap=float(getattr(result, "mip_gap", 0.0)),
        solve_seconds=elapsed,
    )
