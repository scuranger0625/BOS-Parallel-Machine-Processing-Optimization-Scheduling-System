@echo off
cd /d "%~dp0"
where latexmk >nul 2>nul
if errorlevel 1 (
  echo Please install TeX Live or MiKTeX with latexmk, then run this file again.
  pause
  exit /b 1
)
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
if errorlevel 1 pause
