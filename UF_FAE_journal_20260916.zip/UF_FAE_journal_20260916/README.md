# UF-FAE 期刊修訂套件｜2026-09-16

先看 `投稿改寫總整理.md`，英文稿直接開 `main.pdf`。

本套件包含：
- `main.tex`：完整英文修訂稿，採通用單欄期刊審閱格式。
- `references.bib`：核心來源 BibTeX。
- `main.pdf`：已編譯的閱讀版。
- `main.bbl`：本次 BibTeX 編譯結果，方便編輯系統使用。
- `build.bat`：Windows 編譯入口。
- `build.sh`：Linux／macOS 編譯入口。
- `投稿改寫總整理.md`：繁體中文選刊、審查與補實驗計畫。
- `source_manifest.json`：五份來源的檔名、SHA-256、用途與本次驗證界限。

你不需要 Overleaf。若只讀稿，直接開 PDF；若要在本機重編譯，需先有 TeX Live 或 MiKTeX，以及 latexmk。Windows 執行 build.bat；Linux/macOS 執行 bash build.sh。亦可執行 `latexmk -pdf main.tex`。

沒有使用未安裝的 elsarticle 類別；這是可攜審稿布局，不宣稱已符合特定期刊最新全部投稿規則。正式投稿前再依確認的出版社模板與作者指南轉換。未使用外部圖片，因此沒有遺漏圖片路徑的問題。

科學狀態：原稿結果僅轉錄，沒有新實驗。圖特徵時間合法性、公平消融和完整成本仍待驗證。PDF 內保留狀態註記；不得只刪註記就當成投稿終稿。原始附件保持不變。

本稿匿名；作者姓名、研究時單位、現址、共同作者與聲明在正式送件前另確認。
