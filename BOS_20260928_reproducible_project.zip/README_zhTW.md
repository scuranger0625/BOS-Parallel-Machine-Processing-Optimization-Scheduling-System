# BOS：2026-09-28 IEEE 論文與可重現程式

這份專案接續 2026-09-15 版本，保留 nominal BOS 的核心，再新增進度檢查點恢復、兩種不同目標的 LP、容錯證明及新實驗。原始 0915 檔案沒有被覆寫。

## 先看哪幾個檔案

| 檔案 | 內容 |
|---|---|
| `BOS_IEEE_20260928.pdf` | IEEEtran conference 雙欄、10 頁英文研究稿，含完整證明、LP、實驗與限制 |
| `BOS_IEEE_20260928.tex`、`sections/`、`refs.bib` | 可編輯 LaTeX 原稿；主檔不能單獨編譯，須保留這些相依檔 |
| `experiments/bos_core.py` | nominal／segment list scheduler、BOS 等優先權、下界與可行性檢查 |
| `experiments/recovery.py` | 凍結已完成進度、切割工作檢查點、建立剩餘 DAG、物理驗證、固定順序修補、恢復入口 |
| `experiments/optimization.py` | 最小完工 LP／MILP，以及最大可容忍延遲 LP／MILP |
| `experiments/run_revision.py` | 主要 nominal、exact、固定延遲恢復實驗 |
| `experiments/delay_tolerance.py` | 固定交付期限後，搜尋最大的可行到料延遲 |
| `experiments/random_baseline.py` | 32 組隨機優先序＋兩個 greedy 的固定計算量比較基準 |
| `experiments/verify_results.py` | 讀取保存的排程見證，重新驗證可行性、上下界與期限 |
| `results/` | CSV、JSONL 原始排程、求解狀態、環境版本與驗證結果 |
| `CODE_WALKTHROUGH_zhTW.md` | 數學公式、論文章節和程式的對照 |
| `run_all.py` | 跨平台完整重跑入口 |

## 兩種 LP 不要混在一起

**LP 1：固定延遲，最小化完工時間。** 輸入已知的到料延遲 D，求 LP makespan 下界，將分數解的期望開始時間轉為優先序，交由實際 ready-set 排程器執行。此時 LP 和 greedy 都承受相同延遲，不能拿 LP 的結果與沒有延遲的 nominal BOS 比。

**LP 2：固定交付期限，最大化可容忍延遲。** 先給期限 T，再求材料最多可以延遲多久。這才直接對應「有交付鬆弛，可以容忍多少遲到」的問題。LP 最佳值是可承受延遲的上界，仍要 rounding 成可執行排程，再驗證真的能準時交付。二元版本提供小型案例的最優容錯量。

LP 的 fractional start variables 不是把同一工作分身到多台機器上；程式的 rounding 是把分數開始分布轉成優先序。工作能暫停是檢查點模型的能力，並不等於 rounding 本身。

## 核心證明

對固定過去進度後的剩餘 DAG，令 m 為機器數、D 為最大剩餘 release，OPT_rec 為同一剩餘模型的最優完工時間：

`C_rec <= (2 - 1/m) * OPT_rec + D/m`。

若 B 是有效的剩餘最優解下界，而且 `D <= m * epsilon * B`，則：

`C_rec <= (2 - 1/m + epsilon) * OPT_rec`。

D 是時間，epsilon 沒有單位。這是有條件的保證，不是把任何延遲直接稱為 epsilon，也不是 LP 獨有的改善。證明適用所有符合條件的 work-conserving list policies。

**比較基準固定了相同的過去執行、可中斷點、材料條件與機器數。** 沒有宣稱相對於能改寫歷史的全域最優解、任意位置搶先中斷、未知未來事件或機台故障仍維持此界限。機器中斷與移轉成本目前皆為零。

## 這次實際跑出的結果

- 2,880 個 nominal instances，六種策略，共 17,280 份排程。
- 96 個 nominal 小型精確求解。
- 216 個固定延遲恢復精確求解。
- 216 個固定期限、最大容錯量精確求解。
- 共 **528 個精確 oracle 案例**；全部 status 0，最大回報 MIP gap 約 `2.60e-15`（浮點容差）。
- **17 項測試通過**；保存的排程與期限見證重新驗證後，沒有發現可行性或適用界限違反。

固定期限的平均可承受延遲（同一批 216 組 prefix/deadline 案例）：

| 策略 | 平均可承受延遲 | 平均距離最優容錯量 | 達最優案例 |
|---|---:|---:|---:|
| 保留原機台及順序的修補 | 5.963 | 5.898 | 12 / 216 |
| Greedy-2 恢復 | 11.634 | 0.227 | 198 / 216 |
| Reserve-LP 單獨排序 | 10.569 | 1.292 | 89 / 216 |
| Reserve-hybrid：greedy 與容錯 LP 擇優 | 11.801 | 0.060 | 204 / 216 |
| Random-32 擇優 | 11.852 | 0.009 | 214 / 216 |

Reserve-LP 有 22 個案例需要退回已知可行的「零延遲原計畫」，表中已保留而未排除。這些是合成時間單位，不能換算為工廠分鐘。

結果支持第二層重排的作用，但大部分收益來自可中斷／移轉與重排本身，尚不能說是 LP 造成。Random-32 在這些小型例子品質更好，容錯搜尋的平均規劃成本也較高。不能隱藏這個基準來宣稱 LP 是最好的方法。

## 如何執行（Windows 也可以）

先把 ZIP **完整解壓**，在有 `run_all.py` 的根目錄開啟終端機：

```bash
python -m pip install -r requirements.txt
python run_all.py --verify-only
python run_all.py
```

建議 Python 3.12；套件鎖定本次環境版本。`--verify-only` 執行測試並重新檢查附帶資料，不重跑 MILP。完整執行會覆寫專案內的 `results/`、`tables/`、`figures/`；要保留本次基準數據，先複製資料夾。執行時間依電腦不同，MILP 單例上限 20 秒。

單獨重跑：

```bash
python -m experiments.run_revision --suite nominal
python -m experiments.run_revision --suite exact
python -m experiments.run_revision --suite recovery
python -m experiments.random_baseline
python -m experiments.delay_tolerance
python -m experiments.analyze_revision
python -m experiments.analyze_tolerance
python -m experiments.verify_results
```

`random_baseline` 與 `delay_tolerance` 需要先有 `recovery_certificates.jsonl`。模組需在專案根目錄使用 `python -m ...`；單獨下載一個 `.py` 主要供閱讀，並不包含它的套件相依檔。

## 編譯 IEEE 論文

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error BOS_IEEE_20260928.tex
```

或將完整 ZIP 匯入 Overleaf，設定 `BOS_IEEE_20260928.tex` 為主檔，使用 pdfLaTeX。ZIP 已包含 IEEEtran 類別、BST、algorithm 套件、章節、圖與表。這是通用 IEEE conference 排版，尚未針對某一會議的頁數限制、匿名規範或 PDF eXpress 作最終投稿處理。作者英文名與 email 沿用 0915 原稿。

## 投稿成熟度

目前可交給老師審查模型、證明與實驗，不等同於已完成特定刊會的投稿版本。仍需補公開／真實資料、較大恢復 DAG、更多獨立亂數種子、正的移轉／切換成本，以及時間預算控制的更強基準；需要確認製造流程真的允許所設定的檢查點。沒有實驗支持的機器故障、多事件線上競爭比及任意 partial-kit OR 模型，沒有被包裝成已完成貢獻。
