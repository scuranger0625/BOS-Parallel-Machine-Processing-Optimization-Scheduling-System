import unittest
from experiments.bos_core import Edge,Instance,simulate,path_lower_bounds
from experiments.recovery import build_recovery,validate_recovery
from experiments.optimization import optimize

class RecoveryTests(unittest.TestCase):
    def test_elapsed_time_is_not_progress(self):
        i=Instance((10,2),(0,0),(Edge(0,1,6),),2)
        rec=build_recovery(i,simulate(i),3,{0:(3,10)})
        rs=simulate(rec.residual);validate_recovery(rec,rs)
        child=next(k for k,(j,a,b) in enumerate(rec.segments) if j==1)
        self.assertGreaterEqual(3+rs.start[child],13)
    def test_zero_lag_and_simultaneous_start(self):
        i=Instance((5,4,2),(0,0,0),(Edge(0,1,0),Edge(1,2,2)),2)
        rec=build_recovery(i,simulate(i),0,{0:(2,7)})
        for p in ['bos','heft_rank','fifo']:
            validate_recovery(rec,simulate(rec.residual,p))
    def test_lp_lower_bound_and_exact(self):
        i=Instance((4,3,2),(0,4,0),(Edge(0,2,2),),2)
        lp,s=optimize(i);ex,e=optimize(i,True)
        self.assertEqual(ex['status'],0)
        self.assertLessEqual(lp['objective'],ex['objective']+1e-6)
        self.assertLessEqual(ex['objective'],s.makespan)
    def test_release_budget_bound(self):
        for r in range(8):
            i=Instance((2,5,3),(r,0,0),(Edge(0,2,1),),2)
            s=simulate(i);w,l,lr=path_lower_bounds(i)
            self.assertLessEqual(s.makespan,w+.5*lr+r/2+1e-8)
    def test_work_conservation_on_single_machine(self):
        i=Instance((6,4,3),(0,0,0),(Edge(0,2,2),),1)
        rec=build_recovery(i,simulate(i),1,{0:(1,8)})
        validate_recovery(rec,simulate(rec.residual))

if __name__=='__main__':unittest.main()
