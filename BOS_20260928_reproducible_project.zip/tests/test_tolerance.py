import unittest
from unittest.mock import patch
from experiments.bos_core import Instance,Edge,simulate
from experiments.recovery import build_recovery,validate_recovery,fixed_plan_repair,plan_recovery
from experiments.optimization import optimize_delay

class ToleranceTests(unittest.TestCase):
    def case(self):
        i=Instance((10,2),(0,0),(Edge(0,1,6),),2)
        return build_recovery(i,simulate(i),3,{0:(3,3)})
    def test_fixed_deadline_delay_oracle(self):
        rec=self.case();gate=[k for k,(j,a,b) in enumerate(rec.segments) if j==0 and a==3]
        lp,_=optimize_delay(rec.residual,gate,17)
        ex,_=optimize_delay(rec.residual,gate,17,True)
        self.assertEqual(ex['status'],0)
        self.assertAlmostEqual(ex['objective'],10)
        self.assertGreaterEqual(lp['objective']+1e-6,ex['objective'])
    def test_fixed_order_repair_and_zero_delay_fallback(self):
        rec=self.case();s=fixed_plan_repair(rec);validate_recovery(rec,s)
        self.assertEqual(rec.tau+s.makespan,rec.nominal.makespan)
    def test_lp_failure_uses_greedy(self):
        rec=self.case()
        with patch('experiments.optimization.optimize',return_value=({'status':1},None)):
            result=plan_recovery(rec)
        self.assertIn(result['selected'],('bos','heft_rank'))
        validate_recovery(rec,result['schedule'])

if __name__=='__main__':unittest.main()
