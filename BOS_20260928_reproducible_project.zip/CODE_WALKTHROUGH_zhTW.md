# 程式與證明對照

## 1. 原始 BOS

`experiments/bos_core.py` 的 `bos_scores()` 由 sink 往前計算 `max(p_i, lag_ij + b_j)`。`simulate()` 維護 release、completion、activation 事件，以及真正 executable 的 ready heap。改變 priority 不會改變可行性條件。

這次新增 `scores_override`，讓 LP 與隨機優先序使用同一 dispatcher；新增 `record_decisions=False`，避免每步複製整個 ready set，否則舊版的診斷輸出可能超出論文所寫的核心複雜度。其他 nominal 語義保持一致。

論文 II–IV 節包含下界、BOS DP、單次執行、終止性與單一 blocking-chain 證明。

## 2. 做到一半遇到材料遲到

`recovery.py: build_recovery()`：

1. 在 tau 計算每項工作已完成多少 `progress`。
2. 在剩餘 handoff 門檻、材料 gate、完成點切成正長度的 segment。
3. 同一工作的前後段用 finish–start 邊串起來，禁止同一工作分身並行。
4. 前驅實際完成 handoff 所需工作量，才放行後繼第一段。
5. 已在 tau 前滿足的 gate 不再重複等待。
6. 材料到達時間減去 tau，轉成對應 segment 的 release。

`validate_recovery()` 不只檢查新 DAG；它還把片段接回原始工作，重新計算後繼開始時前驅已完成多少工作量，以及所有機台的區間是否互斥。這可以抓出「人停工了，但時鐘繼續走，所以誤以為原料已生產」的模型錯誤。

對應論文 V 節及 Theorem 9。

## 3. 固定延遲的 LP

`optimization.py: optimize()`：

- `integer=False`：連續 start-distribution LP，回傳 makespan 下界與每段工作的期望開始時間。
- `integer=True`：同一 formulation 的二元版本，求 segment 最優排程。
- LP rounding 使用 `scores_override=-means`，在每次 ready set 中先選期望開始較早者；不是直接四捨五入開始時間。

`recovery.py: plan_recovery()` 是固定延遲的公開入口；若 LP 失敗，仍回傳 BOS／HEFT-rank 中較好的可行排程與解析下界。

對應論文 VI 節。

## 4. 固定期限的容錯 LP

`optimization.py: optimize_delay()`：

- 固定剩餘 deadline horizon。
- 目標改為最大化共同 gate 到料延遲 D。
- 每個 gate 起始段的開始時間必須不早於 D。
- LP 給最大容錯量的上界；MILP 給小型案例的精確最優容錯量。

`delay_tolerance.py` 將這份 LP 的 expected starts 轉成 Reserve-LP 排序，逐個整數 D 驗證真正能否準時完工。沒有使用未經證明的 heuristic monotonicity 去二分搜尋。所有方法共享同一上界、同一 deadline、同一進度、同一 gate。

若某個 heuristic 在所有測試 D 都未能達標，退回已驗證可行的 D=0 原順序修補排程，並記錄 `zero_delay_fallback`。不會把失敗案例丟掉。`fixed_plan_repair()` 的機台與順序不變，作為保守修補比較對象。

對應論文 VII 節。注意：最小化 LP 的 optimum 是完成時間下界，最大化 LP 的 optimum 是延遲容量上界，方向相反。

## 5. epsilon 保證究竟在哪裡

論文 VIII 節 Theorem 12／Corollary 13：

- chain proof 得到 `C <= W/m + rho + (1-1/m)*Q`。
- 重寫成 `W/m + (1-1/m)*(rho+Q) + rho/m`。
- `rho+Q <= release-aware critical path`、`rho <= D`。
- 所以 `C <= (2-1/m)*OPT_rec + D/m`。
- 任取有效下界 B，驗證 `D <= m*epsilon*B`，即可推出目標比值。

程式 `run_revision.py: audit()` 逐例檢查較強的解析上界，並保存 `epsilon_cert`。`plan_recovery()` 若有成功 LP，會用更強的 LP 下界輸出證書。

DAG 的比較基準必須固定：不能把擁有更多切點的 OPT、原始無延遲 OPT、或從頭改變 nominal prefix 的 OPT 混用。

## 6. 原始資料如何追溯

| 結果檔 | 可檢查事項 |
|---|---|
| `nominal.csv`、`nominal_instances.jsonl` | 每個 instance 的 p、release、lag、六種排程與執行時間 |
| `exact_nominal_certificates.jsonl` | MILP status、gap、dual bound、最優 starts 與 machines |
| `recovery_certificates.jsonl` | nominal prefix、tau、progress、gates、segments、LP/MILP、每種恢復排程 |
| `random32_certificates.jsonl` | 隨機 seed、32 個 makespan、最後選用的排程 |
| `delay_tolerance_certificates.jsonl` | deadline、delay-LP 上界、MILP 最優 D、每個整數 D 的結果、可行排程見證 |
| `verification.json` | 從上述保存資料重新驗證的計數 |
| `summary.json` | 圖表與正文數字的彙整；以 raw CSV／JSONL 為最終追溯依據 |

## 7. 模型沒有偷偷新增哪些能力

檢查點之間不准中斷；移轉不代表同一工作可在兩台機器同時執行。材料 gate 的所有 incoming 條件仍然都必須成立。沒有模擬壞掉的機器、restart loss、未知後續事件、運輸時間或任意 OR/subset kit。

本稿中 LP 是可供比較的候選方法與容錯上界工具；實驗沒有支持「只要加 LP 就必然比 greedy 強」。這點在表格、原始碼與結論保持一致。
