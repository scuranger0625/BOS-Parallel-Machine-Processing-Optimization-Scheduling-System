# 0915 → 0928 變更紀錄

- 保留 start–start bounded-lag nominal 模型、BOS bottom level 與 single blocking-chain 證明。
- 修正 interrupted work 的語義：從經過時間改成累積完成工作量。
- 新增 checkpoint residual DAG 的構造與等價性證明；比較只針對同一 frozen prefix。
- 從 blocking-chain accounting 推導 `D/m` 加法容錯界限，寫明 epsilon 的充分條件與單位。
- 新增最小 makespan LP-list，並保留二元精確模型及求解狀態。
- 依使用者指出的目標差異，另新增固定交付期限最大化容錯 D 的 LP／MILP。
- LP 分數值經 ready-set list rounding 轉成可執行排程；只有實際通過驗證的 delay 才回報可容忍。
- 新增 matched greedy、固定原順序修補、Random-32、greedy／LP 組合消融。
- 全部論文結果來自本次執行，未把 0915 的 5,760／576 等數字當成本次結果。
- 新增輸出資料驗證、17 項回歸測試、跨平台重跑入口及繁體中文程式導讀。
- 使用 IEEEtran conference 雙欄格式；作者資訊沿用原稿，沒有擅自新增共同作者或資助聲明。

## 尚未宣稱完成

公開工廠資料、PSPLIB／RCPSP-max 原生 benchmark、特定 IEEE 刊會格式門檻、投稿操作、機台故障、正的 checkpoint 成本、對 unrestricted optimum 的全域比值、online competitive ratio。
