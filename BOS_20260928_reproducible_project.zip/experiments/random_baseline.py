"""Fixed-effort stochastic comparator; intentionally not an equal-time claim."""
import json,time
import numpy as np,pandas as pd
from .run_revision import OUT,audit,schedule_dict
from .bos_core import instance_from_dict,simulate,Schedule
from .recovery import Recovery,validate_recovery

def main():
    df=pd.read_csv(OUT/'recovery.csv');df=df[df.policy!='random32']
    rows=[]
    with (OUT/'random32_certificates.jsonl').open('w') as f:
        for line in (OUT/'recovery_certificates.jsonl').read_text().splitlines():
            data=json.loads(line);i=instance_from_dict(data['residual']);id=data['id']
            orig=instance_from_dict(data['instance']);s=data['nominal']
            nom=Schedule(s['policy'],tuple(s['start']),tuple(s['machine']),tuple(s['completion']),s['makespan'],tuple(s['start_order']),())
            rec=Recovery(orig,nom,data['tau'],tuple(data['progress']),{int(j):tuple(g) for j,g in data['gates'].items()},i,tuple(tuple(s) for s in data['segments']))
            rng=np.random.default_rng(424200+id);costs=[];best=None
            st=time.perf_counter()
            for k in range(32):
                scores=rng.random(i.n);s=simulate(i,'random',scores_override=scores,record_decisions=False)
                costs.append(s.makespan)
                if best is None or s.makespan<best.makespan:best=s
            elapsed=time.perf_counter()-st
            for p in ['bos','heft_rank']:
                s=simulate(i,p,record_decisions=False)
                if s.makespan<=best.makespan:best=s
            b=audit(i,best);physical=validate_recovery(rec,best)
            old=df[(df.id==id)&(df.policy=='greedy_portfolio')].iloc[0].to_dict()
            old.update(policy='random32',C=best.makespan,total_C=rec.tau+best.makespan,seconds=elapsed+old['seconds'],selected=best.policy,**b,**physical)
            rows.append(old)
            f.write(json.dumps({'id':id,'seed':424200+id,'sampled_makespans':costs,'selected':schedule_dict(best)})+'\n')
    pd.concat([df,pd.DataFrame(rows)],ignore_index=True).to_csv(OUT/'recovery.csv',index=False)
    print('random32 completed',len(rows))
if __name__=='__main__':main()
