"""User-requested objective: maximize tolerable common arrival delay at a
fixed final deadline, rather than minimize makespan for a prescribed delay.
"""
import json,csv,time
import numpy as np
from .run_revision import OUT,schedule_dict,audit
from .bos_core import Instance,Schedule,instance_from_dict,simulate
from .recovery import Recovery,validate_recovery,fixed_plan_repair
from .optimization import optimize_delay,schedule_from_starts

def decode(data,D):
    i=instance_from_dict(data['residual']);nom=data['nominal'];nominal=Schedule(nom['policy'],tuple(nom['start']),tuple(nom['machine']),tuple(nom['completion']),nom['makespan'],tuple(nom['start_order']),())
    gates={int(j):(g[0],data['tau']+D) for j,g in data['gates'].items()}
    nodes=[k for k,(j,a,b) in enumerate(data['segments']) if j in gates and a==gates[j][0]]
    actual=Instance(i.p,tuple(D if k in nodes else 0 for k in range(i.n)),i.edges,i.machines,i.family,i.instance_id)
    return Recovery(instance_from_dict(data['instance']),nominal,data['tau'],tuple(data['progress']),gates,actual,tuple(tuple(s) for s in data['segments'])),nodes

def main():
    rows=[];count=0
    with (OUT/'delay_tolerance_certificates.jsonl').open('w') as out:
        for line in (OUT/'recovery_certificates.jsonl').read_text().splitlines():
            data=json.loads(line)
            if data['id']%3:continue  # 72 unique prefixes, not 216 copies
            rec0,nodes=decode(data,0);base=rec0.residual
            for slack in (0,.25,.5):
                deadline=int(np.floor((1+slack)*rec0.nominal.makespan));H=deadline-rec0.tau
                st=time.perf_counter();lp,means=optimize_delay(base,nodes,H,False,20);lpwall=time.perf_counter()-st
                ex,_=optimize_delay(base,nodes,H,True,20)
                assert means is not None,lp
                upper=int(np.floor(lp['objective']+1e-6))
                methods=['fixed_repair','bos','greedy2','reserve_lp','reserve_hybrid','random32']
                best={p:-1 for p in methods};bestsch={};curve=[];times={p:0.0 for p in methods}
                # Exhaustive integer delay scan: do not assume heuristic monotonicity.
                for D in range(upper+1):
                    rec,_=decode(data,D);i=rec.residual
                    st=time.perf_counter();fixed=fixed_plan_repair(rec);times['fixed_repair']+=time.perf_counter()-st
                    st=time.perf_counter();bos=simulate(i,record_decisions=False);t1=time.perf_counter()-st;times['bos']+=t1
                    st=time.perf_counter();heft=simulate(i,'heft_rank',record_decisions=False);t2=time.perf_counter()-st;times['greedy2']+=t1+t2
                    st=time.perf_counter();lps=simulate(i,'reserve_lp',scores_override=-means,record_decisions=False);tl=time.perf_counter()-st;times['reserve_lp']+=tl;times['reserve_hybrid']+=t1+t2+tl
                    greedy=min([bos,heft],key=lambda s:s.makespan)
                    hybrid=min([bos,heft,lps],key=lambda s:s.makespan)
                    rng=np.random.default_rng(924200+data['id'])
                    st=time.perf_counter();rand=greedy
                    for k in range(32):
                        sch=simulate(i,'random',scores_override=rng.random(i.n),record_decisions=False)
                        if sch.makespan<rand.makespan:rand=sch
                    times['random32']+=time.perf_counter()-st+t1+t2
                    ss=dict(fixed_repair=fixed,bos=bos,greedy2=greedy,reserve_lp=lps,reserve_hybrid=hybrid,random32=rand)
                    for p,s in ss.items():
                        validate_recovery(rec,s)
                        if p!='fixed_repair':audit(i,s)
                        if s.makespan<=H:best[p]=D;bestsch[p]=schedule_dict(s)
                    curve.append({'D':D,**{p:s.makespan for p,s in ss.items()}})
                raw_failure={p:best[p]<0 for p in methods}
                fallback=fixed_plan_repair(rec0)
                assert fallback.makespan<=H
                for p in methods:
                    if raw_failure[p]:best[p]=0;bestsch[p]=schedule_dict(fallback)
                if ex['status']==0:
                    opt=int(round(ex['objective']));assert upper>=opt
                    assert all(v<=opt for v in best.values()),(best,opt)
                    er,_=decode(data,opt);es=schedule_from_starts(er.residual,ex['starts'],'delay_exact');validate_recovery(er,es)
                else:opt=None
                for p in methods:
                    rows.append(dict(id=count,base_id=data['id'],family=base.family,n=rec0.original.n,m=base.machines,slack=slack,deadline=deadline,tau=rec0.tau,policy=p,zero_delay_fallback=raw_failure[p],D_feasible=best[p],D_opt=opt if opt is not None else '',exact_status=ex['status'],exact_gap=ex['gap'],D_lp=lp['objective'],lp_seconds=lpwall,search_seconds=times[p],total_seconds=times[p]+lpwall))
                out.write(json.dumps({'id':count,'base_id':data['id'],'slack':slack,'deadline':deadline,'gate_nodes':nodes,'LP':lp,'exact':ex,'best_delays':best,'zero_delay_fallback':raw_failure,'best_schedules':bestsch,'curve':curve})+'\n');out.flush();count+=1
                if count%18==0:print('delay tolerance cases',count,flush=True)
    with (OUT/'delay_tolerance.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
if __name__=='__main__':main()
