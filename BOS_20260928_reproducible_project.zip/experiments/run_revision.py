"""Reproduce September 28 experiments. Run from the project root.
python -m experiments.run_revision --suite all
"""
import argparse,csv,json,itertools,time,platform,sys
from pathlib import Path
import numpy as np,scipy
from .bos_core import *
from .generators import generate_instance,FAMILIES
from .recovery import build_recovery,validate_recovery
from .optimization import optimize
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
POLICIES=('bos','heft_rank','grpw','lpt','spt','fifo')

def csvwrite(name,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def schedule_dict(s):
    return {'policy':s.policy,'start':s.start,'machine':s.machine,'completion':s.completion,'makespan':s.makespan,'start_order':s.start_order}

def audit(i,s):
    validate_schedule(i,s);verify_approximation_bound(i,s)
    w,l,lr=path_lower_bounds(i);D=max(i.release);alpha=2-1/i.machines
    sharp=w+(1-1/i.machines)*lr+D/i.machines
    assert s.makespan<=sharp+1e-7,(s.makespan,sharp)
    return {'lb':lower_bound(i),'release_max':D,'sharp_upper':sharp,
            'epsilon_cert':D/(i.machines*lower_bound(i)),
            'ratio_certificate':min(2,alpha+D/(i.machines*lower_bound(i)))}

def nominal():
    rows=[];k=0
    with (OUT/'nominal_instances.jsonl').open('w') as f:
        for fam,n,m,a,release,seed in itertools.product(FAMILIES,(24,64,128),(2,4,8),(0,.25,.5,.75),('zero','uniform'),range(10)):
            i=generate_instance(n=n,machines=m,family=fam,overlap=a,release_policy=release,seed=20260928+seed)
            schedules=[]
            for p in POLICIES:
                st=time.perf_counter();s=simulate(i,p,record_decisions=False);elapsed=time.perf_counter()-st
                b=audit(i,s)
                rows.append(dict(id=k,family=fam,n=n,m=m,overlap=a,release=release,seed=20260928+seed,policy=p,C=s.makespan,seconds=elapsed,**b))
                schedules.append(schedule_dict(s))
            f.write(json.dumps({'id':k,'instance':instance_to_dict(i),'schedules':schedules})+'\n');k+=1
    csvwrite('nominal.csv',rows);print('nominal instances',k,flush=True)

def exact_nominal():
    rows=[]
    with (OUT/'exact_nominal_certificates.jsonl').open('w') as f:
        for k,(fam,n,m,a,seed) in enumerate(itertools.product(FAMILIES,(8,12),(2,3),(.25,.75),range(3))):
            i=generate_instance(n=n,machines=m,family=fam,overlap=a,release_policy='zero',seed=280000+seed)
            result,s=optimize(i,True,20)
            rec={'id':k,'instance':instance_to_dict(i),'solver':result,'exact_schedule':schedule_dict(s) if s else None}
            f.write(json.dumps(rec)+'\n');f.flush()
            for p in POLICIES:
                sch=simulate(i,p,record_decisions=False);audit(i,sch)
                if s: assert sch.makespan>=s.makespan
                rows.append(dict(id=k,family=fam,n=n,m=m,overlap=a,seed=280000+seed,policy=p,C=sch.makespan,opt=s.makespan if s else '',status=result['status'],gap=result['gap'],seconds=result['seconds']))
            if (k+1)%16==0:print('nominal exact',k+1,flush=True)
    csvwrite('exact_nominal.csv',rows)

def recovery():
    rows=[];k=0
    with (OUT/'recovery_certificates.jsonl').open('w') as f:
        for fam,n,m,a,seed in itertools.product(('fork_join','merge_heavy','random_layered'),(8,12),(2,3),(.5,.8),range(3)):
            i=generate_instance(n=n,machines=m,family=fam,overlap=a,release_policy='zero',seed=928000+seed,processing_high=10)
            nominal=simulate(i,record_decisions=False);tau=max(1,int(nominal.makespan*.35))
            done=[max(0,min(i.p[j],tau-nominal.start[j])) for j in range(i.n)]
            rng=np.random.default_rng(61900+seed)
            eligible=[j for j in range(i.n) if done[j]<i.p[j]]
            affected=[j for j in eligible if done[j]>0 or rng.random()<.35]
            if not affected:affected=[eligible[0]]
            gates={j:(done[j] if done[j]>0 else i.p[j]//2,tau) for j in affected}
            zero=build_recovery(i,nominal,tau,gates);lb0=lower_bound(zero.residual)
            for severity in (0,.25,.75):
                D=int(np.ceil(severity*lb0));actual={j:(g,tau+D) for j,(g,_) in gates.items()}
                rec=build_recovery(i,nominal,tau,actual);ri=rec.residual
                schedules={};timings={}
                for p in POLICIES:
                    st=time.perf_counter();schedules[p]=simulate(ri,p,record_decisions=False);timings[p]=time.perf_counter()-st
                st=time.perf_counter();lp,ls=optimize(ri,False,20);lptime=time.perf_counter()-st
                assert ls is not None,lp
                schedules['lp_list']=ls;timings['lp_list']=lptime
                chosen_g=min(('bos','heft_rank'),key=lambda p:schedules[p].makespan)
                schedules['greedy_portfolio']=schedules[chosen_g];timings['greedy_portfolio']=timings['bos']+timings['heft_rank']
                chosen=min(('bos','heft_rank','lp_list'),key=lambda p:schedules[p].makespan)
                schedules['hybrid']=schedules[chosen];timings['hybrid']=timings['greedy_portfolio']+lptime
                ex,es=optimize(ri,True,20)
                if es:
                    validate_recovery(rec,es)
                    assert lp['objective']<=es.makespan+1e-6
                packed=[]
                for p,s in schedules.items():
                    b=audit(ri,s);physical=validate_recovery(rec,s)
                    if es:assert s.makespan>=es.makespan
                    # Delaying releases cannot hurt the zero-release optimum downward;
                    # all budget claims use the SAME checkpoint graph.
                    rows.append(dict(id=k,family=fam,n=n,m=m,overlap=a,seed=928000+seed,severity=severity,tau=tau,D=D,segments=ri.n,active=sum(0<d<i.p[j] for j,d in enumerate(done)),policy=p,C=s.makespan,total_C=tau+s.makespan,opt=es.makespan if es else '',exact_status=ex['status'],exact_gap=ex['gap'],lp_lb=lp['objective'],lp_fractional=lp['fractional_variables'],lp_seconds=lp['seconds'],seconds=timings[p],selected=chosen if p=='hybrid' else chosen_g if p=='greedy_portfolio' else p,lb0=lb0,**b,**physical))
                    packed.append({'label':p,**schedule_dict(s)})
                f.write(json.dumps({'id':k,'instance':instance_to_dict(i),'nominal':schedule_dict(nominal),'tau':tau,'progress':rec.progress,'gates':actual,'segments':rec.segments,'residual':instance_to_dict(ri),'lp':lp,'exact':ex,'exact_schedule':schedule_dict(es) if es else None,'schedules':packed})+'\n');f.flush();k+=1
                if k%18==0:print('recovery cases',k,flush=True)
    csvwrite('recovery.csv',rows)

def main():
    p=argparse.ArgumentParser();p.add_argument('--suite',choices=['all','nominal','exact','recovery'],default='all');args=p.parse_args()
    (OUT/'environment.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__,'seed_conventions':[20260928,280000,928000,61900],'time_limit_seconds':20},indent=2))
    if args.suite in ('all','nominal'):nominal()
    if args.suite in ('all','exact'):exact_nominal()
    if args.suite in ('all','recovery'):recovery()
if __name__=='__main__':main()
