"""Generate paper tables, figures and machine-readable summary from fresh CSVs."""
from pathlib import Path
import json
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'results';F=ROOT/'figures';T=ROOT/'tables';F.mkdir(exist_ok=True);T.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'legend.fontsize':7,'pdf.fonttype':42,'ps.fonttype':42})
LABELS={'bos':'BOS','heft_rank':'HEFT-rank','grpw':'GRPW','lpt':'LPT','spt':'SPT','fifo':'FIFO','lp_list':'LP-list','greedy_portfolio':'Greedy-2','hybrid':'BOS-LP','random32':'Random-32'}

def ci_cluster(vals,groups,seed=20260928):
    # Equal-size design cells: average within each shared-seed block first.
    d=pd.DataFrame({'v':np.asarray(vals),'g':np.asarray(groups)}).groupby('g').v.mean().to_numpy()
    rng=np.random.default_rng(seed);b=d[rng.integers(0,len(d),(5000,len(d)))].mean(axis=1)
    return [float(x) for x in np.quantile(b,[.025,.975])]

def table(path,header,rows,cols):
    s='\\begin{tabular}{'+cols+'}\n\\toprule\n'+' & '.join(header)+r' \\'+'\n\\midrule\n'
    s+='\n'.join(' & '.join(map(str,row))+r' \\' for row in rows)+'\n\\bottomrule\n\\end{tabular}\n'
    path.write_text(s)

def main():
    n=pd.read_csv(R/'nominal.csv');e=pd.read_csv(R/'exact_nominal.csv');r=pd.read_csv(R/'recovery.csv')
    w=n[(n.family!='chain_heavy')&(n.overlap>0)].pivot(index='id',columns='policy',values='C')
    meta=n.drop_duplicates('id').set_index('id').loc[w.index];groups=meta.seed.astype(str)
    nominal=[]
    for p in ('heft_rank','grpw','lpt','spt','fifo'):
        g=100*(w[p]-w.bos)/w[p];ci=ci_cluster(g,groups)
        nominal.append({'policy':p,'mean':float(g.mean()),'ci':ci,'wins':int((w.bos<w[p]).sum()),'ties':int((w.bos==w[p]).sum()),'losses':int((w.bos>w[p]).sum())})
    table(T/'nominal.tex',['Comparator','Gain (\\%)','95\\% CI','W/T/L'],[[LABELS[d['policy']],f"{d['mean']:.3f}",f"[{d['ci'][0]:.3f}, {d['ci'][1]:.3f}]",f"{d['wins']}/{d['ties']}/{d['losses']}"] for d in nominal],'lrrr')
    rec=[];exact=[]
    for df,out,policies in [(e,exact,('bos','heft_rank','grpw','lpt','spt','fifo')),(r,rec,tuple(LABELS))]:
        for p in policies:
            d=df[df.policy==p];gap=100*(d.C/d.opt-1)
            out.append({'policy':p,'mean_gap':float(gap.mean()),'max_gap':float(gap.max()),'hits':int((abs(gap)<1e-6).sum()),'n':len(d),'mean_ms':float(d.seconds.mean()*1000)})
    table(T/'exact.tex',['Policy','Mean gap (\\%)','Max (\\%)','Hits / 96'],[[LABELS[d['policy']],f"{d['mean_gap']:.3f}",f"{d['max_gap']:.2f}",f"{d['hits']} / 96"] for d in exact],'lrrr')
    table(T/'recovery.tex',['Policy','Mean gap','Max gap','Hits','Mean ms'],[[LABELS[d['policy']],f"{d['mean_gap']:.3f}\\%",f"{d['max_gap']:.2f}\\%",str(d['hits']),f"{d['mean_ms']:.3f}"] for d in rec],'lrrrr')
    rw=r.pivot(index='id',columns='policy',values='C');b=r[r.policy=='bos'].set_index('id')
    gain=100*(rw.greedy_portfolio-rw.hybrid)/rw.greedy_portfolio
    comparison={'lp_win':int((rw.lp_list<rw.greedy_portfolio).sum()),'lp_tie':int((rw.lp_list==rw.greedy_portfolio).sum()),'lp_loss':int((rw.lp_list>rw.greedy_portfolio).sum()),'hybrid_mean_gain':float(gain.mean()),'hybrid_gain_ci':ci_cluster(gain,b.seed.astype(str)),'lp_beats_random32':int((rw.lp_list<rw.random32).sum()),'lp_stronger_lb':int((b.lp_lb>b.lb+1e-6).sum()),'eps_point1':int((b.epsilon_cert<=.1).sum()),'nonzero_incidents':int((b.active>0).sum()),'fractional_cases':int((b.lp_fractional>0).sum())}
    summary={'nominal_instances':n.id.nunique(),'nominal_runs':len(n),'nominal_exact':e.id.nunique(),'recovery_cases':r.id.nunique(),'nominal_pairs':len(w),'nominal':nominal,'exact':exact,'recovery':rec,'comparison':comparison,'zero_violations':True}
    (R/'summary.json').write_text(json.dumps(summary,indent=2))
    # Worked example with physically correct checkpoint intervals.
    fig,ax=plt.subplots(figsize=(3.5,1.8));ax.broken_barh([(0,3)],(1.1,.5),facecolors='#3f617c');ax.broken_barh([(10,3),(13,4)],(1.1,.5),facecolors=['#2a9d8f','#76c8ba']);ax.broken_barh([(13,2)],(.25,.5),facecolors='#dd9a37');ax.axvspan(3,10,alpha=.13,color='#777777');ax.axvline(3,color='#a33',ls='--',lw=1);ax.axvline(13,color='#999',ls=':',lw=1)
    ax.text(1.5,1.35,'A: 3',ha='center',va='center',color='white',fontsize=7);ax.text(11.5,1.35,'A: 3',ha='center',va='center',fontsize=7);ax.text(15,1.35,'A: 4',ha='center',va='center',fontsize=7);ax.text(14,.5,'B: 2',ha='center',va='center',fontsize=7);ax.text(6.5,.95,'material wait',ha='center',fontsize=7)
    ax.set(yticks=[.5,1.35],yticklabels=['Machine 2','Machine 1'],xlabel='Absolute time',xlim=(0,18),ylim=(0,1.9),xticks=[0,3,6,10,13,17]);ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(F/'checkpoint_example.pdf');plt.close(fig)
    fig,ax=plt.subplots(figsize=(3.5,2.4));chosen=['bos','heft_rank','greedy_portfolio','lp_list','hybrid','random32'];d={x['policy']:x for x in rec};ys=np.arange(len(chosen));ax.barh(ys,[d[p]['mean_gap'] for p in chosen],color=['#567a91','#8f9ea7','#2a9d8f','#c36b62','#3974ac','#c99938']);ax.set(yticks=ys,yticklabels=[LABELS[p] for p in chosen],xlabel='Mean gap to residual optimum (%)');ax.invert_yaxis();ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(F/'recovery_gaps.pdf');plt.close(fig)
    fig,ax=plt.subplots(figsize=(3.5,2.35))
    for severity,color in [(0,'#3974ac'),(.25,'#2a9d8f'),(.75,'#c36b62')]:
        d=b[b.severity==severity];ax.scatter(d.epsilon_cert,d.C/d.opt,s=15,alpha=.65,label=f'd={severity:g}',color=color)
    ax.set(xlabel=r'Certified excess $D/(mB_0)$',ylabel='BOS recovery / optimum',ylim=(.985,1.15));ax.legend(frameon=False,ncol=3,loc='upper center');ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(F/'budget_certificate.pdf');plt.close(fig)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
