"""Read serialized certificates and validate them, without trusting summary.csv."""
import json
from .run_revision import OUT,audit
from .bos_core import Schedule,instance_from_dict,validate_schedule
from .recovery import Recovery,validate_recovery
from .delay_tolerance import decode

def sch(d):
    return Schedule(d['policy'],tuple(d['start']),tuple(d['machine']),tuple(d['completion']),d['makespan'],tuple(d['start_order']),())

def read(name):
    return [json.loads(l) for l in (OUT/name).read_text().splitlines()]

def main():
    counts={};nominal=read('nominal_instances.jsonl');ns=0
    for d in nominal:
        i=instance_from_dict(d['instance'])
        for s in d['schedules']:audit(i,sch(s));ns+=1
    counts['nominal_instances']=len(nominal);counts['nominal_schedules']=ns
    ex=read('exact_nominal_certificates.jsonl')
    for d in ex:
        assert d['solver']['status']==0 and d['solver']['gap']<=1e-8
        validate_schedule(instance_from_dict(d['instance']),sch(d['exact_schedule']))
    counts['nominal_exact']=len(ex)
    data=read('recovery_certificates.jsonl');indexed={d['id']:d for d in data};rs=0
    for d in data:
        rec=Recovery(instance_from_dict(d['instance']),sch(d['nominal']),d['tau'],tuple(d['progress']),{int(j):tuple(g) for j,g in d['gates'].items()},instance_from_dict(d['residual']),tuple(tuple(s) for s in d['segments']))
        assert d['exact']['status']==0 and d['exact']['gap']<=1e-8
        validate_recovery(rec,sch(d['exact_schedule']))
        assert d['lp']['objective']<=d['exact']['objective']+1e-6
        for s in d['schedules']:
            audit(rec.residual,sch(s));validate_recovery(rec,sch(s));rs+=1
    counts['recovery_exact']=len(data);counts['recovery_reported_schedules']=rs
    random=read('random32_certificates.jsonl')
    for d in random:
        base=indexed[d['id']];i=instance_from_dict(base['residual']);audit(i,sch(d['selected']))
        assert d['selected']['makespan']<=min(d['sampled_makespans'])
    tol=read('delay_tolerance_certificates.jsonl')
    for d in tol:
        assert d['exact']['status']==0 and d['exact']['gap']<=1e-8
        assert d['LP']['objective']+1e-6>=d['exact']['objective']
        for p,D in d['best_delays'].items():
            assert D<=d['exact']['objective']+1e-6
            rec,_=decode(indexed[d['base_id']],D);s=sch(d['best_schedules'][p]);validate_recovery(rec,s)
            assert rec.tau+s.makespan<=d['deadline']
            feasible=[x['D'] for x in d['curve'] if x[p]<=d['deadline']-rec.tau]
            assert D==max([0]+feasible)
    counts['tolerance_exact']=len(tol);counts['tolerance_witnesses']=sum(len(d['best_delays']) for d in tol)
    counts['bound_or_feasibility_violations']=0
    (OUT/'verification.json').write_text(json.dumps(counts,indent=2));print(json.dumps(counts,indent=2))
if __name__=='__main__':main()
