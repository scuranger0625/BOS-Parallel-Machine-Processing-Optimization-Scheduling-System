"""Checkpoint recovery with progress-based dependencies and a frozen BOS prefix.
All times and work amounts are integers. Migration and checkpointing cost zero.
The optimization benchmark shares the SAME prefix and allowed checkpoints.
"""
from dataclasses import dataclass
from .bos_core import Edge, Instance, Schedule, validate_schedule

@dataclass
class Recovery:
    original: Instance
    nominal: Schedule
    tau: int
    progress: tuple
    gates: dict  # original task -> (progress threshold, absolute availability)
    residual: Instance
    segments: tuple  # (original task, work begin, work end)


def build_recovery(inst, nominal, tau, gates):
    assert 0 <= tau < nominal.makespan
    done = tuple(max(0, min(inst.p[i], tau - nominal.start[i])) for i in range(inst.n))
    for i,(g,a) in gates.items():
        assert done[i] <= g < inst.p[i] and a >= tau
    segs, by_task, ending = [], {}, {}
    releases=[]
    for i in range(inst.n):
        if done[i] == inst.p[i]:
            continue
        cuts={done[i],inst.p[i]}
        cuts.update(e.lag for e in inst.edges if e.u==i and done[i]<e.lag<inst.p[i])
        if i in gates:
            cuts.add(gates[i][0])
        cuts=sorted(cuts)
        by_task[i]=[]
        for a,b in zip(cuts,cuts[1:]):
            k=len(segs); segs.append((i,a,b)); by_task[i].append(k); ending[i,b]=k
            r=max(0,inst.release[i]-tau) if a==0 else 0
            if i in gates and a==gates[i][0]:
                r=max(r,gates[i][1]-tau)
            releases.append(r)
    arcs={}
    for ids in by_task.values():
        for u,v in zip(ids,ids[1:]):
            arcs[u,v]=segs[u][2]-segs[u][1]
    for e in inst.edges:
        # Only the FIRST start is gated. A satisfied progress gate stays satisfied.
        if e.v not in by_task or nominal.start[e.v]<tau:
            continue
        if e.lag>0 and done[e.u]>=e.lag:
            continue
        if e.lag==0:
            if nominal.start[e.u]<tau:
                continue
            u=by_task[e.u][0]; lag=0
        else:
            u=ending[e.u,e.lag]; lag=segs[u][2]-segs[u][1]
        v=by_task[e.v][0]
        arcs[u,v]=max(arcs.get((u,v),0),lag)
    residual=Instance(tuple(b-a for i,a,b in segs),tuple(releases),
                      tuple(Edge(u,v,l) for (u,v),l in sorted(arcs.items())),
                      inst.machines,inst.family,inst.instance_id+'-recovery')
    assert sum(residual.p)==sum(inst.p)-sum(done)
    return Recovery(inst,nominal,tau,done,dict(gates),residual,tuple(segs))


def validate_recovery(rec, sched):
    """Check physical progress independently of residual DAG feasibility."""
    validate_schedule(rec.residual,sched)
    intervals={i:[] for i in range(rec.original.n)}
    for i,d in enumerate(rec.progress):
        if d:
            intervals[i].append((rec.nominal.start[i],rec.nominal.start[i]+d,
                                 rec.nominal.machine[i]))
    for k,(i,a,b) in enumerate(rec.segments):
        intervals[i].append((rec.tau+sched.start[k],rec.tau+sched.completion[k],sched.machine[k]))
    for i,ivals in intervals.items():
        ivals.sort()
        assert sum(b-a for a,b,m in ivals)==rec.original.p[i]
        assert all(a[1]<=b[0] for a,b in zip(ivals,ivals[1:]))
        assert ivals[0][0]>=rec.original.release[i]
    for e in rec.original.edges:
        start_v=intervals[e.v][0][0]
        attained=sum(max(0,min(b,start_v)-a) for a,b,m in intervals[e.u] if a<start_v)
        assert intervals[e.u][0][0]<=start_v and attained>=e.lag,(e,attained,start_v)
    for i,(g,arrival) in rec.gates.items():
        for k,(j,a,b) in enumerate(rec.segments):
            if j==i and a==g:
                assert rec.tau+sched.start[k]>=arrival
    all_intervals=[(a,b,m,i) for i,row in intervals.items() for a,b,m in row]
    for machine in range(rec.original.machines):
        row=sorted(x for x in all_intervals if x[2]==machine)
        assert all(a[1]<=b[0] for a,b in zip(row,row[1:]))
    gaps=sum(a[1]<b[0] for row in intervals.values() for a,b in zip(row,row[1:]))
    migrations=sum(a[2]!=b[2] for row in intervals.values() for a,b in zip(row,row[1:]))
    return {'interruptions':gaps,'migrations':migrations}


def fixed_plan_repair(rec):
    """Keep nominal task-machine orders; propagate material waiting forward.
    A baseline with no opportunistic work inserted during blocked intervals.
    """
    i=rec.residual;arcs={(e.u,e.v):e.lag for e in i.edges}
    machine=[rec.nominal.machine[j] for j,a,b in rec.segments]
    for m in range(i.machines):
        order=sorted((k for k in range(i.n) if machine[k]==m),key=lambda k:(rec.nominal.start[rec.segments[k][0]],rec.segments[k][1]))
        for u,v in zip(order,order[1:]):arcs[u,v]=max(arcs.get((u,v),0),i.p[u])
    aug=Instance(i.p,i.release,tuple(Edge(u,v,l) for (u,v),l in arcs.items()),i.machines)
    starts=list(i.release)
    for v in aug.topological_order:
        for u,lag in aug.predecessors[v]:starts[v]=max(starts[v],starts[u]+lag)
    completion=tuple(starts[k]+i.p[k] for k in range(i.n))
    s=Schedule('fixed_repair',tuple(starts),tuple(machine),completion,max(completion),tuple(sorted(range(i.n),key=lambda k:(starts[k],aug.topological_order.index(k)))),())
    validate_recovery(rec,s)
    return s


def plan_recovery(rec, lp_time_limit=20):
    """Public fixed-delay entry point; LP failure falls back to feasible greedy.
    Returns schedule, lower bound, budget epsilon and candidate makespans.
    """
    from .bos_core import simulate,lower_bound
    from .optimization import optimize
    i=rec.residual
    candidates={p:simulate(i,p,record_decisions=False) for p in ('bos','heft_rank')}
    lp,ls=optimize(i,False,lp_time_limit)
    B=lower_bound(i)
    if ls is not None:
        candidates['lp_list']=ls;B=max(B,lp['objective'])
    chosen=min(candidates,key=lambda p:candidates[p].makespan)
    s=candidates[chosen];validate_recovery(rec,s)
    eps=max(i.release)/(i.machines*B)
    return {'schedule':s,'selected':chosen,'lower_bound':B,'epsilon_certificate':eps,
            'ratio_certificate':min(2,2-1/i.machines+eps),'lp':lp,
            'candidate_makespans':{p:s.makespan for p,s in candidates.items()}}
