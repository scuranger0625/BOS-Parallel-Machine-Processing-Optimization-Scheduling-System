import json
import numpy as np,pandas as pd
from .analyze_revision import ROOT,R,F,T,table,plt

def main():
    d=pd.read_csv(R/'delay_tolerance.csv');d['shortfall']=d.D_opt-d.D_feasible
    names={'fixed_repair':'Fixed-plan','bos':'BOS-recovery','greedy2':'Greedy-2','reserve_lp':'Reserve-LP','reserve_hybrid':'Reserve-hybrid','random32':'Random-32'}
    rows=[];summary=[]
    for p,name in names.items():
        q=d[d.policy==p];v=dict(policy=p,mean_delay=float(q.D_feasible.mean()),mean_shortfall=float(q.shortfall.mean()),max_shortfall=int(q.shortfall.max()),hits=int((q.shortfall==0).sum()),fallbacks=int(q.zero_delay_fallback.sum()),mean_ms=float(q.total_seconds.mean()*1000));summary.append(v)
        rows.append([name,f"{v['mean_delay']:.3f}",f"{v['mean_shortfall']:.3f}",v['hits'],v['fallbacks']])
    table(T/'tolerance.tex',['Policy','Mean $\\widehat D$','Shortfall','Hits','Fallback'],rows,'lrrrr')
    s=json.loads((R/'summary.json').read_text());s['tolerance']=summary;s['tolerance_cases']=int(d.id.nunique());s['tolerance_exact_success']=int(d[d.exact_status==0].id.nunique());s['tolerance_lp_exact']=int(sum(abs(d[d.policy=='bos'].D_lp-d[d.policy=='bos'].D_opt)<1e-6));(R/'summary.json').write_text(json.dumps(s,indent=2))
    fig,ax=plt.subplots(figsize=(3.5,2.6));xs=np.array([0,.25,.5])
    for p,col,mark in [('fixed_repair','#939393','s'),('greedy2','#2a9d8f','o'),('reserve_lp','#c36b62','^'),('reserve_hybrid','#3974ac','D')]:
        v=d[d.policy==p].groupby('slack').D_feasible.mean();ax.plot(xs,v.values,label=names[p],color=col,marker=mark,ms=4,lw=1.2)
    exact=d[d.policy=='bos'].groupby('slack').D_opt.mean();ax.plot(xs,exact.values,'k--',label='Exact tolerance',lw=1)
    ax.set(xlabel='Added delivery allowance / nominal makespan',ylabel='Mean tolerable gate delay',xticks=xs);ax.legend(frameon=False,fontsize=6.5,ncol=2,loc='upper left');ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(F/'delay_tolerance.pdf');plt.close(fig)
if __name__=='__main__':main()
