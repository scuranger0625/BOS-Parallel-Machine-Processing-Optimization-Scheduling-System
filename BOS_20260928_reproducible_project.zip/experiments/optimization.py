"""Shared time-indexed model: binary exact solver and continuous LP relaxation.
LP expected-start sorting is list rounding, never independent time rounding.
"""
import time
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix
from .bos_core import Instance, lower_bound, simulate, Schedule, validate_schedule


def optimize(inst, integer=False, time_limit=20):
    horizon=min(simulate(inst,p,record_decisions=False).makespan for p in ('bos','heft_rank','lpt','fifo'))
    var={}; times=[]
    for i in range(inst.n):
        ti=list(range(inst.release[i],horizon-inst.p[i]+1)); times.append(ti)
        for t in ti: var[i,t]=len(var)
    z=len(var); nvar=z+1
    rr=[];cc=[];vv=[];lb=[];ub=[]
    def add(terms,lo,hi):
        row=len(lb);lb.append(lo);ub.append(hi)
        for c,v in terms:
            if v: rr.append(row);cc.append(c);vv.append(v)
    for i,ti in enumerate(times): add([(var[i,t],1) for t in ti],1,1)
    for t in range(horizon):
        add([(var[i,s],1) for i in range(inst.n) for s in times[i] if s<=t<s+inst.p[i]],-np.inf,inst.machines)
    for e in inst.edges:
        add([(var[e.v,t],t) for t in times[e.v]]+[(var[e.u,t],-t) for t in times[e.u]],e.lag,np.inf)
    for i,ti in enumerate(times):
        add([(z,1)]+[(var[i,t],-t) for t in ti],inst.p[i],np.inf)
    c=np.zeros(nvar);c[z]=1
    lows=np.zeros(nvar);lows[z]=lower_bound(inst)
    highs=np.ones(nvar);highs[z]=horizon
    integrality=np.full(nvar,int(integer));integrality[z]=0
    A=coo_matrix((vv,(rr,cc)),shape=(len(lb),nvar)).tocsr()
    st=time.perf_counter()
    r=milp(c,integrality=integrality,bounds=Bounds(lows,highs),
           constraints=LinearConstraint(A,lb,ub),
           options={'time_limit':time_limit,'mip_rel_gap':0.0})
    elapsed=time.perf_counter()-st
    out={'status':int(r.status),'message':str(r.message),'seconds':elapsed,
         'integer':integer,'variables':nvar,'constraints':len(lb),'horizon':horizon,
         'objective':None if r.fun is None else float(r.fun),
         'dual_bound':(None if getattr(r,'mip_dual_bound',None) is None else float(r.mip_dual_bound)),
         'gap':(None if getattr(r,'mip_gap',None) is None else float(r.mip_gap))}
    if not r.success or r.x is None: return out,None
    means=np.array([sum(t*r.x[var[i,t]] for t in times[i]) for i in range(inst.n)])
    out['expected_starts']=means.tolist()
    # Report how much mass is truly fractional; preserve for auditing.
    out['fractional_variables']=int(sum(1e-7<x<1-1e-7 for x in r.x[:z]))
    if integer:
        starts=tuple(max(times[i],key=lambda t:r.x[var[i,t]]) for i in range(inst.n))
        sched=schedule_from_starts(inst,starts,'exact')
        assert abs(sched.makespan-r.fun)<1e-5
    else:
        # Smaller expected starts first; task index breaks equal keys.
        sched=simulate(inst,'lp_list',scores_override=-means,record_decisions=False)
        assert out['objective']<=sched.makespan+1e-6
    validate_schedule(inst,sched)
    return out,sched


def schedule_from_starts(inst, starts, policy):
    available=[0]*inst.machines;machine=[-1]*inst.n
    # A zero-lag predecessor must be recorded before its same-time successor.
    topo={u:k for k,u in enumerate(inst.topological_order)}
    order=sorted(range(inst.n),key=lambda i:(starts[i],topo[i]))
    for i in order:
        j=next(j for j in range(inst.machines) if available[j]<=starts[i])
        machine[i]=j;available[j]=starts[i]+inst.p[i]
    result=Schedule(policy,tuple(starts),tuple(machine),tuple(starts[i]+inst.p[i] for i in range(inst.n)),max(starts[i]+inst.p[i] for i in range(inst.n)),tuple(order),())
    validate_schedule(inst,result)
    return result


def optimize_delay(inst_zero, gate_nodes, horizon, integer=False, time_limit=20):
    """Maximize COMMON gate-release delay D subject to a FIXED deadline.
    Every gate-node start must be >=D. LP gives an upper bound on tolerable
    D, not a feasible delay certificate until the list-rounded plan is checked.
    """
    inst=inst_zero
    assert all(r==0 for r in inst.release) and gate_nodes
    var={};times=[]
    for i in range(inst.n):
        ti=list(range(horizon-inst.p[i]+1));times.append(ti)
        for t in ti:var[i,t]=len(var)
    z=len(var);nvar=z+1;rr=[];cc=[];vv=[];lo=[];hi=[]
    def add(terms,l,h):
        row=len(lo);lo.append(l);hi.append(h)
        for col,val in terms:
            if val:rr.append(row);cc.append(col);vv.append(val)
    for i,ti in enumerate(times):add([(var[i,t],1) for t in ti],1,1)
    for t in range(horizon):
        add([(var[i,s],1) for i in range(inst.n) for s in times[i] if s<=t<s+inst.p[i]],-np.inf,inst.machines)
    for e in inst.edges:
        add([(var[e.v,t],t) for t in times[e.v]]+[(var[e.u,t],-t) for t in times[e.u]],e.lag,np.inf)
    for i in gate_nodes:add([(var[i,t],t) for t in times[i]]+[(z,-1)],0,np.inf)
    c=np.zeros(nvar);c[z]=-1;upper=np.ones(nvar);upper[z]=horizon
    integ=np.full(nvar,int(integer));integ[z]=0
    A=coo_matrix((vv,(rr,cc)),shape=(len(lo),nvar)).tocsr()
    st=time.perf_counter()
    r=milp(c,integrality=integ,bounds=Bounds(np.zeros(nvar),upper),constraints=LinearConstraint(A,lo,hi),options={'time_limit':time_limit,'mip_rel_gap':0.0})
    out={'status':int(r.status),'message':str(r.message),'seconds':time.perf_counter()-st,'integer':integer,'horizon':horizon,'objective':None if r.fun is None else float(-r.fun),'gap':getattr(r,'mip_gap',None)}
    if not r.success or r.x is None:return out,None
    means=np.array([sum(t*r.x[var[i,t]] for t in times[i]) for i in range(inst.n)])
    out['expected_starts']=means.tolist()
    if integer:
        starts=tuple(max(times[i],key=lambda t:r.x[var[i,t]]) for i in range(inst.n))
        D=int(round(-r.fun));release=tuple(D if i in gate_nodes else 0 for i in range(inst.n))
        actual=Instance(inst.p,release,inst.edges,inst.machines)
        sched=schedule_from_starts(actual,starts,'delay_exact')
        assert sched.makespan<=horizon and all(starts[i]>=D for i in gate_nodes)
        out['starts']=list(starts);out['machines']=list(sched.machine)
    return out,means
