"""Cross-platform reproduction entry point: python run_all.py
Use --verify-only to inspect supplied certificates without re-solving MILPs.
"""
import os,sys,subprocess,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');args=p.parse_args()
env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
commands=[['-m','unittest','discover','-s','tests','-v']]
if not args.verify_only:
    commands += [['-m','experiments.run_revision','--suite','all'],['-m','experiments.random_baseline'],['-m','experiments.delay_tolerance'],['-m','experiments.analyze_revision'],['-m','experiments.analyze_tolerance']]
commands += [['-m','experiments.verify_results']]
for cmd in commands:
    print('Running:',sys.executable,*cmd,flush=True)
    subprocess.run([sys.executable,*cmd],cwd=ROOT,env=env,check=True)
