"""BOS-2L: single-revelation recovery; see paper for conditional guarantee.
No arbitrary-online or LP-only approximation guarantee is claimed.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math, time
import numpy as np
from scipy.optimize import linprog, milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix, vstack
from bos_core_0915 import Instance, Edge, simulate, lower_bound

@dataclass
class Chunk:
    job:int
    lo:float
    hi:float
    d:float
    q:float
    ref:float
    machine:int
    release:float=0

@dataclass
class Recovery:
    chunks:list
    edges:list
    tau:float
    D:float
    h:float
    m:int
    C0:float
    LB:float
    nominal:dict


def residualize(inst, tau, arrivals, h=1):
    """arrivals maps (job, progress threshold) -> absolute arrival.
    tau must precede any violated gate. Positive overlap lags only.
    The completed prefix is immutable; running tasks split exactly at tau.
    """
    if h<=0: raise ValueError('h must be positive')
    if any(e.lag<=0 for e in inst.edges):
        raise ValueError('This implementation requires strictly positive lags')
    if any(inst.release): raise ValueError('Nominal releases must be zero')
    s=simulate(inst)
    assert 0<=tau<s.makespan
    cuts=[{0,float(p)} for p in inst.p]
    for e in inst.edges: cuts[e.u].add(float(e.lag))
    for (i,g),a in arrivals.items():
        assert 0<=g<inst.p[i]
        assert a<=s.start[i]+g or tau<=s.start[i]+g
        cuts[i].add(float(g))
    done=[max(0,min(p,tau-s.start[i])) for i,p in enumerate(inst.p)]
    for i,x in enumerate(done): cuts[i].add(float(x))
    chunks=[]; byjob={i:[] for i in range(inst.n)}
    for i in range(inst.n):
        pts=sorted(x for x in cuts[i] if x>=done[i])
        for lo,hi in zip(pts,pts[1:]):
            if hi<=lo: continue
            d=hi-lo; q=h*math.ceil(d/h-1e-10)
            r=max([0]+[a-tau for (j,g),a in arrivals.items() if j==i and g<=lo])
            k=len(chunks);byjob[i].append(k)
            chunks.append(Chunk(i,lo,hi,d,q,s.start[i]+lo,s.machine[i],r))
    edges=set()
    for ids in byjob.values(): edges.update(zip(ids,ids[1:]))
    for e in inst.edges:
        if done[e.v]>0 or not byjob[e.v] or done[e.u]>=e.lag: continue
        pred=next(k for k in byjob[e.u] if abs(chunks[k].hi-e.lag)<1e-8)
        edges.add((pred,byjob[e.v][0]))
    D=max([0]+[a-tau for a in arrivals.values()])
    return Recovery(chunks,sorted(edges),tau,D,h,inst.machines,s.makespan,
                    lower_bound(inst),asdict(s))


def topology(n,edges):
    pred=[[] for _ in range(n)];succ=[[] for _ in range(n)]
    for a,b in edges: pred[b].append(a);succ[a].append(b)
    order=[];ready=[a for a in range(n) if not pred[a]];deg=list(map(len,pred))
    while ready:
        a=min(ready);ready.remove(a);order.append(a)
        for b in succ[a]:
            deg[b]-=1
            if not deg[b]:ready.append(b)
    assert len(order)==n, 'cycle'
    return order,pred,succ


def fallback(r):
    """Preserve nominal machine order; wait at most D then replay padded chunks.
    Source offsets retain the original nominal spacing. E=sum(q-d).
    """
    edges=set(r.edges);n=len(r.chunks)
    for machine in range(r.m):
        ids=sorted((i for i,c in enumerate(r.chunks) if c.machine==machine),key=lambda i:r.chunks[i].ref)
        edges.update(zip(ids,ids[1:]))
    order,pred,_=topology(n,edges);st=[0.]*n
    for a in order:
        st[a]=max([r.chunks[a].ref+r.D]+[st[b]+r.chunks[b].q for b in pred[a]])
    return dict(start=st,machine=[c.machine for c in r.chunks],C=max(st[i]+c.q for i,c in enumerate(r.chunks)))


def decode(r,keys):
    """Feasible nonpreemptive chunk list schedule, allowing job-level pauses.
    The LP median is only a priority: it never overrides gates or capacity.
    """
    n=len(r.chunks);_,pred,_=topology(n,r.edges)
    st=[None]*n;mach=[None]*n;running={};done=set();pending=set(range(n));t=0.
    release=[r.h*math.ceil(c.release/r.h-1e-10) for c in r.chunks]
    while pending or running:
        for mi,(a,end) in list(running.items()):
            if end<=t+1e-8: done.add(a);del running[mi]
        ready=sorted((a for a in pending if release[a]<=t+1e-8 and all(b in done for b in pred[a])),key=lambda a:(keys[a],a))
        idle=[i for i in range(r.m) if i not in running]
        for mi,a in zip(idle,ready):
            st[a]=r.tau+t;mach[a]=mi;pending.remove(a);running[mi]=(a,t+r.chunks[a].q)
        if not pending and not running:break
        events=[end for _,end in running.values()]+[release[a] for a in pending if release[a]>t+1e-8]
        assert events,'deadlock';t=min(events)
    return dict(start=st,machine=mach,C=max(st[i]+c.q for i,c in enumerate(r.chunks)))


def bottom_keys(r):
    order,_,succ=topology(len(r.chunks),r.edges);b=[0.]*len(order)
    for a in reversed(order):b[a]=r.chunks[a].q+max([0]+[b[x] for x in succ[a]])
    return [-v for v in b]


def lp_model(r):
    """Start-time LP: expected precedence is a relaxation, not physical flow.
    With binary x this is an exact grid/chunk MILP for the frozen prefix.
    """
    n=len(r.chunks);d=[round(c.q/r.h) for c in r.chunks]
    rel=[math.ceil(c.release/r.h-1e-10) for c in r.chunks]
    H=max(rel,default=0)+sum(d)
    variables=[(a,t) for a in range(n) for t in range(rel[a],H-d[a]+1)]
    by=[[] for _ in range(n)]
    for j,(a,t) in enumerate(variables):by[a].append((j,t))
    z=len(variables);N=z+1
    rr=[];cc=[];vv=[];rhs=[]
    def row(terms,b):
        k=len(rhs)
        for j,v in terms:
            if v:rr.append(k);cc.append(j);vv.append(v)
        rhs.append(b)
    # capacity
    for t in range(H):row(((j,1) for j,(a,s) in enumerate(variables) if s<=t<s+d[a]),r.m)
    # expected precedence: E[S_a]+d_a <= E[S_b]
    for a,b in r.edges:row([(j,t) for j,t in by[a]]+[(j,-t) for j,t in by[b]],-d[a])
    for a in range(n):row([(j,t+d[a]) for j,t in by[a]]+[(z,-1)],0)
    A=coo_matrix((vv,(rr,cc)),shape=(len(rhs),N)).tocsr()
    er=[];ec=[]
    for a in range(n):
        for j,_ in by[a]:er.append(a);ec.append(j)
    eq=coo_matrix((np.ones(len(er)),(er,ec)),shape=(n,N)).tocsr()
    obj=np.zeros(N);obj[z]=1
    lb=np.zeros(N);ub=np.ones(N);ub[z]=H
    return obj,A,np.array(rhs),eq,np.ones(n),lb,ub,variables,by,H


def lp_round(r,alpha=.5,model=None):
    if not 0<alpha<1:raise ValueError('alpha must be in (0,1)')
    data=model or lp_model(r);obj,A,b,eq,be,lb,ub,var,by,H=data
    begin=time.perf_counter()
    sol=linprog(obj,A_ub=A,b_ub=b,A_eq=eq,b_eq=be,bounds=list(zip(lb,ub)),method='highs')
    elapsed=time.perf_counter()-begin
    if not sol.success:return None,dict(status=int(sol.status),seconds=elapsed)
    keys=[]
    for ids in by:
        acc=0
        for j,t in ids:
            acc+=max(0,sol.x[j])
            if acc>=alpha-1e-8:keys.append(t);break
        else:raise AssertionError('missing median')
    result=decode(r,keys)
    fraction=sum(1 for ids in by if sum(sol.x[j]>1e-7 for j,_ in ids)>1)
    return result,dict(status=0,seconds=elapsed,LP_bound=r.tau+r.h*sol.fun,
                       fractional_chunks=fraction,variables=len(obj),median_keys=keys,
                       support=[(a,t,float(sol.x[j])) for j,(a,t) in enumerate(var) if sol.x[j]>1e-7])


def exact(r,model=None,seconds=15):
    obj,A,b,eq,be,lb,ub,var,by,H=model or lp_model(r)
    integ=np.ones(len(obj));integ[-1]=0
    result=milp(obj,integrality=integ,bounds=Bounds(lb,ub),
      constraints=[LinearConstraint(A,-np.inf,b),LinearConstraint(eq,be,be)],
      options={'time_limit':seconds,'mip_rel_gap':0})
    return dict(status=int(result.status),optimum=(r.tau+r.h*result.fun if result.fun is not None else None),
      lower=(r.tau+r.h*result.mip_dual_bound if getattr(result,'mip_dual_bound',None) is not None else None),
      gap=float(result.mip_gap) if getattr(result,'mip_gap',None) is not None else None)


def validate(r,s):
    n=len(r.chunks);assert len(s['start'])==n
    for a,c in enumerate(r.chunks):assert s['start'][a]>=r.tau+c.release-1e-7
    for a,b in r.edges:assert s['start'][b]>=s['start'][a]+r.chunks[a].q-1e-7
    for mi in range(r.m):
        ids=sorted((a for a in range(n) if s['machine'][a]==mi),key=lambda a:s['start'][a])
        for a,b in zip(ids,ids[1:]):assert s['start'][b]>=s['start'][a]+r.chunks[a].q-1e-7
    assert abs(s['C']-max(s['start'][a]+c.q for a,c in enumerate(r.chunks)))<1e-7


def solve(r,do_exact=False):
    F=fallback(r);B=decode(r,bottom_keys(r));data=lp_model(r);P,meta=lp_round(r,model=data)
    guarded=P if P is not None and P['C']<=F['C']+1e-8 else F
    chosen=min([B,guarded],key=lambda s:s['C'])
    for s in [F,B,P,chosen]:
        if s is not None:validate(r,s)
    E=sum(c.q-c.d for c in r.chunks);rho=2-1/r.m
    assert F['C']<=r.C0+r.D+E+1e-7
    assert chosen['C']<=rho*r.LB+r.D+E+1e-7
    record=dict(C0=r.C0,LB=r.LB,tau=r.tau,D=r.D,E=E,epsilon=(r.D+E)/r.LB,
      fallback=F['C'],greedy=B['C'],lp=P['C'] if P else None,guarded_lp=guarded['C'],hybrid=chosen['C'],
      selected='greedy' if chosen is B else ('LP' if chosen is P else 'fallback'),certificate=rho*r.LB+r.D+E,
      chunks=len(r.chunks),**{k:v for k,v in meta.items() if k not in ['support','median_keys']})
    if do_exact:record.update({'exact_'+k:v for k,v in exact(r,data).items()})
    return record,dict(recovery=asdict(r),fallback=F,greedy=B,lp=P,hybrid=chosen,LP=meta)
