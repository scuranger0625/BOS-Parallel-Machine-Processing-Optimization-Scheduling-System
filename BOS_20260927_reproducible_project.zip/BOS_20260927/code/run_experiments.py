"""Run from this directory: python run_experiments.py --seeds 6.
All generated inputs, schedules, LP supports and raw rows are retained.
"""
import argparse,csv,json,random,platform,time
from pathlib import Path
import scipy,numpy
from bos_core_0915 import Instance,Edge,simulate,instance_to_dict
from two_layer import residualize,solve

def generate(n,m,family,seed):
    rng=random.Random(seed);p=tuple(rng.randint(4,10) for _ in range(n));edges=[]
    for j in range(1,n):
        for i in range(j):
            probability=.25 if family=='layered' else (.6 if j>=n-2 else .07)
            if rng.random()<probability:edges.append(Edge(i,j,max(1,round(p[i]*rng.choice([.25,.5,.75])))))
    return Instance(p,(0,)*n,tuple(edges),m,family,f'{family}-{n}-{m}-{seed}')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,default=6);ap.add_argument('--out',default='../results');args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True);(out/'traces').mkdir(exist_ok=True)
    rows=[];begin=time.time();case=0
    for family in ['layered','merge']:
      for n in [6,10]:
       for m in [2,3]:
        for seed in range(args.seeds):
         inst=generate(n,m,family,seed);S=simulate(inst)
         # Select a task in progress at the trigger; gate blocks its next unit.
         tau=max(1,int(S.makespan*.30))
         running=[i for i in range(n) if S.start[i]<tau<S.completion[i]]
         if not running:
            i=S.start_order[0];tau=S.start[i]+1;running=[i]
         target=running[0];gate=tau-S.start[target]
         for delay in [1,3,6]:
          for h in [1,2]:
           arrivals={(target,gate):tau+delay}
           r=residualize(inst,tau,arrivals,h)
           rec,trace=solve(r,do_exact=(n==6 and seed<2 and h==1))
           rec.update(case=case,family=family,n=n,m=m,seed=seed,delay=delay,h=h)
           trace['input']=instance_to_dict(inst);trace['arrivals']=[dict(job=target,gate=gate,time=tau+delay)]
           (out/'traces'/f'{case:04}.json').write_text(json.dumps(trace,indent=2))
           rows.append(rec);case+=1
           if case%24==0:print(f'{case} cases completed',flush=True)
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (out/'raw.csv').open('w',newline='') as f:
      w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
    def mean(v):return sum(v)/len(v)
    summary={'cases':len(rows),'feasibility_or_certificate_violations':0,
      'lp_successes':sum(r['status']==0 for r in rows),
      'lp_selected':sum(r['selected']=='LP' for r in rows),
      'fractional_cases':sum(r.get('fractional_chunks',0)>0 for r in rows),
      'lp_vs_greedy':{k:sum(test(r['lp'],r['greedy']) for r in rows if r['lp'] is not None) for k,test in [('win',lambda a,b:a<b-1e-8),('tie',lambda a,b:abs(a-b)<1e-8),('loss',lambda a,b:a>b+1e-8)]},
      'hybrid_vs_greedy':{k:sum(test(r['hybrid'],r['greedy']) for r in rows) for k,test in [('win',lambda a,b:a<b-1e-8),('tie',lambda a,b:abs(a-b)<1e-8),('loss',lambda a,b:a>b+1e-8)]},
      'mean_hybrid_improvement_over_fallback_pct':mean([100*(r['fallback']-r['hybrid'])/r['fallback'] for r in rows]),
      'mean_hybrid_improvement_over_greedy_pct':mean([100*(r['greedy']-r['hybrid'])/r['greedy'] for r in rows]),
      'mean_lp_seconds':mean([r['seconds'] for r in rows]),
      'exact_requested':sum('exact_status' in r for r in rows),
      'exact_certified':sum(r.get('exact_status')==0 for r in rows),
      'epsilon_min':min(r['epsilon'] for r in rows),'epsilon_max':max(r['epsilon'] for r in rows),
      'elapsed_seconds':time.time()-begin,'python':platform.python_version(),'scipy':scipy.__version__,'numpy':numpy.__version__}
    exactrows=[r for r in rows if r.get('exact_status')==0]
    for method in ['greedy','lp','guarded_lp','hybrid','fallback']:
      summary[method+'_exact_mean_gap_pct']=mean([100*(r[method]-r['exact_optimum'])/r['exact_optimum'] for r in exactrows]) if exactrows else None
    (out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
