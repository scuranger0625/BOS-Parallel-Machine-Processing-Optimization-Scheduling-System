"""Independent audit of full progress schedules, including frozen prefix.
Run: python audit_traces.py ../results
This checks physical semantics from the original inputs, not only chunk arcs.
"""
import json,sys
from pathlib import Path
TOL=1e-7

def audit(trace,s):
    r=trace['recovery'];ins=trace['input'];tau=r['tau'];nom=r['nominal'];chunks=r['chunks'];n=len(ins['p'])
    pieces=[[] for _ in range(n)];reservations=[]
    for i,p in enumerate(ins['p']):
        st=nom['start'][i];end=min(tau,nom['completion'][i])
        if st<end:
            pieces[i].append((0,end-st,st,end))
            reservations.append((nom['machine'][i],st,end))
    for a,c in enumerate(chunks):
        st=s['start'][a]
        assert st>=tau-TOL
        assert 0<=s['machine'][a]<ins['machines']
        pieces[c['job']].append((c['lo'],c['hi'],st,st+c['d']))
        reservations.append((s['machine'][a],st,st+c['q']))
    for i,p in enumerate(ins['p']):
        seq=sorted(pieces[i]);assert seq and abs(seq[0][0])<TOL and abs(seq[-1][1]-p)<TOL
        for a,b in zip(seq,seq[1:]):
            assert abs(a[1]-b[0])<TOL
            assert a[3]<=b[2]+TOL
        assert abs(sum(v[1]-v[0] for v in seq)-p)<TOL
    for mi in range(ins['machines']):
        spans=sorted((st,en) for m,st,en in reservations if m==mi)
        for a,b in zip(spans,spans[1:]):assert a[1]<=b[0]+TOL
    def reach(i,g):
        for lo,hi,st,en in sorted(pieces[i]):
            if lo-TOL<=g<=hi+TOL:return st+g-lo
        raise AssertionError('threshold not reached')
    for e in ins['edges']:
        assert min(v[2] for v in pieces[e['v']])>=reach(e['u'],e['lag'])-TOL
    for gate in trace['arrivals']:
        for lo,hi,st,en in pieces[gate['job']]:
            if hi>gate['gate']+TOL:
                assert st+max(0,gate['gate']-lo)>=gate['time']-TOL
    E=sum(c['q']-c['d'] for c in chunks)
    assert trace['fallback']['C']<=r['C0']+r['D']+E+TOL
    assert trace['hybrid']['C']<=(2-1/r['m'])*r['LB']+r['D']+E+TOL
    assert trace['hybrid']['C']<=trace['greedy']['C']+TOL

root=Path(sys.argv[1] if len(sys.argv)>1 else '../results');count=0
for p in sorted((root/'traces').glob('*.json')):
    t=json.loads(p.read_text())
    for method in ['fallback','greedy','lp','hybrid']:
        if t[method] is not None:audit(t,t[method]);count+=1
result={'trace_cases':len(list((root/'traces').glob('*.json'))),'full_schedules_audited':count,'violations':0}
(root/'audit.json').write_text(json.dumps(result,indent=2));print(result)
