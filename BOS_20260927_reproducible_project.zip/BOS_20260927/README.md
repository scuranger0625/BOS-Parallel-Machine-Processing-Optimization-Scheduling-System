# BOS-2L：20260927 最新論文與可重現專案

這是以 0915 原稿為第一層、加入延遲恢復第二層的新研究版本。主文為英文，沿用原稿作者署名 Chen-Hong 與中央大學資工系。理論是有條件的保證；不是一般線上排程的無條件新近似比。

## 檔案

- `BOS_two_layer_20260927.pdf`：完整新版論文。
- `BOS_two_layer_20260927.tex`：可直接編譯的單檔 LaTeX；不依賴外部圖檔或 bib 檔。
- `BOS_雙層架構_中文導讀與簡報內容.md`：12 頁簡報內容、講解與研究限制。
- `code/two_layer.py`：殘餘 DAG、LP、median rounding、greedy、備援排程、精確 MILP 與檢查器。
- `code/run_experiments.py`：固定 seeds 的 288 組實驗。
- `code/audit_traces.py`：由原始工作與進度語義獨立檢查整份排程，含已完成前綴。
- `code/bos_core_0915.py`：從使用者提供的 `bos_core.py` 原樣保留之第一層。
- `results/raw.csv`、`summary.json`、`audit.json`：逐筆結果、統計、獨立檢查。
- `results/traces/*.json`：每個案例的原始輸入、材料 gate、nominal 排程、chunks、LP 正值分數、rounding keys 與候選排程。

## 重跑

建議 Python 3.12，套件版本見 `requirements.txt`。在自己的環境安裝後：

```bash
cd code
python run_experiments.py --seeds 6 --out ../results_rerun
python audit_traces.py ../results_rerun
```

論文編譯：

```bash
pdflatex BOS_two_layer_20260927.tex
pdflatex BOS_two_layer_20260927.tex
```

套件：標準 LaTeX article、amsmath、amsthm、geometry、booktabs、hyperref、lmodern、enumitem、listings。

## 一句話看懂

平常執行 BOS；材料延遲時保留已做進度，將剩餘工作變成 DAG，同時產生 LP rounding、greedy 修復與可證明的備援排程，選完工時間最短者。

令 B 為原始工作量／路徑下界、D 為觸發後所有材料到齊的最長等待、E 為 chunk 時間向上取整的總增加量。證明：

`C_2L ≤ (2 − 1/m) B + D + E`。

**只有在 `D + E ≤ ε B` 時，才得到指定的 `2 − 1/m + ε` 保證。**

ε 不是「幾分鐘」；`ε B` 才是時間。LP priority rounding 的損失沒有獨立界；安全性由備援與選擇機制保護，不能把 E 當成 LP integrality gap。

## 結果與限制

288 組：完整機制相對 greedy 為 7 勝、281 平、0 敗，平均改善 0.141%。單用 LP 則 7 勝、186 平、95 敗。24 組 frozen-prefix grid 最優解全部有 status 0、MIP gap 0；完整機制平均 gap 0.278%。

這是開發用合成資料，不是獨立保留測試集。選擇機制是在同一組資料初測發現 LP 弱勢後加入。不是所有案例都能宣稱 ε=0.2；僅 124/288 通過此充分條件。

假設：同速機器、原始 release=0、正 lag、單次揭露所有未來材料到達、進度可保留、可中斷與遷移、切換成本零。計算時間預設不算入排程；可另加總停機求解時間。無限多次未知延遲、零 lag 啟動語義與有成本切換尚未證明。

檢查點會限制後續中斷位置；精確 MILP 的最優解是固定前綴、固定 chunks、固定格點版本，不是全域 clairvoyant 最優解。論文主定理使用 B，並未拿這個 MILP 值冒充全域下界。

此版本尚未加入現場資料與大型 benchmark，投稿前仍需補強。
