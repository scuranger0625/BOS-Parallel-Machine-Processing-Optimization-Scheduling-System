"""Small independent exhaustive oracle and model edge cases."""
import itertools
import random
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from dp_scheduler import Problem, solve_dp, greedy, lower_bounds, validate
from milp_oracle import solve_milp


def exhaustive_layers(P):
    # Includes explicit idling; no earliest-arrival or A* dominance.
    layer={P.q0}
    for t in range(P.tau,P.stable_time()+sum(P.p)+1):
        if P.p in layer:return t
        nxt=set()
        for q in layer:
            for bits in itertools.product((0,1),repeat=P.n):
                a=[i for i,b in enumerate(bits) if b]
                if len(a)>P.capacity(t):continue
                if any(q[i]>=P.p[i] or not P.available(i,t) for i in a):continue
                okay=True
                for u,v,l in P.edges:
                    if v in a and q[v]==0:
                        if q[u]<l or (l==0 and q[u]==0 and u not in a):okay=False
                if okay:nxt.add(tuple(q[i]+bits[i] for i in range(P.n)))
        layer=nxt
    raise AssertionError("horizon exhausted")


class TestDP(unittest.TestCase):
    def test_zero_lag_simultaneous(self):
        P=Problem((2,2),((0,1,0),),2)
        self.assertEqual(solve_dp(P)["ub"],2)
        self.assertEqual(solve_milp(P)["optimum"],2)

    def test_progress_not_wall_clock(self):
        P=Problem((3,1),((0,1,2),),2,blocks=((0,1,4),))
        self.assertEqual(solve_dp(P)["ub"],6)
        self.assertEqual(exhaustive_layers(P),6)

    def test_zero_capacity_and_release(self):
        P=Problem((2,1),(),2,release=(3,0),outages=((0,4,0),))
        self.assertEqual(solve_dp(P)["ub"],6)

    def test_random_exhaustive(self):
        rng=random.Random(28092026)
        for k in range(90):
            n=4;p=tuple(rng.randint(1,2) for _ in range(n))
            edges=tuple((i,j,rng.randint(0,p[i])) for i in range(n) for j in range(i+1,n) if rng.random()<.25)
            blocks=((rng.randrange(n),1,3),) if k%2 else ()
            outages=((0,2,1),) if k%3==0 else ()
            P=Problem(p,edges,2,release=tuple(rng.randrange(2) for _ in range(n)),blocks=blocks,outages=outages)
            exact=exhaustive_layers(P);dp=solve_dp(P)
            self.assertEqual(dp["ub"],exact)
            self.assertEqual(dp["lb"],exact)
            cut=solve_dp(P,max_expansions=0)
            self.assertLessEqual(cut["lb"],exact)
            self.assertGreaterEqual(cut["ub"],exact)
            for policy in ("bos","continue","lpt"):validate(P,greedy(P,policy))

    def test_fixed_prefix(self):
        P=Problem((3,2,2),((0,2,2),),2,tau=2,q0=(2,2,0),blocks=((0,2,5),))
        self.assertEqual(solve_dp(P)["ub"],exhaustive_layers(P))
        self.assertEqual(solve_dp(P)["ub"],round(solve_milp(P)["optimum"]))

    def test_nontrivial_budget_certificate(self):
        # Three full barriers, four length-2 jobs per layer, m=3.
        # Each layer needs ceil(8/3)=3 slots with free preemption.
        edges=tuple((i,j,2) for g in range(2) for i in range(4*g,4*g+4) for j in range(4*g+4,4*g+8))
        P=Problem((2,)*12,edges,3)
        limited=solve_dp(P,max_expansions=0)
        self.assertEqual(limited["status"],"budget")
        self.assertLessEqual(limited["lb"],9)
        self.assertGreaterEqual(limited["ub"],9)
        self.assertEqual(solve_dp(P)["ub"],9)

if __name__ == "__main__":unittest.main()
