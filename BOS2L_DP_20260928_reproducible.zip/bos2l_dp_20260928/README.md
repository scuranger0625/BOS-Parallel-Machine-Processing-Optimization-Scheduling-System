# BOS2L-DP — 2026-09-28 研究版本

這一版把「延遲後可行集合只會縮小」變成可驗證的 DP 模型、上下界與延遲損失公式。主論文是英文 IEEEtran 雙欄格式；本說明與公式導讀使用繁體中文。

**結論範圍：**固定 BOS 第一層已執行的歷史後，對「整數時槽、可免費中斷／換機、已知有限延遲」的續排問題求精確解。沒有宣稱整段歷史全域最優、連續時間精確、FPTAS，或已證明 `2-1/m+epsilon`。

## 先看哪些檔案

| 檔案 | 用途 |
|---|---|
| `paper/BOS2L_DP_20260928.pdf` | 新版論文，包含模型、證明、公式、實驗、限制 |
| `docs/FORMULAS_ZH.md` | 新 Formula 的繁體中文解釋 |
| `docs/CODE_WALKTHROUGH_ZH.md` | DP 程式逐段導讀與狀態定義 |
| `src/dp_scheduler.py` | 主要模型、Greedy 修復、上下界、精確 DP、預算停止 |
| `src/milp_oracle.py` | 獨立 MILP 驗證，不參與 DP 決策 |
| `src/legacy_bos_0915.py` | 原 0915 BOS 核心，逐位元保留 |
| `src/run_experiments.py` | 384 案例、24 個 MILP 驗證、Greedy 反例與規模診斷 |
| `src/stress_barriers.py` | 三個有獨立結構性最優值的壓力案例 |
| `results/delay_sweep.csv` | 384 個案例的逐例數值 |
| `results/certificates.json` | 每個輸入、原排程前綴、DP 排程與比較策略 |
| `results/summary.json` | 匯總數字及實際執行環境 |
| `results/greedy_anomaly.json` | 原 BOS 延遲後 12→11 的完整反例 |
| `results/barrier_stress.json` | 預算停止的上下界、排程與獨立最優值 |

## 重跑

Python 3.12；主要 DP 只使用標準函式庫。獨立 MILP、實驗整理及作圖需要：

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python src/run_experiments.py
python src/stress_barriers.py
python src/make_figures.py
```

先做較小的試跑可使用 `python src/run_experiments.py --quick`。**注意：它會覆寫 `results` 中對應的完整實驗檔案**；要重建本文數字，請再執行不含 `--quick` 的完整版。程式不會自動變更 PDF；需重新產生圖表並編譯。

單獨解一個案例：

```bash
python src/dp_scheduler.py results/example_instance.json
python src/dp_scheduler.py results/example_instance.json --max-expansions 0
```

編譯論文（需要 TeX Live／MiKTeX 和 latexmk）：

```bash
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error BOS2L_DP_20260928.tex
```

`IEEEtran.cls`、`IEEEtran.bst` 由原專案保留。不要在 `make_figures.py` 尚未結束時同時編譯，以免讀取尚未寫完的 PDF 圖檔。

## 本次結果

- 384 個小型案例全部完成精確認證；339 個靠初始 LB=UB 直接結案，並非全部都需要展開 DP。
- 24 個獨立 MILP 全部求至最優，與 DP／界限結案的結果一致。
- 90 個隨機微型案例與包含等待動作的完整時槽列舉一致。
- 288 個有延遲案例中，112 個沒有增加最佳完工時間。
- BOS-P 平均高於最優 2.475%，R-LPT 為 2.085%；不能宣稱 BOS 平均勝過所有比較者。
- 容量延遲示範：無延遲 OPT=9；延遲後 OPT=11、BOS-P=13，DP 找到 11。
- 原版 BOS 的反例：延遲後 makespan 12→11；前後在相同可中斷規則下的續排 OPT 都是 11。
- 24 工作 barrier 壓力案例在兩秒停止，本次回傳 LB=17、UB=18；獨立分層容量分析可證 OPT=18。時間限制、展開數與毫秒數會因電腦而異。

## 模型不可省略的條件

1. 時间、加工量、門檻、行事曆端點都使用整數時槽。這是明確模型，不是已證明無誤差的連續時間近似。
2. 每個工作每槽最多用一台機器；時槽邊界可中斷及換機，沒有額外代價。
3. 正門檻依據前驅「實際累積加工量」。零門檻仍要求前驅已啟動或在同槽共同啟動。
4. `blocks` 是 `(工作編號, 起點, 終點)` 的半開區間；可表示後續物料不足使正在加工的工作暫停。
5. `outages` 是 `(起點, 終點, 可用機器數)`；重疊紀錄取最小可用數，不是損失數相加。
6. 事件在修復時已揭露，本版沒有未知未來事件的競爭比。
7. 固定相同歷史才比較延遲前後 OPT；不把不可中斷 OPT 與可中斷 OPT 混用。
8. `OPT_d-OPT_0 <= D` 要求原參考續排從當下起沒有未來限制，且新增干擾全部於 `tau+D` 前解除。

這是對 0915 版本的「延遲修復研究分支」，不是把原本零延遲定理改名套用。原始附件未覆寫；新增英文署名沿用原稿 `Chen-Hong`。
