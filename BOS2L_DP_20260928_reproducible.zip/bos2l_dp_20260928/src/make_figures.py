"""Generate manuscript figures and tables only from stored raw results."""
import csv,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"paper"/"figures";OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42,"savefig.bbox":"tight"})
rows=list(csv.DictReader((ROOT/"results"/"delay_sweep.csv").open()))
s=json.loads((ROOT/"results"/"summary.json").read_text())
fig,axes=plt.subplots(1,2,figsize=(7.0,2.7))
for mode,c in zip(("material","capacity","mixed"),("#087E8B","#B66525","#6653A3")):
    ys=[]
    for d in (0,1,3,6):
        vals=[int(r["dp_ub"])-int(r["base_opt"]) for r in rows if r["mode"]==mode and int(r["D"])==d]
        ys.append(np.mean(vals))
    axes[0].plot((0,1,3,6),ys,"o-",label=mode,color=c,markersize=4)
axes[0].plot((0,6),(0,6),"--",color="0.6",linewidth=1,label="upper bound D")
axes[0].set(xlabel="Disturbance horizon D (slots)",ylabel="Mean unavoidable delay (slots)",xticks=(0,1,3,6))
axes[0].legend(fontsize=7,frameon=False)
keys=("bos","continue","lpt","portfolio_ub")
vals=[s["heuristics"][k]["mean_gap_percent"] for k in keys]
axes[1].bar(range(4),vals,color=("#087E8B","#B66525","#6653A3","#375369"))
axes[1].set(xticks=range(4),xticklabels=("BOS-P","BOS-C","R-LPT","Portfolio"),ylabel="Mean gap to exact optimum (%)")
for j,v in enumerate(vals):axes[1].text(j,v+.04,f"{v:.2f}",ha="center",fontsize=8)
axes[1].set_ylim(0,max(vals)+.55)
fig.tight_layout();fig.savefig(OUT/"delay_and_gap.pdf");fig.savefig(OUT/"delay_and_gap.png",dpi=180);plt.close(fig)

allc=json.loads((ROOT/"results"/"certificates.json").read_text())
case=max(allc,key=lambda c:c["heuristics"]["bos"]["completion"]-c["dp"]["ub"])
(ROOT/"results"/"recovery_example.json").write_text(json.dumps(case,indent=2))
fig,axes=plt.subplots(2,1,figsize=(7.0,3.5),sharex=True)
colors=plt.get_cmap("tab10")
P=case["problem"]
for ax,sc,title in zip(axes,(case["heuristics"]["bos"],case["dp"]["schedule"]),("BOS-P repair","Exact progress DP")):
    for t,a in sc["slots"]:
        for j in a:ax.broken_barh([(t,1)],(j-.32,.64),facecolors=colors(j),edgecolors="white",linewidth=.4)
    ax.axvline(sc["completion"],ls="--",color="#333333",lw=.8)
    ax.text(sc["completion"]+.1,len(P["p"])-.6,f'C = {sc["completion"]}',fontsize=8)
    ax.set(yticks=range(len(P["p"])),yticklabels=[f"J{j}" for j in range(len(P["p"]))],ylabel=title)
    for a,b,c in P["outages"]:ax.axvspan(a,b,color="#D49345",alpha=.09)
axes[0].set_title(f'Fixed prefix ends at t = {P["tau"]}; shaded interval has reduced capacity',fontsize=9)
axes[1].set_xlabel("Absolute time (slots)")
axes[1].set_xlim(P["tau"]-.2,max(case["heuristics"]["bos"]["completion"],case["dp"]["ub"])+1.1)
fig.tight_layout();fig.savefig(OUT/"repair_example.pdf");fig.savefig(OUT/"repair_example.png",dpi=180);plt.close(fig)

a=json.loads((ROOT/"results"/"greedy_anomaly.json").read_text())
fig,axes=plt.subplots(2,1,figsize=(7.0,2.7),sharex=True)
for ax,k,title in zip(axes,("before","after"),("No delay: original BOS","Delayed J5: original BOS")):
    for j,(t,m,p) in enumerate(zip(a[f"starts_{k}"],a[f"machines_{k}"],a["p"])):
        ax.broken_barh([(t,p)],(m-.3,.6),facecolors=colors(j),edgecolors="white")
        ax.text(t+p/2,m,f"J{j}",ha="center",va="center",fontsize=8,color="black")
    ax.axvline(a["tau"],color="black",ls=":",lw=1)
    ax.set(yticks=(0,1),yticklabels=("M0","M1"),title=title)
axes[1].set(xlabel="Absolute time (slots)",xticks=range(13),xlim=(0,12.3))
fig.tight_layout();fig.savefig(OUT/"greedy_anomaly.pdf");fig.savefig(OUT/"greedy_anomaly.png",dpi=180);plt.close(fig)

lines=[]
for k,label in zip(keys,("BOS-P","BOS-C","R-LPT","Portfolio")):
    v=s["heuristics"][k]
    lines.append(f'{label} & {v["mean_gap_percent"]:.2f} & {v["max_gap_percent"]:.2f} & {v["optimal_hits"]}/{v["count"]} \\\\')
(ROOT/"paper"/"results_table.tex").write_text('\\begin{tabular}{lrrr}\\toprule\nPolicy & Mean gap (\\%) & Max gap (\\%) & Optimal hits\\\\\\midrule\n'+"\n".join(lines)+'\n\\bottomrule\\end{tabular}\n')
macros={"NumCases":s["cases"],"NumExact":s["exact"],"NumDisturbed":s["disturbed_exact"],"NumChecks":s["milp_checks"],
        "NumAbsorbed":s["delay_absorbed"],"NumTight":s["analytic_lb_tight"],"NumClosed":s["bound_closure_cases"],
        "MaxLabels":s["max_labels"],"MeanMillis":f'{s["mean_dp_seconds"]*1000:.3f}',"MaxMillis":f'{s["max_dp_seconds"]*1000:.3f}'}
(ROOT/"paper"/"results_macros.tex").write_text("\n".join('\\newcommand{\\'+k+'}{'+str(v)+'}' for k,v in macros.items())+"\n")
print(json.dumps({"example":P["name"],"macros":macros},indent=2))
