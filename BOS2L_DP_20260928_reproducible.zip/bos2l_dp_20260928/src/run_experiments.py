"""Reproduce paired delay sweeps, independent MILP checks and counterexamples."""
import argparse,csv,json,platform,random,sys,time
from pathlib import Path
from dataclasses import replace
import numpy as np
import scipy
from dp_scheduler import Problem,Schedule,solve_dp,greedy,validate,lower_bounds
from milp_oracle import solve_milp
from legacy_bos_0915 import Instance,Edge,simulate

ROOT=Path(__file__).resolve().parents[1]

def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2),encoding="utf-8")

def write_csv(path,rows):
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def generate(n,m,seed,family):
    rng=random.Random(seed)
    p=tuple(rng.randint(1,4) for _ in range(n))
    pairs=set()
    if family=="sparse":
        pairs={(i,j) for i in range(n) for j in range(i+1,n) if rng.random()<.2}
    elif family=="layered":
        pairs={(i,j) for i in range(n) for j in range(i+1,n) if i//2<j//2 and rng.random()<.38}
    elif family=="fork_join":
        pairs={(0,j) for j in range(1,n-1)}|{(j,n-1) for j in range(1,n-1)}
    else:raise ValueError(family)
    edges=tuple((i,j,rng.randint(0,p[i])) for i,j in sorted(pairs))
    return p,edges

def fixed_prefix(p,edges,m):
    old=Instance(p,(0,)*len(p),tuple(Edge(*e) for e in edges),m)
    s=simulate(old,"bos")
    tau=max(1,s.makespan//3)
    q=tuple(max(0,min(p[i],tau-s.start[i])) for i in range(len(p)))
    return tau,q,{"start":s.start,"machine":s.machine,"completion":s.completion,"makespan":s.makespan}

def main(quick=False):
    out=ROOT/"results";out.mkdir(exist_ok=True)
    rows=[];checks=[];certificates=[];violations=[]
    started=time.perf_counter()
    for family_id,family in enumerate(("sparse","layered","fork_join")):
      for n in ((6,) if quick else (6,8)):
       for m in (2,3):
        for rep in range(2 if quick else 8):
            seed=928000+family_id*10000+n*100+m*10+rep
            p,edges=generate(n,m,seed,family)
            tau,q,prefix=fixed_prefix(p,edges,m)
            remaining=[i for i in range(n) if q[i]<p[i]]
            victim=remaining[rep%len(remaining)]
            mode=("material","capacity","mixed")[rep%3]
            base=Problem(p,edges,m,tau,q,name=f"{family}-n{n}-m{m}-s{seed}")
            previous_opt=None;base_dp=None;base_lb=lower_bounds(base)["combined"]
            base_reference=min((greedy(base,k) for k in ("bos","continue","lpt")),key=lambda s:s.completion)
            for d in (0,1,3,6):
                blocks=((victim,tau,tau+d),) if d and mode in ("material","mixed") else ()
                outages=((tau,tau+d,m-1),) if d and mode in ("capacity","mixed") else ()
                P=replace(base,blocks=blocks,outages=outages,name=base.name+f"-D{d}")
                heur={k:greedy(P,k) for k in ("bos","continue","lpt")}
                for s in heur.values():validate(P,s)
                dp=solve_dp(P,max_expansions=250000,time_limit=15)
                if d==0:base_dp=dp
                lb=max(base_lb,dp["initial_lb"])
                shifted=Schedule(base_reference.completion+d,[(t+d,tuple(a)) for t,a in base_reference.slots],"shifted-reference")
                validate(P,shifted)
                ub=min(*(s.completion for s in heur.values()),shifted.completion)
                # Shared baseline has no future gates/outages, so shift theorem applies.
                if not(lb<=dp["lb"]<=dp["ub"]<=ub):violations.append([P.name,"bracket"])
                if dp["status"]=="optimal" and base_dp["status"]=="optimal":
                    if not(0<=dp["ub"]-base_dp["ub"]<=d):violations.append([P.name,"delay"])
                    if previous_opt is not None and dp["ub"]<previous_opt:violations.append([P.name,"monotonic"])
                    previous_opt=dp["ub"]
                row={"instance":P.name,"family":family,"n":n,"m":m,"seed":seed,"mode":mode,"victim":victim,"tau":tau,"D":d,
                     "work_remaining":sum(p[i]-q[i] for i in range(n)),"analytic_lb":lb,"dp_lb":dp["lb"],"dp_ub":dp["ub"],
                     "status":dp["status"],"bos":heur["bos"].completion,"continue":heur["continue"].completion,"lpt":heur["lpt"].completion,
                     "reference_shift":shifted.completion,"portfolio_ub":ub,"base_opt":base_dp["ub"],"reference_ub":base_reference.completion,
                     "expanded":dp["expanded"],"labels":dp["labels"],"state_box":dp["state_box"],"dp_seconds":dp["seconds"]}
                rows.append(row)
                certificates.append({"problem":P.to_dict(),"prefix":prefix,"dp":dp,"heuristics":{k:s.to_dict() for k,s in heur.items()},"shifted":shifted.to_dict()})
                if n==6 and rep in (0,1) and d in (0,3):
                    oracle=solve_milp(P,time_limit=20)
                    checks.append({"instance":P.name,"dp":dp["ub"],**{k:v for k,v in oracle.items() if k!="schedule"}})
                    if oracle["status"]!=0 or abs(oracle["optimum"]-dp["ub"])>1e-6:
                        violations.append([P.name,"milp",oracle])
            print(f"done {base.name}, {len(rows)} cases",flush=True)
    write_csv(out/"delay_sweep.csv",rows)
    dump(out/"certificates.json",certificates)
    dump(out/"milp_checks.json",checks)
    # Search for original nonpreemptive BOS timing anomalies. Search results are
    # illustrative witnesses, excluded from the paired benchmark statistics.
    anomaly=None
    for seed in range(9281000,9286000):
        p,edges=generate(8,2,seed,"sparse")
        I=Instance(p,(0,)*8,tuple(Edge(*e) for e in edges),2)
        before=simulate(I,"bos")
        tau=max(1,before.makespan//3)
        for victim in range(8):
            if before.start[victim]<tau:continue
            for d in (1,2,4):
                r=[0]*8;r[victim]=tau+d
                J=Instance(p,tuple(r),tuple(Edge(*e) for e in edges),2)
                after=simulate(J,"bos")
                if after.makespan<before.makespan:
                    q0=tuple(max(0,min(p[i],tau-before.start[i])) for i in range(8))
                    q1=tuple(max(0,min(p[i],tau-after.start[i])) for i in range(8))
                    assert q0==q1
                    P0=Problem(p,edges,2,tau,q0,name="anomaly-reference")
                    P1=replace(P0,release=tuple(r),name="anomaly-delayed")
                    o0,o1=solve_dp(P0),solve_dp(P1)
                    assert o0["ub"]<=o1["ub"]
                    anomaly={"seed":seed,"victim":victim,"D":d,"tau":tau,"p":p,"edges":edges,"q0":q0,"release_delayed":r,
                             "bos_before":before.makespan,"bos_after":after.makespan,"starts_before":before.start,"starts_after":after.start,
                             "machines_before":before.machine,"machines_after":after.machine,
                             "dp_reference":o0,"dp_delayed":o1,
                             "note":"Original 0915 nonpreemptive BOS outputs; DP optima allow slot preemption in BOTH branches."}
                    break
            if anomaly:break
        if anomaly:break
    dump(out/"greedy_anomaly.json",anomaly)
    # Larger residuals document exponential state bounds and budget outcomes.
    scale=[]
    if not quick:
      for n in (8,10,12,14):
       for rep in range(4):
        p,edges=generate(n,2,928200+n*10+rep,"sparse")
        P=Problem(p,edges,2,blocks=((n//2,1,5),),outages=((1,3,1),),name=f"scale-n{n}-r{rep}")
        dp=solve_dp(P,max_expansions=10000,time_limit=2)
        scale.append({"n":n,"rep":rep,**{k:dp[k] for k in ("status","lb","ub","expanded","labels","state_box","seconds")}})
      write_csv(out/"scaling.csv",scale)
    exact=[r for r in rows if r["status"]=="optimal"]
    disturbed=[r for r in exact if r["D"]>0]
    stats={}
    for policy in ("bos","continue","lpt","portfolio_ub"):
        gaps=[(r[policy]/r["dp_ub"]-1)*100 for r in disturbed]
        stats[policy]={"mean_gap_percent":float(np.mean(gaps)),"max_gap_percent":float(max(gaps)),
                       "optimal_hits":sum(r[policy]==r["dp_ub"] for r in disturbed),"count":len(disturbed)}
    summary={"date":"2026-09-28","cases":len(rows),"exact":len(exact),"disturbed_exact":len(disturbed),"milp_checks":len(checks),
             "milp_optimal":sum(c["status"]==0 for c in checks),"violations":violations,"heuristics":stats,
             "delay_absorbed":sum(r["dp_ub"]==r["base_opt"] for r in disturbed),
             "analytic_lb_tight":sum(r["analytic_lb"]==r["dp_ub"] for r in exact),
             "mean_dp_seconds":float(np.mean([r["dp_seconds"] for r in rows])),"max_dp_seconds":max(r["dp_seconds"] for r in rows),
             "max_labels":max(r["labels"] for r in rows),"bound_closure_cases":sum(r["expanded"]==0 for r in rows),"runtime_seconds":time.perf_counter()-started,
             "environment":{"python":sys.version,"platform":platform.platform(),"numpy":np.__version__,"scipy":scipy.__version__},
             "anomaly_found":anomaly is not None,"scaling_exact":sum(r["status"]=="optimal" for r in scale),"scaling_cases":len(scale)}
    dump(out/"summary.json",summary)
    dump(out/"example_instance.json",certificates[-1]["problem"])
    print(json.dumps(summary,indent=2),flush=True)
    assert not violations,violations

if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--quick",action="store_true")
    main(parser.parse_args().quick)
