"""Structured stress test with independently derivable optimum.

Three complete-precedence layers, w equal length-2 jobs each, m=3.
One unit-capacity blackout reduces capacity from 3 to 2 in the first slot.
The first layer needs ceil((2w+1)/3) slots, each later layer ceil(2w/3).
Free-preemption unit-slot packing realizes these bounds for w >= 4.
"""
import json,math
from pathlib import Path
from dp_scheduler import Problem,solve_dp
rows=[]
for width in (4,6,8):
    n=3*width
    edges=tuple((i,j,2) for g in range(2) for i in range(width*g,width*(g+1)) for j in range(width*(g+1),width*(g+2)))
    P=Problem((2,)*n,edges,3,outages=((0,1,2),),name=f"barrier-width{width}")
    opt=math.ceil((2*width+1)/3)+2*math.ceil(2*width/3)
    dp=solve_dp(P,max_expansions=10000,time_limit=2)
    assert dp["lb"]<=opt<=dp["ub"]
    if dp["status"]=="optimal":assert dp["ub"]==opt
    rows.append({"width":width,"n":n,"derived_optimum":opt,"problem":P.to_dict(),"dp":dp})
out=Path(__file__).resolve().parents[1]/"results"/"barrier_stress.json"
out.write_text(json.dumps(rows,indent=2))
print(json.dumps([{k:v for k,v in r.items() if k not in ("problem","dp")}|{k:r["dp"][k] for k in ("status","lb","ub","expanded","seconds")} for r in rows],indent=2))
