"""Independent time-indexed MILP oracle, NOT used by the DP solver."""
import time
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix
from dp_scheduler import Schedule, greedy, validate


def solve_milp(P, time_limit=30):
    start = time.perf_counter()
    H = min(greedy(P,k).completion for k in ("bos","continue","lpt"))
    if P.q0 == P.p:
        return {"status":0,"optimum":P.tau,"lb":P.tau,"gap":0.,"seconds":0.}
    slots = list(range(P.tau,H))
    jobs = [i for i in range(P.n) if P.q0[i] < P.p[i]]
    unstarted = [i for i in jobs if P.q0[i] == 0]
    x = {(i,t):k for k,(i,t) in enumerate((i,t) for i in jobs for t in slots)}
    y = {(i,t):len(x)+k for k,(i,t) in enumerate((i,t) for i in unstarted for t in slots)}
    z = len(x)+len(y)
    c = np.zeros(z+1);c[z]=1
    lo=np.zeros(z+1);hi=np.ones(z+1);lo[z]=P.tau;hi[z]=H
    for (i,t),k in x.items():
        if not P.available(i,t):hi[k]=0
    rows,cols,data,lbs,ubs=[],[],[],[],[]
    def add(terms,lb=-np.inf,ub=np.inf):
        r=len(lbs)
        for k,v in terms.items():
            if v:rows.append(r);cols.append(k);data.append(v)
        lbs.append(lb);ubs.append(ub)
    for i in jobs:
        add({x[i,t]:1 for t in slots},P.p[i]-P.q0[i],P.p[i]-P.q0[i])
    for t in slots:
        add({x[i,t]:1 for i in jobs},ub=P.capacity(t))
        for i in jobs:
            add({x[i,t]:t+1,z:-1},ub=0)
    for i in unstarted:
        add({y[i,t]:1 for t in slots},1,1)
        for t in slots:
            add({y[i,t]:1,x[i,t]:-1},ub=0)
            terms={x[i,t]:1}
            terms.update({y[i,s]:-1 for s in slots if s<=t})
            add(terms,ub=0)
            for u,v,l in P.edges:
                if v != i:continue
                if l>0:
                    terms={y[i,t]:l}
                    if u in jobs:terms.update({x[u,s]:-1 for s in slots if s<t})
                    add(terms,ub=P.q0[u])
                elif P.q0[u]==0:
                    terms={y[i,t]:1}
                    terms.update({y[u,s]:-1 for s in slots if s<=t})
                    add(terms,ub=0)
    A=coo_matrix((data,(rows,cols)),shape=(len(lbs),z+1)).tocsc()
    integrality=np.ones(z+1);integrality[z]=0
    result=milp(c,integrality=integrality,bounds=Bounds(lo,hi),
                constraints=LinearConstraint(A,lbs,ubs),
                options={"time_limit":time_limit,"mip_rel_gap":0.0})
    answer={"status":int(result.status),"message":result.message,
            "optimum":None if result.fun is None else float(result.fun),
            "lb":None if result.mip_dual_bound is None else float(result.mip_dual_bound),
            "gap":None if result.mip_gap is None else float(result.mip_gap),
            "seconds":time.perf_counter()-start}
    if result.x is not None:
        chosen=[(t,tuple(i for i in jobs if result.x[x[i,t]]>.5)) for t in slots]
        chosen=[(t,a) for t,a in chosen if a]
        s=Schedule(max(t for t,a in chosen)+1,chosen,"milp")
        validate(P,s)
        answer["schedule"]=s.to_dict()
    return answer
