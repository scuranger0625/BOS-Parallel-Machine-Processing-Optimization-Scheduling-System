"""Exact integer-slot, progress-state DP for BOS2L repair.

Identical unit-speed machines; free slot-boundary preemption/migration;
one machine per task; fixed prefix summarized by progress q0 at time tau.
Known finite job blackouts and aggregate machine-capacity outages. No restart
loss, setup cost, uncertainty policy, or continuous-time exactness is claimed.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from itertools import combinations
import heapq
import math
import time


@dataclass(frozen=True)
class Problem:
    p: tuple[int, ...]
    edges: tuple[tuple[int, int, int], ...]
    m: int
    tau: int = 0
    q0: tuple[int, ...] = ()
    release: tuple[int, ...] = ()
    blocks: tuple[tuple[int, int, int], ...] = ()  # job, begin, end
    outages: tuple[tuple[int, int, int], ...] = ()  # begin, end, available count
    name: str = ""

    def __post_init__(self):
        n = len(self.p)
        if not self.q0:
            object.__setattr__(self, "q0", (0,) * n)
        if not self.release:
            object.__setattr__(self, "release", (0,) * n)
        assert n and self.m >= 1 and self.tau >= 0
        assert len(self.q0) == len(self.release) == n
        assert all(isinstance(v, int) and v > 0 for v in self.p)
        assert all(isinstance(q, int) and 0 <= q <= p for q, p in zip(self.q0, self.p))
        assert all(isinstance(r, int) and r >= 0 for r in self.release)
        assert len({(u,v) for u,v,_ in self.edges}) == len(self.edges)
        for u,v,l in self.edges:
            assert 0 <= u < n and 0 <= v < n and u != v
            assert isinstance(l,int) and 0 <= l <= self.p[u]
            if self.q0[v] > 0:
                assert self.q0[u] >= l and (l > 0 or self.q0[u] > 0)
        self.topological_order()  # reject cycles
        for i,a,b in self.blocks:
            assert 0 <= i < n and 0 <= a < b and isinstance(a,int) and isinstance(b,int)
        for a,b,c in self.outages:
            assert 0 <= a < b and 0 <= c <= self.m
            assert all(isinstance(v,int) for v in (a,b,c))

    @property
    def n(self):
        return len(self.p)

    def topological_order(self):
        pred = [0]*self.n
        succ = [[] for _ in self.p]
        for u,v,_ in self.edges:
            pred[v] += 1
            succ[u].append(v)
        ready = [i for i in range(self.n) if not pred[i]]
        order = []
        while ready:
            u = ready.pop()
            order.append(u)
            for v in succ[u]:
                pred[v] -= 1
                if not pred[v]:
                    ready.append(v)
        assert len(order) == self.n, "cyclic graph"
        return tuple(order)

    def capacity(self, t):
        return min([self.m] + [c for a,b,c in self.outages if a <= t < b])

    def available(self, i, t):
        return t >= self.release[i] and not any(j == i and a <= t < b for j,a,b in self.blocks)

    def stable_time(self):
        return max([self.tau, *self.release, *(b for _,_,b in self.blocks),
                    *(b for _,b,_ in self.outages)])

    def scores(self):
        b = list(self.p)
        succ = [[] for _ in self.p]
        for u,v,l in self.edges:
            succ[u].append((v,l))
        for u in reversed(self.topological_order()):
            for v,l in succ[u]:
                b[u] = max(b[u], l+b[v])
        return tuple(b)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        d = dict(d)
        for k in ("p","q0","release"):
            if k in d:
                d[k] = tuple(d[k])
        for k in ("edges","blocks","outages"):
            if k in d:
                d[k] = tuple(tuple(v) for v in d[k])
        return cls(**d)


@dataclass
class Schedule:
    completion: int
    slots: list[tuple[int, tuple[int, ...]]]
    policy: str

    def to_dict(self):
        return asdict(self)


def legal_structure(P, q, action):
    """Progress thresholds at first execution; zero lags allow joint starts."""
    chosen = set(action)
    if len(chosen) != len(action) or any(q[i] >= P.p[i] for i in action):
        return False
    for u,v,l in P.edges:
        if v in chosen and q[v] == 0:
            if l > 0 and q[u] < l:
                return False
            if l == 0 and q[u] == 0 and u not in chosen:
                return False
    return True


def actions(P, q):
    candidates = [i for i in range(P.n) if q[i] < P.p[i]
                  and (q[i] > 0 or all(q[u] >= l for u,v,l in P.edges if v == i))]
    for k in range(min(P.m,len(candidates)),0,-1):
        for a in combinations(candidates,k):
            if legal_structure(P,q,a):
                yield a


def next_slot(P, t, a):
    """Earliest legal calendar slot for a structurally legal fixed action."""
    while P.capacity(t) < len(a) or not all(P.available(i,t) for i in a):
        t += 1
    return t


def advance(q, a):
    out = list(q)
    for i in a:
        out[i] += 1
    return tuple(out)


def greedy(P, policy="bos"):
    q, t = P.q0, P.tau
    slots, previous = [], set()
    scores = P.scores()
    while q != P.p:
        selected = []
        # Same-timestamp closure preserves original zero-lag start semantics.
        while len(selected) < P.capacity(t):
            candidates = [i for i in range(P.n) if i not in selected and q[i] < P.p[i]
                          and P.available(i,t) and legal_structure(P,q,tuple(selected+[i]))]
            if not candidates:
                break
            if policy == "lpt":
                key = lambda i: (P.p[i]-q[i], -i)
            elif policy == "continue":
                key = lambda i: (int(i in previous), scores[i], -i)
            elif policy == "bos":
                key = lambda i: (scores[i], -i)
            else:
                raise ValueError(policy)
            selected.append(max(candidates,key=key))
        a = tuple(sorted(selected))
        if a:
            slots.append((t,a))
        q = advance(q,a)
        previous = set(a)
        t += 1
        assert t <= P.stable_time()+sum(P.p)+1
    return Schedule(t,slots,policy)


def infinite_capacity_bound(P):
    """Earliest finish with unlimited machines, all other constraints retained."""
    q, t = P.q0, P.tau
    while q != P.p:
        a = []
        changed = True
        while changed:
            changed = False
            for i in range(P.n):
                if i not in a and q[i] < P.p[i] and P.available(i,t) and legal_structure(P,q,tuple(a+[i])):
                    a.append(i)
                    changed = True
        q = advance(q,a)
        t += 1
        assert t <= P.stable_time()+sum(P.p)+1
    return t


def lower_bounds(P, inherited=None):
    remaining = [p-q for p,q in zip(P.p,P.q0)]
    w = sum(remaining)
    t, supplied = P.tau, 0
    while supplied < w:
        supplied += P.capacity(t)
        t += 1
    out = {"work": P.tau+math.ceil(w/P.m), "single_job": P.tau+max(remaining),
           "capacity": t, "unlimited_machines": infinite_capacity_bound(P)}
    if inherited is not None:
        out["inherited"] = inherited
    out["combined"] = max(out.values())
    return out


def validate(P, S):
    """Independent slot replay; rejects unrecorded early finish and double use."""
    q = list(P.q0)
    times = set()
    for t,a in sorted(S.slots):
        assert P.tau <= t < S.completion and t not in times
        times.add(t)
        assert len(set(a)) == len(a) and len(a) <= P.capacity(t)
        before = q.copy()
        for i in a:
            assert 0 <= i < P.n and q[i] < P.p[i] and P.available(i,t)
            if before[i] == 0:
                for u,v,l in P.edges:
                    if v == i:
                        assert before[u] >= l
                        assert l > 0 or before[u] > 0 or u in a
            q[i] += 1
    assert tuple(q) == P.p
    assert S.completion == (max(times)+1 if times else P.tau)
    return True


def solve_dp(P, max_expansions=None, time_limit=None):
    """A*-ordered label-correcting evaluation of an acyclic progress DP.

    f(q) stores earliest arrival. A label can be reopened if improved.
    Waiting is compressed by next_slot; all nonempty action subsets are tried.
    On a budget stop, return a feasible incumbent and valid frontier LB.
    """
    start = time.perf_counter()
    incumbent = min((greedy(P,k) for k in ("bos","continue","lpt")),key=lambda s:s.completion)
    bounds = lower_bounds(P)
    base_lb = bounds["combined"]
    ub = incumbent.completion
    def estimate(t,q):
        rem = [p-x for p,x in zip(P.p,q)]
        return max(base_lb,t+math.ceil(sum(rem)/P.m),t+max(rem))
    dist = {P.q0:P.tau}
    parents = {}
    heap = [(estimate(P.tau,P.q0),-sum(P.q0),P.tau,P.q0)]
    expanded, transitions, budget = 0, 0, False
    while heap:
        key,negwork,t,q = heapq.heappop(heap)
        if dist.get(q) != t:
            continue
        if key >= ub:
            # This is the smallest valid frontier key; all are now pruned.
            heap.clear()
            break
        if (max_expansions is not None and expanded >= max_expansions) or (time_limit is not None and time.perf_counter()-start >= time_limit):
            heapq.heappush(heap,(key,negwork,t,q))
            budget = True
            break
        expanded += 1
        for a in actions(P,q):
            depart = next_slot(P,t,a)
            arrival = depart+1
            q2 = advance(q,a)
            transitions += 1
            if arrival >= dist.get(q2,math.inf) or estimate(arrival,q2) >= ub:
                continue
            dist[q2] = arrival
            parents[q2] = (q,depart,a)
            if q2 == P.p:
                slots, cur = [], q2
                while cur != P.q0:
                    prev,at,act = parents[cur]
                    slots.append((at,act))
                    cur = prev
                incumbent = Schedule(arrival,list(reversed(slots)),"dp")
                ub = arrival
            else:
                heapq.heappush(heap,(estimate(arrival,q2),-sum(q2),arrival,q2))
    valid_frontier = [k for k,_,t,q in heap if dist.get(q) == t]
    lb = min([ub]+valid_frontier) if budget else ub
    lb = max(base_lb,lb)
    validate(P,incumbent)
    return {"status":"optimal" if lb == ub else "budget", "lb":lb,"ub":ub,
            "initial_lb":base_lb,"bounds":bounds,"expanded":expanded,
            "labels":len(dist),"transitions":transitions,
            "state_box":math.prod(p-q+1 for p,q in zip(P.p,P.q0)),
            "seconds":time.perf_counter()-start,"schedule":incumbent.to_dict()}


if __name__ == "__main__":
    import argparse,json
    parser = argparse.ArgumentParser()
    parser.add_argument("instance")
    parser.add_argument("--max-expansions",type=int,default=None)
    args = parser.parse_args()
    P = Problem.from_dict(json.load(open(args.instance,encoding="utf-8")))
    print(json.dumps(solve_dp(P,args.max_expansions),indent=2))
